import React from "react";
import Ddos from './pages/Ddos';

export default function (props) {
    return (
        <Ddos />
    )
}