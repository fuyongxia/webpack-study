import React from 'react';
import './index.less';

class Select extends React.Component {

    constructor() {
        super();
        this.state = {
            collapse: false
        }

        const self = this;
        window.addEventListener('click', () => {
            self.setState({
                collapse: false
            })
        });
    }

    onItemClick(item) {
        const self = this;
        const {onChange} = this.props;
        return function(e) {
            onChange && onChange(item.value);
            self.setState({
                value: item.value,
                collapse: false,
            });
            e.stopPropagation();
        }
    }

    onValueClick(e) {
        this.setState({
            collapse: !this.state.collapse
        });
        e.stopPropagation();
    }

    render() {
        const self = this;
        const { onItemClick, onValueClick } = this;
        const { data = [], placeholder = '请选择'} = this.props;

        const value = this.props.value || this.state.value || '';
        const item = data.find(i => i.value == value) || { label: placeholder};

        return (
            <div className={`m-select ${this.props.className}`} style={this.props.style}>
                <div className="select-value" onClick={onValueClick.bind(self)}>
                    {item.label}
                </div>
                {this.state.collapse && (
                    <div className="select-list">
                        <ul>
                            {data.map(item => (
                                <li className="select-item" onClick={onItemClick.bind(self)(item)}>
                                    {item.label}
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
        )
    }
}

export default Select;