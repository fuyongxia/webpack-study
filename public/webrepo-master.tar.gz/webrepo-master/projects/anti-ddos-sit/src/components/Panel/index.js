import React from 'react';
import './index.less';

class Panel extends React.Component {
    constructor() {
        super();
        this.state = {
            collapse: false
        }
    }

    onTitleClick() {
        this.setState({
            collapse: !this.state.collapse
        })
    }

    render() {
        const collapse = this.state.collapse ? 'collapse' : '';

        return (
            <div className={`m-panel ${collapse} ${this.props.className}`}>
                <div className="panel-header">
                    <h3 className="title" onDoubleClick={this.onTitleClick.bind(this)}>
                        {this.props.title}
                    </h3>
                    <div className="block">
                    </div>
                </div>
                <div className="panel-body">
                    {this.props.children}
                </div>
                <div className="panel-left-corner"></div>
                <div className="panel-right-corner"></div>
            </div>
        )
    }
}

export default Panel;