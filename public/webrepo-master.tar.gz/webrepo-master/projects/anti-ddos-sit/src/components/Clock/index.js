import React from 'react';
import fecha from 'fecha';
import './index.less';

class Clock extends React.Component {
    constructor() {
        super();
        this.state = {
            value: new Date()
        }
        const self = this;
        setInterval(()=> {
            self.setState({
                value: new Date()
            })
        }, 1000);
    }

    render() {
        const value = this.state.value || new Date();
        const dateStr = fecha.format(value, 'YYYY-MM-DD HH:mm:ss').toUpperCase();
        return (
            <div className={`m-clock ${this.props.className}`}>
                {dateStr}
            </div>
        )
    }
}

export default Clock;