import React from 'react';
import './index.less';

class Table extends React.Component {
    render() {
        return (
            <div className={`m-table ${this.props.className}`}>
                {this.props.children}
            </div>
        )
    }
}

export default Table;