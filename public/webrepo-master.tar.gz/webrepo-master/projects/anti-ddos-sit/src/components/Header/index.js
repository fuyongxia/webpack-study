import React from 'react';
import './index.less';
import Clock from '../Clock';
import Select from '../Select';

class Header extends React.Component {
    timeRange = [
        { label: '一天', value: 1 },
        { label: '一周', value: 2 },
        { label: '一月', value: 3 },
    ];

    onFilterChange = (value) => {
        this.props.updateFilters({ period: value })
    }
    
    render() {
        const { filters } = this.props;
        return (
            <div className="m-header">
                <div className="header-left">
                    <h3>中国移动CMNet骨干网抗D系统</h3>
                </div>
                <div className="header-center">
                    <h1 className="title">{this.props.title}</h1>
                </div>
                <div className="header-right">
                    <Clock />
                    <Select value={filters.period} data={this.timeRange} placeholder="时间范围" onChange={this.onFilterChange} />
                </div>
            </div>
        )
    }
}

export default Header;