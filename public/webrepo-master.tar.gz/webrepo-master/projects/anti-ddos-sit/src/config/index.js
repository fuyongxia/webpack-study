export default {
    cookie: {
        encode: false,
    },
    request: {
        onRequest: function (req, onRequest) {
            // req.headers.zy_token = app.cookie.get('zy_token');
            req.headers.Authorization =  app.storage.get('access_token') ? ('Bearer ' + app.storage.get('access_token')) : '';
            return onRequest(req);
        },
        onResponse: function (res) {
            if (res.status == 401) {
                return res.json()
                    .then(result => {
                        return Promise.reject(result);
                    })
            }

            if (res.status != 200) {
                return Promise.reject({ code: res.status, message: res.statusText });
            }

            return res.json()
                .then(result => {
                    const { code, body, message } = result;
                    if (code == null) {
                        return result;
                    }
                    if (code === '000000') {
                        return body;
                    }
                    return Promise.reject({ code, body, message });
                });
        }
    },

    service: {
        items: {
            attackSum: 'POST /api/v1/unicontroller/map/attackSum',
            attackSrcArea: 'POST /api/v1/unicontroller/map/attackSrcArea',
            attackSrcAreaList: 'POST /api/v1/unicontroller/map/attackSrcAreaList',
            attackDstAreaList: 'POST /api/v1/unicontroller/map/attackDstAreaList',
            attackSrcIp: 'POST /api/v1/unicontroller/map/attackSrcIp',
            attackDstIp: 'POST /api/v1/unicontroller/map/attackDstIp',
            attackType: 'POST /api/v1/unicontroller/map/attackType',
            attackLevel: 'POST /api/v1/unicontroller/map/attackLevel',
            attackCustomer: 'POST /api/v1/unicontroller/map/attackCustomer'
        }
    },

    socket: {
        items: {
            attack: function() {
                return app.socket('ws://192.168.131.98:8080/websocket/10001');
            }
        }
    }
}