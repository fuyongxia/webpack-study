import React from 'react';
import './style.less';

export default class extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            cur: 0
        }
    }

    onSwitch = () => {
        this.setState({ cur: this.state.cur == 0 ? 1 : 0 });
    }

    render() {
        return (
            <div className={`panel-switch ${this.props.className}`}>
                <span className={'switch-btn'} onClick={this.onSwitch}>
                    切换
                </span>
                {this.state.cur == 0 && this.props.children[0]}
                {this.state.cur == 1 && this.props.children[1]}
            </div>
        )
    }
}