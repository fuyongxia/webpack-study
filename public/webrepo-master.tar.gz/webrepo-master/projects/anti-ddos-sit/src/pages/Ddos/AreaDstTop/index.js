import React from 'react';
import Panel from '../../../components/Panel';
import Table from '../../../components/Table';
import './index.less';

class AttackMonitor extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            list: []
        }
    }

    loadData(filters) {
        app.service.attackDstAreaList(filters)
        .then(body => {
                body = (body || []).slice(0, 5);
                this.setState({ list: body });
            })
    }

    componentWillMount() {
        this.loadData(this.props.filters);
    }

    componentWillReceiveProps(nextProps) {
        if (!lodash.isEqual(this.props.filters, nextProps.filters)) {
            this.loadData(nextProps.filters);
        }
    }

    render() {
        return (
            <Panel className="panel-areaDstTop" title="被攻击地区排名">
                <Table>
                    <table>
                        <thead>
                            <tr>
                                <th width={200}>地区</th>
                                <th width={300}>被攻击次数</th>
                                <th width={300}>被攻击IP数</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.list.map(item => (
                                <tr>
                                    <td>{item.name}</td>
                                    <td>{item.attackCount}</td>
                                    <td>{item.attackIpCount}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </Table>
            </Panel>
        )
    }
}

export default AttackMonitor;