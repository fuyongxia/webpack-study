import React from 'react';
import { Easing, Tween, autoPlay } from 'es6-tween';
import Header from '../../components/Header';
import Board from './Board';
import AttackerTop from './AttackerTop';
import VictimTop from './VictimTop';
import AttackArea from './AttackArea';
import AreaSrcTop from './AreaSrcTop';
import AreaDstTop from './AreaDstTop';
import AttackeeTop from './AttackeeTop';
import AttackMax from './AttackMax';
import AttackMonitor from './AttackMonitor';
import AttackLevel from './AttackLevel';
import AttackType from './AttackType';
import AttackMap from './AttackMap';
import Switch from './Switch';

import './index.less';

class Ddos extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            filters: {
                "period": 1,
                "endTime": Date.now(),
                "startTime": Date.now() - 24*3600*1000
            },
            updateFilters: (data) => {
                if (data.period) {
                    data.startTime = Date.now() - data.period*24*3600*1000;
                    data.endTime = Date.now();
                }

                this.setState({
                    filters: {
                        ...this.state.filters,
                        ...data,
                        _updatedAt: Date.now()
                    }
                })
            }
        }

        autoPlay(true);

        this.start = 10;
        this.source = [];
        this.tween = new Tween({ count: 10 })
            .to({ count: 0 }, 3000)
            .easing(Easing.Quadratic.Out)
            .on('update', (args) => {
                this.onUpdate(args)
            })
            .repeat(Infinity)
            .start()
    }

    onUpdate({ count }) {
        if (Math.floor(count) != this.start) {
            this.start = Math.floor(count);
            if (this.source.length) {
                const attackEvent = new CustomEvent('attack', {
                    detail: this.source.splice(0, 1)[0]
                });
                if (window.dispatchEvent) {
                    window.dispatchEvent(attackEvent);
                } else {
                    window.fireEvent(attackEvent);
                }
            }
        }
    }

    componentWillMount() {        
        const socket = app.socket.attack();
        socket.onmessage = event => {
            const eventData = (JSON.parse(event.data) || {});
            if (eventData.type == 'ATTACK_OLD') {
                this.source = this.source.concat(eventData.data);
            } else {
                this.source = eventData.data;
            }
        };

        this.timer = setInterval(() => {
            this.state.updateFilters({})
        },  3*60*1000)
    }

    componentWillUnmount() {
        if (this.timer) {
            clearInterval(this.timer);
        }
    }

    render() {
        return (
            <div id="app" className="ddos">
                <Header title="异常流量攻击安全态势" {...this.state} />
                <Board {...this.state} />
                <div className="m-main">
                    <AttackMap {...this.state} />
                </div>
                <div className="m-left">
                    <VictimTop {...this.state} />
                        <Switch className="mb10">
                            <AttackeeTop {...this.state} />
                            <AreaDstTop {...this.state} />
                        </Switch>
                    <AttackMax {...this.state} />
                </div>
                <div className="m-right">
                    <AttackArea {...this.state} />
                    <Switch>
                        <AttackerTop {...this.state} />
                        <AreaSrcTop {...this.state} />
                    </Switch>
                </div>
                <div className="m-bottom">
                    <div className="floor-1">
                        <AttackMonitor {...this.state} />
                    </div>
                    <div className="floor-2">
                        <AttackLevel {...this.state} />
                        <AttackType {...this.state} />
                    </div>
                </div>
            </div>
        )
    }
}

export default Ddos;