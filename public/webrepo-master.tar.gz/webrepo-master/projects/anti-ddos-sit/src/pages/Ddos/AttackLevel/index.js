import React from 'react';
import lodash from 'lodash';
import Panel from '../../../components/Panel';
import G2, { Chart, Shape, Animate, Util } from '@antv/g2';
import fecha from 'fecha';

class AttackLevel extends React.Component {
  loadData(filters) {
    app.service.attackLevel(filters)
      .then(body => {
        this.renderChart(body || []);
      })
  }

  componentWillMount() {
    this.loadData(this.props.filters);
  }

  componentWillReceiveProps(nextProps) {
    if (!lodash.isEqual(this.props.filters, nextProps.filters)) {
      this.loadData(nextProps.filters);
    }
  }

  renderChart(data) {
    const { filters } = this.props;
    data = data.map(item => ({
      ...item,
      value: parseInt(item.value),
      dataTime: fecha.format(new Date(+item.name), {"1": "HH", "2": "MM/DD", "3": "MM/DD", "4": "YYYY/MM"}[filters.period || "2"])
    }))

    if (this.chart) {
      this.chart.changeData(data);
      return;
    }

    this.chart = new Chart({
      container: this.refs.container,
      forceFit: true,
      height: 210,
      padding: [30, 30, 50, 50]
    });
    this.chart.legend(false);
    this.chart.source(data, {
      dataTime: {
        tickCount: 12
      }
    });
    this.chart.tooltip({
      crosshairs: {
        type: 'line'
      }
    });
    this.chart.axis("dataTime", {
      label: {
        textStyle: {
          fill: "#fff",
        }
      }
    });
    this.chart.axis("value", {
      label: {
        textStyle: {
          fill: "#fff",
          fontFamily: 'digit'
        }
      }
    })
    this.chart.areaStack().position('dataTime*value').color('type').shape('smooth');
    this.chart.lineStack().position('dataTime*value').color('type').size(2).shape('smooth');
    this.chart.render();
  }

  render() {
    return (
      <Panel className="panel-attacklevel" title="攻击级别变化趋势">
        <div ref="container" />
      </Panel>
    )
  }
}

export default AttackLevel;