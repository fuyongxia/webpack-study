import React from 'react';
import Panel from '../../../components/Panel';
import Table from '../../../components/Table';
import fecha from 'fecha';
import './index.less';

class AttackMonitor extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [ ]
        }
    }

    componentWillMount() {
        window.addEventListener('attack', e => {
            let data = this.state.data.slice();
            data = [e.detail].concat(data);
            if (data.length > 3) {
                data.pop();
            }
            this.setState({ data });
        })
    }

    render() {
        return (
            <Panel className="panel-attackmonitor" title="当前正在发生攻击详情">
                <Table>
                    <table>
                        <thead>
                            <tr>
                                <th width={200}>攻击时间</th>
                                <th width={200}>攻击IP地址</th>
                                <th width={200}>攻击归属地</th>
                                <th width={200}>被攻击IP地址</th>
                                <th width={200}>被攻击归属地</th>
                                <th>流速(Gbps)</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.data.map(item => (
                                <tr>
                                    <td>{item.startTime}</td>
                                    <td>{item.srcIpInfo.ip}</td>
                                    <td>{[item.srcIpInfo.country, item.srcIpInfo.province].join('/')}</td>
                                    <td>{item.dstIpInfo.ip}</td>
                                    <td>{[item.dstIpInfo.country, item.dstIpInfo.province].join('/')}</td>
                                    <td>{(item.bps/1e9).toFixed(2)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </Table>
            </Panel>
        )
    }
}

export default AttackMonitor;