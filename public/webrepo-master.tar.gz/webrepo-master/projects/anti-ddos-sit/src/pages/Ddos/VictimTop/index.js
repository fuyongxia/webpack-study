import React from 'react';
import lodash from 'lodash';
import Panel from '../../../components/Panel';
import Table from '../../../components/Table';
import './index.less';

class VictimTop extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [ ]
        }
    }

    loadData(filters) {
        app.service.attackCustomer(filters)
            .then(body => {
                body = body || [];
                body = body.slice(0, 5);
                this.setState({ 
                    data: body
                })
            })
    }
    
    componentWillMount() {
        this.loadData(this.props.filters);
    }
    
    componentWillReceiveProps(nextProps) {
        if (!lodash.isEqual(this.props.filters, nextProps.filters)) {
            this.loadData(nextProps.filters);
        }
    }

    render() {
        return (
            <Panel className="panel-victimtop mb10" title="被攻击资源池统计">
                <Table>
                    <table>
                        <thead>
                            <tr>
                                <th>序号</th>
                                <th>资源池名称</th>
                                <th>被攻击次数</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.data.map((item, index) => (
                                <tr>
                                    <td>{index + 1}</td>
                                    <td>{item.custName}</td>
                                    <td>{item.attackCount}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </Table>
            </Panel>
        )
    }
}

export default VictimTop;