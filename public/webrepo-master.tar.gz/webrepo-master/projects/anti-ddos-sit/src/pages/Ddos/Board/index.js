import React from 'react';
import lodash from 'lodash';
import { Easing, Tween, autoPlay } from 'es6-tween';
import './index.less';

class Board extends React.Component {
    constructor(props) {
        super(props);

        autoPlay(true);
        this.state = {
            attackCount: 0,
            maxBps: 0,
        }
    }

    loadData(filters, init) {
        app.service.attackSum(filters || {})
            .then(body => {
                body = body || {};
                if (init) {
                    this.setState(body);
                } else {
                    new Tween(this.state)
                        .to(body, 30 * 1000)
                        .easing(Easing.Quartic.Out)
                        .on('update', (args) => {
                            this.setState({
                                attackCount: parseInt(args.attackCount),
                                maxBps: args.maxBps.toFixed(2)
                            })
                        })
                        .start()
                }
            })
    }

    componentWillMount() {
        this.loadData(this.props.filters, true);

        this.timer = setInterval(() => {
            this.loadData(this.props.filters, false);
        }, 30*1000)
    }

    componentWillUnmount() {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
    }

    componentWillReceiveProps(nextProps) {
        if (!lodash.isEqual(this.props.filters, nextProps.filters)) {
            this.loadData(nextProps.filters, true);
        }
    }

    render() {
        return (
            <div className="panel-board">
                <div className="card">
                    <h1>全网攻击总次数（次）</h1>
                    <p>{String(this.state.attackCount).split('').map(i => (
                        <span>{i}</span>
                    ))}</p>
                </div>
                <div className="card">
                    <h1>全网攻击峰值流量（Gbps）</h1>
                    <p>{(this.state.maxBps/(1024*1024*1024)).toFixed(2)}</p>
                </div>
            </div>
        )
    }
}

export default Board;