import React from 'react';
import lodash from 'lodash';
import Panel from '../../../components/Panel';
import fecha from 'fecha';
import './index.less';

class Board extends React.Component {
    constructor(props) {
        super(props);

        this.state = {}
    }

    componentDidMount() {
        window.addEventListener('attack', e => {
            const data = e.detail;
            if (data.level == '高') {
                this.setState({ data });
            }
        })
    }

    render() {
        const { data } = this.state;

        return (
            <Panel className={`panel-attackmax ${ (data && data.companyName) ? 'imporant' : ''}`} title="重大网络攻击详情">
                {data && (
                    <ul>
                        <li>
                            <label>发生时间：</label> {data.startTime}
                        </li>
                        <li>
                            <label>攻击目标：</label> {data.custName}
                        </li>
                        <li>
                            <label>攻击目标IP地址：</label> {data.dstIp}
                        </li>
                        <li>
                            <label>攻击类型：</label> {data.attackType}
                        </li>
                        <li>
                            <label>流量大小：</label> {(data.bps / 1e9).toFixed(2)} Gbps
                        </li>
                        <li>
                            <label>告警等级：</label> {data.level}
                        </li>
                    </ul>
                )}
            </Panel>
        )
    }
}

export default Board;