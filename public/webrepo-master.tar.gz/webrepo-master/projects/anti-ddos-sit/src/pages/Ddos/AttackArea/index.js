import React from 'react';
import lodash from 'lodash';
import Panel from '../../../components/Panel';
import G2, { Chart, Shape, Animate, Util } from '@antv/g2';
import DataSet from '@antv/data-set';

export default class extends React.Component {
    loadData(filters) {
        app.service.attackSrcArea(filters)
        .then(body => {
                this.renderChart(body || []);
            })
    }

    componentWillMount() {
        this.loadData(this.props.filters);
    }

    componentWillReceiveProps(nextProps) {
        if (!lodash.isEqual(this.props.filters, nextProps.filters)) {
            this.loadData(nextProps.filters);
        }
    }

    renderChart(data) {
        data = data.map(item => ({
            ...item,
            value: parseInt(item.value)
        }))

        data.sort((a, b) => {
            return b.value - a.value;
        })

        if (data.length > 9) {
            let top9 = data.splice(0, 9);
            let others = {
                name: '其他',
                value: data.reduce((accumulator, currentValue) => {
                    return accumulator + currentValue.value
                }, 0)
            }
            data = top9.concat(others);
        }

        const ds = new DataSet();
        const dv = ds.createView().source(data);
        dv.transform({
            type: 'percent',
            field: 'value',
            dimension: 'name',
            as: 'percent'
        });

        if (this.chart) {
            this.chart.changeData(dv);
            return;
        }

        this.chart = new Chart({
            container: this.refs.container,
            forceFit: true,
            height: 210,
            padding: [10, 10, 20, 10]
        })

        this.chart.source(dv);
        this.chart.legend(false);
        this.chart.coord('theta', { 
            radius: 0.8,
            innerRadius: 0.5
        });
        this.chart.tooltip({ 
            showTitle: false 
        });
        this.chart.intervalStack().position('value').color('name').label('percent', {
            formatter: function formatter(val, item) {
                return item.point.name + ': ' + item.point.value;
            },
            textStyle: {
                fill: '#fff',
                fontSize: '12'
              }
        });
        this.chart.render();
    }

    render() {
        return (
            <Panel className="panel-attackarea mb10" title="攻击源地区统计">
                <div ref="container" />
            </Panel>
        )
    }
}