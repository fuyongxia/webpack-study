import React from 'react';
import G2, { Chart, Shape, Animate, MatrixUtil } from '@antv/g2';
import DataSet from '@antv/data-set';
import chinaMapData from '../../../assets/china.geo.json';
import worldMapData from '../../../assets/world.geo.json';
import lodash from 'lodash';
import './index.less';

class AttackMap extends React.Component {
    constructor(cfg) {
        super(cfg);
        this.pressing = false;
        this.prePoint = null;

        this.registerShape();
    }

    registerShape() {
        // 向Shape工厂注册某个geom的一个shape
        Shape.registerShape('edge', 'attackLine', {
             // 自定义具体标记点
            getPoints(cfg) {
                return [
                    { x: cfg.x[0], y: cfg.y[0] },
                    { x: cfg.x[1], y: cfg.y[1] }
                ]
            },
            // 自定义最终绘制
            draw(cfg, container) {
                const points = this.parsePoints(cfg.points); // 将0-1空间的坐标转换为画布坐标

                const fromXY = [points[0].x, points[0].y];
                const targetXY = [points[1].x, points[1].y];;

                const width = targetXY[0] - fromXY[0];
                const height = targetXY[1] - fromXY[1];
                
                let lineLength = 100;

                //计算出目标点跟根据点的距离
                const distance = Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2));
                if (distance < lineLength) {
                    lineLength = distance;
                }

                let propertion = 1;
                if (distance == 0) {
                    propertion = 0;
                } else {
                    propertion = lineLength / distance;
                }

                //起点的三角形
                const sourcePolygon = [];
                sourcePolygon.push(fromXY);
                sourcePolygon.push([(targetXY[0] - fromXY[0]) * propertion + fromXY[0], (targetXY[1] - fromXY[1]) * propertion + fromXY[1] - 2]);
                sourcePolygon.push([(targetXY[0] - fromXY[0]) * propertion + fromXY[0], (targetXY[1] - fromXY[1]) * propertion + fromXY[1] + 2]);
                
                //终点的三角形
                const targetpolygon = [];
                targetpolygon.push([(targetXY[0] - (targetXY[0] - fromXY[0]) * propertion), (targetXY[1] - (targetXY[1] - fromXY[1]) * propertion)]);
                targetpolygon.push([targetXY[0], targetXY[1] - 2]);
                targetpolygon.push([targetXY[0], targetXY[1] + 2]);

                //起点
                const srcPoint = container.addShape('circle', {
                    attrs: {
                        x: points[0].x,
                        y: points[0].y,
                        r: 3,
                        fill: cfg.color
                    }
                });

                //终点
                const destPoint = container.addShape('circle', {
                    attrs: {
                        x: points[1].x,
                        y: points[1].y,
                        r: 3,
                        fill: cfg.color
                    }
                });

                const startRipple = container.addShape('circle', {
                    attrs: {
                        x: points[0].x,
                        y: points[0].y,
                        r: 5,
                        stroke: cfg.color,
                        lineWidth: 5,
                        opacity: 1,
                        fill: 'rgba(0,0,0,0)'
                    }
                });

                const attackLine = container.addShape('polygon', {
                    attrs: {
                        points: sourcePolygon,
                        fill: cfg.color
                    }
                })

                startRipple.animate({
                    r: 80,
                    opacity: 0
                }, 2000, 'easeCubicOut', ()=> {
                    startRipple.destroy();
                })

                attackLine.animate({ 
                    points: targetpolygon
                }, 2000, 'easeLinear', ()=>{
                    attackLine.animate({
                        points: [[targetXY[0], targetXY[1]], [targetXY[0], targetXY[1]], [targetXY[0], targetXY[1]]]
                    }, 500, () => {
                        attackLine.destroy();

                        const targetRipple = container.addShape('circle', {
                            attrs: {
                                x: points[1].x,
                                y: points[1].y,
                                r: 5,
                                stroke: cfg.color,
                                lineWidth: 5,
                                opacity: 1,
                                fill: 'rgba(0,0,0,0)'
                            }
                        });

                        targetRipple.animate({
                            r: 80,
                            opacity: 0
                        }, 2000, 'easeCubicOut', ()=> {
                            targetRipple.destroy();

                            srcPoint.animate({
                                opacity: 0
                            }, 2500, 'easeLinear', () => {
                                srcPoint.destroy();
                            });

                            destPoint.animate({
                                opacity: 0
                            }, 2500, 'easeLinear', () => {
                                destPoint.destroy();
                            })
                        })
                    })
                });
                return container;
            }
        });
    }

    init() {
        this.mapChart = new Chart({
            container: this.refs.backgroud,
            height: window.innerHeight,
            width: 1900,
            padding: [80, 300, 80, 0]
        })

        this.mapChart.tooltip({ showTitle: false });
        // 同步度量
        this.mapChart.scale({
            longitude: {
                sync: true,
                nice: false,
                min: -180,
                max: 180,
            },
            latitude: {
                sync: true,
                nice: false,
                min: -90,
                max: 90
            }
        });
        this.mapChart.axis(false);
        this.mapChart.legend(false);

        var ds = new DataSet();
        var worldMap = ds.createView('back').source(worldMapData, {
            type: 'GeoJSON'
        });

        var chinaMap = ds.createView('front').source(chinaMapData, {
            type: 'GeoJSON'
        })

        const worldMapView = this.mapChart.view();
        worldMapView.source(worldMap);
        worldMapView.tooltip(false);
        worldMapView.polygon().position('longitude*latitude').style({
            fill: '#04208e',
            stroke: '#07c7ff',
            lineWidth: 1
        })

        const chinaMapView = this.mapChart.view();
        chinaMapView.source(chinaMap);
        chinaMapView.tooltip(false);
        chinaMapView.polygon().position('longitude*latitude').style({
            fill: '#04208e',
            stroke: '#07c7ff',
            lineWidth: 1
        })

        const attackView = this.mapChart.view();
        attackView.source([]);
        attackView.polygon().position('longitude*latitude')
            .color('value', 'blue-cyan-lime-yellow-red')
            .opacity(0.3)
            .tooltip('name*value', function (name, value) {
                return {
                    name: ` ${name}被攻击次数`,
                    value: value
                }
            })
            .animate({
                leave: {
                    animation: 'fadeOut'
                }
            });
        this.attackView = attackView;

        this.mapChart.render();

        this.chart = new Chart({
            container: this.refs.front,
            height: 900,
            width: 1600,
            height: 1060,
            width: 1900,
            padding: [80, 300, 80, 0],
        });
        
        this.chart.tooltip({ showTitle: false });
        // 同步度量
        this.chart.scale({
            longitude: {
                sync: true,
                nice: false,
                min: -180,
                max: 180,
            },
            latitude: {
                sync: true,
                nice: false,
                min: -90,
                max: 90
            }
        });
        this.chart.axis(false);
        this.chart.legend(false);
        this.chart.render();
    }

    initEvent() {
        this.mapChart.on('mouseup', this.onMouseUp.bind(this));
        this.mapChart.on('mousedown', this.onMouseDown.bind(this));
        this.mapChart.on('mousemove', this.onMouseMove.bind(this));
        this.refs.backgroud.addEventListener('mousewheel', this.onMouseWheel.bind(this));
    }

    onMouseUp(e) {
        this.pressing = false;
        this.prePoint = null;
    }

    onMouseDown(e) {
        this.pressing = true;
        this.prePoint = { x: e.x, y: e.y };
    }

    onMouseMove(e) {
        let point;
        let prePoint;
        let canvas = this.mapChart.get('canvas');

        if (this.pressing) {
            point = canvas.getPointByClient(e.x, e.y);
            point = {
                x: point.x / canvas.get('pixelRatio'),
                y: point.y / canvas.get('pixelRatio')
            }

            prePoint = canvas.getPointByClient(this.prePoint.x, this.prePoint.y);
            prePoint = {
                x: prePoint.x / canvas.get('pixelRatio'),
                y: prePoint.y / canvas.get('pixelRatio')
            };

            this.mapChart.get('canvas').translate(point.x - prePoint.x, point.y - prePoint.y);
            this.mapChart.get('canvas').draw(false);

            this.chart.get('canvas').translate(point.x - prePoint.x, point.y - prePoint.y);
            this.chart.get('canvas').draw(false);

            this.prePoint = { x: e.x, y: e.y };
        }
    }

    onMouseWheel(e) {
        e.preventDefault();

        let scale = 1;
        let times = 1.05;
        let delta = e.wheelDelta;
        let canvas = this.mapChart.get('canvas');

        let point;

        if (Math.abs(delta) > 10) {
            point = canvas.getPointByClient(e.clientX, e.clientY);
            point = {
                x: point.x / canvas.get('pixelRatio'),
                y: point.y / canvas.get('pixelRatio')
            };

            if (delta > 0) {
                scale = scale * times;
            } else {
                scale = scale / times;
            }

            this.mapChart.get('canvas').translate(-point.x, -point.y);
            this.mapChart.get('canvas').scale(scale, scale);
            this.mapChart.get('canvas').translate(point.x, point.y);
            this.mapChart.get('canvas').draw(false);


            this.chart.get('canvas').translate(-point.x, -point.y);
            this.chart.get('canvas').scale(scale, scale);
            this.chart.get('canvas').translate(point.x, point.y);

            this.chart.get('canvas').draw(false);
        }
    }

    componentDidMount() {
        this.init();
        this.initEvent();

        window.addEventListener('attack', e => {
            const detail = e.detail;

            let type = 2;
            // if (detail.destCity == '上海') {
            //     type = 0;
            // }

            // if (detail.sourceCity == '上海') {
            //     type = 1;
            // }
            const attackView = this.chart.view();
            attackView.tooltip(false);
            attackView.source([
                {
                    type: type,
                    longitude: [
                        parseFloat(e.detail.srcIpInfo.longitude),
                        parseFloat(e.detail.dstIpInfo.longitude)
                    ],
                    latitude: [
                        parseFloat(e.detail.srcIpInfo.latitude),
                        parseFloat(e.detail.dstIpInfo.latitude)
                    ],
                    // longitude: [
                    //     116.389,
                    //     121.409
                    // ],
                    // latitude: [
                    //     39.9488,
                    //     31.0909
                    // ]
                }
            ]);
            attackView.edge().position('longitude*latitude').color('type', type => ["#e91e63", "#ffeb3b", "#ff5722"][type]).shape('attackLine');
            attackView.repaint();
            setTimeout(() => {
                this.chart.removeView(attackView);
            }, 10000)
        });

        this.loadData(this.props.filters);
    }


    loadData(filters) {
        // app.service.mapStat(filters)
        //   .then(body => {
        //     var ds = new DataSet();
        //     var worldMapDv = ds.createView().source(chinaMapData, {
        //         type: 'GeoJSON'
        //     });
    
        //     var attackDv = ds.createView().source(body)
        //         .transform({
        //             geoDataView: worldMapDv,
        //             field: 'name',
        //             type: 'geo.region',
        //             as: ['longitude', 'latitude']
        //         });
            
        //     this.attackView.changeData(attackDv);
        //   })
      }
        
      componentWillReceiveProps(nextProps) {
        if (!lodash.isEqual(this.props.filters, nextProps.filters)) {
          this.loadData(nextProps.filters);
        }
      }

    render() {
        return (
            <div className="panel-attackmap">
                <div ref="backgroud" style={{position: "absolute", transform: "translate(-50%,-50%)", top: "50%", left: "50%"}} />
                <div ref="front" style={{position: "absolute", transform: "translate(-50%,-50%)", top: "50%", left: "50%", pointerEvents: "none"}} />
            </div>
        )
    }
}

export default AttackMap;