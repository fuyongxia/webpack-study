import React from 'react';
import Panel from '../../../components/Panel';
import G2, { Chart, Shape, Animate, Util } from '@antv/g2';
import lodash from 'lodash';

class AttackerTop extends React.Component {
    constructor(props) {
        super(props);

        Shape.registerShape('interval', 'borderRadius', {
            draw: function draw(cfg, container) {
                var points = cfg.points;
                var path = [];
                path.push(['M', points[0].x, points[0].y]);
                path.push(['L', points[1].x, points[1].y]);
                path.push(['L', points[2].x, points[2].y]);
                path.push(['L', points[3].x, points[3].y]);
                path.push('Z');
                path = this.parsePath(path); // 将 0 - 1 转化为画布坐标

                return container.addShape('rect', {
                    attrs: {
                        x: path[3][1], // 矩形起始点为左上角
                        y: path[3][2],
                        width: path[1][1] - path[0][1],
                        height: path[1][2] - path[2][2],
                        fill: cfg.color,
                        radius: (path[1][2] - path[2][2]) / 2
                    }
                });
            }
        });
    }

    loadData(filters) {
        app.service.attackSrcIp(filters)
            .then(body => {
                this.renderChart(body || []);
            })
    }

    componentWillMount() {
        this.loadData(this.props.filters);
    }

    componentWillReceiveProps(nextProps) {
        if (!lodash.isEqual(this.props.filters, nextProps.filters)) {
            this.loadData(nextProps.filters);
        }
    }

    renderChart(data) {
        data = data.slice(0, 10);

        data = data.map(item => ({
            ...item,
            value: parseInt(item.value)
        }))

        data.sort(function (a, b) {
            return a.value - b.value;
        });

        if (this.chart) {
            this.chart.changeData(data);
            return;
        }

        this.chart = new Chart({
            container: this.refs.container,
            forceFit: true,
            height: 320,
            padding: [20, 20, 20, 90]
        });

        this.chart.tooltip({ showTitle: false });
        this.chart.source(data, {
            value: {
                tickCount: 4
            }
        });
        this.chart.axis('name', {
            label: {
                offsetX: -64,
                textStyle: {
                    fill: "#fff",
                    textAlign: "left",
                    fontFamily: "digit"
                }
            }
        });
        this.chart.axis('value', {
            label: {
                offsetX: -10,
                textStyle: {
                    fill: "#fff"
                }
            }
        })
        this.chart.coord().transpose();
        this.chart.interval().position('name*value').color('name').shape('borderRadius').tooltip("name*value", (name, value) => ({ name, value }));
        this.chart.render();
    }

    render() {
        return (
            <Panel className="panel-attackertop" title="攻击源IP地址统计">
                <div ref="container" />
            </Panel>
        )
    }
}

export default AttackerTop;