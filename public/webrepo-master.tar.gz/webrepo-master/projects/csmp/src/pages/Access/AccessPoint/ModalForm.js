import React, { useContext } from 'react';
import { Modal, Form, Input, InputNumber } from 'antd';
import { Constant, Grid, Select } from 'ui';

export default function (props) {
    const { accessPointType = [] } = useContext(Constant.Context);
    return (
        <Modal visible width={800} {...props}>
            <Form {...props}>
                <Grid labelWidth="90px" gutter={16}>
                    <Grid.Row>
                        <Form.Item
                            label="接入点名称"
                            name="pointName"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="接入点类型"
                            name="pointType"
                        >
                            <Select data={accessPointType} />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                            label="接入点路径"
                            name="baseDir"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="服务端口"
                            name="pointPort"
                        >
                            <InputNumber style={{width: '100%'}} />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                            label="接入点配置"
                            name="pointConfig"
                        >
                            <Input.TextArea />
                        </Form.Item>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}