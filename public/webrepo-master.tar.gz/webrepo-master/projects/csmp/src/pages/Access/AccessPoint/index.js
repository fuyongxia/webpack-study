import { Button, Space } from 'antd';
import { useModalForm, useStyles, useTableFilters } from 'hooks';
import React, { useContext, useEffect } from 'react';
import { confirm, Constant, Table, renderer } from 'ui';
import ModalForm from './ModalForm';

export default function (props) {
    const { accessPointStatus = [], accessPointType = [] } = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({ accessId: props.accessId });
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    const styles = useStyles({
        "container": {
            marginTop: 20,
        },
        "actions": {
            margin: "10px 0"
        }
    })

    useEffect(() => {
        setFilters({ 
            accessId: props.accessId, 
            _updatedAt: Date.now()
        });
    }, [ props.accessId ])

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onSave() {
        if (modalForm.type == 'add') {
            app.service.accessPointSave({accessId: props.accessId, ...modalForm.data})
                .then(body => {
                    setModalForm(false);
                    setFilters({_updatedAt: Date.now()});
                })
        }

        if (modalForm.type == 'update') {
            app.service.accessPointUpdate(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({_updatedAt: Date.now()});
                })
        }
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '编辑',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.accessPointDelete)(record).then(body => {
                setFilters({_updatedAt: Date.now()});
            })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    function accessPointService(args) {
        if (args.accessId) {
            return app.service.accessPointList(args);
        }
        return Promise.resolve([]);
    }

    return (
        <div className={styles.container}>
            <div className={styles.actions}>
                <Button type="primary" onClick={onAdd} disabled={!props.accessId}>新增接入点</Button>
            </div>
            <div className={styles.results}>
                <Table size="middle" bordered filters={filters} service={accessPointService}>
                    <Table.Column title="序号" dataIndex="_index" />
                    <Table.Column title="接入点名称" dataIndex="pointName" />
                    <Table.Column title="类型" dataIndex="pointType" render={renderer.enumRender({ data: accessPointType })} />
                    <Table.Column title="路径" dataIndex="baseDir" />
                    <Table.Column title="状态" dataIndex="pointStatus"  render={renderer.enumRender({ data: accessPointStatus})} />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </div>
            {modalForm && <ModalForm {...modalFormProps} />}
        </div>
    )
}