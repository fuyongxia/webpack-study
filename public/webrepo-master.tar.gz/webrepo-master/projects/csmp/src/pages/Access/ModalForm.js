import React, { useRef } from 'react';
import { Modal, Form, Row, Col, Input, Select, Button, Space, InputNumber } from 'antd';
import { Grid } from 'ui';
import AccessPoint from './AccessPoint';

export default function (props) {
    return (
        <Modal visible width={800} {...props} okText="关闭" onOk={props.onOk}>
            <Form {...props} >
                <Grid labelWidth="90px" gutter={16}>
                    <Grid.Row>
                        <Form.Item
                            label="接入器名称"
                            name="accessName"
                        >
                            <Input />
                        </Form.Item>
                        <></>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                            label="接入器地址"
                            name="accessIp"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="接入器端口"
                            name="accessPort"
                        >
                            <InputNumber style={{ width: '100%'}} />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row style={{textAlign: 'right'}}>
                        <Button type="primary" htmlType="submit">保存</Button>
                    </Grid.Row>
                </Grid>
            </Form>
            <AccessPoint accessId={props.data.accessId} />
        </Modal>
    )
}