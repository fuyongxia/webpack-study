import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, message, Space } from 'antd';
import { useModalForm, useTableFilters, useService } from 'hooks';
import React, { useContext } from 'react';
import { confirm, Constant, Filters, Page, Results, Table, renderer } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const { accessState } = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onOk: onOk, onFinish: onSave });

    function onOk() {
        setModalForm(false);
        setFilters({_updatedAt: Date.now()});
    }

    function onSave() {
        if (modalForm.type == 'add') {
            if (modalForm.data.accessId) {
                app.service.accessUpdate(modalForm.data)
                    .then(body => {
                        message.success('保存成功');
                    })
            } else {
                app.service.accessSave(modalForm.data)
                    .then(body => { 
                        setModalForm({
                            ...modalForm,
                            data: { 
                                ...modalForm.data,
                                ...body
                            }
                        });
                        message.success('保存成功');
                    })
            }
        }

        if (modalForm.type == 'update') {
            app.service.accessUpdate(modalForm.data)
                    .then(body => {
                        message.success('保存成功');
                    })
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'add',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.accessDelete)(record)
                .then(body => {
                    setFilters({_updatedAt: Date.now()});
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="接入器管理">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="接入器名称"
                    name="accessName"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="接入器列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table filters={filters} service={app.service.accessList}>
                    <Table.Column title="序号" dataIndex="_index" />
                    <Table.Column title="接入器名称" dataIndex="accessName" />
                    <Table.Column title="接入器地址" dataIndex="accessIp" />
                    <Table.Column title="接入器端口" dataIndex="accessPort" />
                    <Table.Column title="接入点数量" dataIndex={["accessPoints", "length"]} />
                    <Table.Column title="状态" dataIndex="accessState"  render={renderer.enumRender({ data: accessState})} />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            {modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function(props) {
    const constants = useService(app.service.accessAttrs, {});
   
    return (
        <Constant.Provider value={constants}>
            <Index />
        </Constant.Provider>
    )
}