import React from 'react';
import { useHistory, useLocation } from "react-router-dom";

export default function(props) {
    let history = useHistory();
    let location = useLocation();

    React.useEffect(() => {
        const params  = new URLSearchParams(location.hash.slice(1));
        app.storage.set('access_token', params.get('access_token'));
        history.push(app.config.homeUrl || '/');
    }, [location]);

    return '正在跳转中...';
}