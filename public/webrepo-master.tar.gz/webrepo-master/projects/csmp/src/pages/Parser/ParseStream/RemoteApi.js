import { MinusCircleOutlined, PlusCircleOutlined } from '@ant-design/icons';
import { Form, Input, Space, Button } from 'antd';
import { useList } from 'hooks';
import React, { useEffect} from 'react';
import { Grid, Select } from 'ui';

export default function (props) {
    const { list, onAdd, onRemove, onChange } = useList(props.value || []);

    useEffect(() => {
        if (props.onChange) {
            props.onChange(list);
        }
    }, [ JSON.stringify(list) ])


    return (
        <Grid>
            <Grid.Row style={{marginBottom: 15}}>
                <Button onClick={onAdd} style={{width: '100%'}}>添加</Button>
            </Grid.Row>
            {list.map((item, index) => (
                <Grid.Row gutter={16}>
                    <Grid.Col span={8}>
                        <Form.Item
                            label=""
                            colon=""
                        >
                             <Select params={{ pageSize: 999 }} value={item.apiId} service={app.service.remoteApiList} labelField="apiName" valueField="apiId" converter={parseInt} onChange={onChange('apiId', index)} />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={14}>
                        <Form.Item
                            label="参数"
                        >
                            <Input.TextArea value={item.requestParams} onChange={onChange('requestParams', index)} />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={2}>
                        <Space align="center" style={{ float: 'right', height: 30, fontSize: 22, color: '#999' }}>
                            <MinusCircleOutlined onClick={onRemove(index)} />
                        </Space>
                    </Grid.Col>
                </Grid.Row>
            ))}
        </Grid>
    )
}