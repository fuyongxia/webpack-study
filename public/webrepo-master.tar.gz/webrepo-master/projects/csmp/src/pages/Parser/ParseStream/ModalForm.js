import React, { useContext } from 'react';
import { Modal, Form, Input, InputNumber } from 'antd';
import { Constant, Grid, Select } from 'ui';
import PipelineOutput from './PipelineOutput';
import RemoteApi from './RemoteApi';

export default function (props) {
    return (
        <Modal visible width={960} {...props}>
            <Form {...props}>
                <Grid labelWidth="90px" gutter={16}>
                    <Grid.Row>
                        <Grid.Col span={12}>
                            <Form.Item
                                label="解析流名称"
                                name="streamName"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="解析流代码"
                                name="streamCode"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="解析模板"
                                name="templateId"
                            >
                                <Select params={{}} service={app.service.parseTemplateList} labelField="templateName" valueField="templateId" converter={parseInt} />
                            </Form.Item>
                            <Form.Item
                                label="输入通道"
                                name="pipelineIn"
                            >
                                <Select params={{}} service={app.service.pipelineList} labelField="pipelineName" valueField="pipelineId" converter={parseInt} />
                            </Form.Item>
                        </Grid.Col>
                    </Grid.Row>
                    <Grid.Row>
                        <Grid.Col span={24}>
                            <Form.Item
                                label="输出通道"
                                name="pipelineOuts"
                            >
                                <PipelineOutput />
                            </Form.Item>
                            <Form.Item
                                label="外部数据"
                                name="streamApis"
                            >
                                <RemoteApi />
                            </Form.Item>
                        </Grid.Col>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}