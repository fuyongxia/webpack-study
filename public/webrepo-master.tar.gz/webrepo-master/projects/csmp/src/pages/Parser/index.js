import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Modal, Space, message } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React from 'react';
import { Filters, Page, Results, Table, Constant, confirm } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onOk: onOk, onFinish: onSave });

    function onOk() {
        setModalForm(false);
        setFilters({_updatedAt: Date.now()});
    }

    function onSave() {
        if (modalForm.type == 'add') {
            if (modalForm.data.parserId) {
                app.service.parserUpdate(modalForm.data)
                    .then(body => {
                        message.success('保存成功');
                    })
            } else {
                app.service.parserSave(modalForm.data)
                    .then(body => { 
                        setModalForm({
                            ...modalForm,
                            data: { 
                                ...modalForm.data,
                                ...body
                            }
                        });
                        message.success('保存成功');
                    })
            }
        }

        if (modalForm.type == 'update') {
            app.service.parserUpdate(modalForm.data)
                    .then(body => {
                        message.success('保存成功');
                    })
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.parserDelete)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function onStart(record) {
        return () => {
            confirm(app.service.parserStart)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function onStop(record) {
        return () => {
            confirm(app.service.parserStop)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
                <a onClick={onStart(record)}>启动</a>
                <a onClick={onStop(record)}>停止</a>
            </Space>
        )
    }

    return (
        <Page title="数据解析器管理">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="解析器名称"
                    name="parserName"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table filters={filters} service={app.service.parserList}>
                    <Table.Column title="序号" dataIndex="_index" />
                    <Table.Column title="解析器名称" dataIndex="parserName" />
                    <Table.Column title="解析器地址" dataIndex="parserIp" />
                    <Table.Column title="解析器端口" dataIndex="parserPort" />
                    <Table.Column title="在线状态" dataIndex="parserState" render={value => value ? '在线' : '离线'} />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            {modalForm && <ModalForm  {...modalFormProps} />}
        </Page>
    )
}

export default function(props) {
    return (
        <Constant.Provider>
            <Index />
        </Constant.Provider>
    )
}