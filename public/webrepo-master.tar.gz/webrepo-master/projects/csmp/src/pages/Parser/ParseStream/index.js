import { Button, Space } from 'antd';
import { useModalForm, useStyles, useTableFilters } from 'hooks';
import React, { useContext, useEffect } from 'react';
import { confirm, Constant, Table, Select, renderer } from 'ui';
import ModalForm from './ModalForm';

export default function (props) {
    const { filters, setFilters, filtersProps } = useTableFilters({ parserId: props.parserId });
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    const styles = useStyles({
        "container": {
            marginTop: 20,
        },
        "actions": {
            margin: "10px 0"
        }
    })

    useEffect(() => {
        setFilters({ 
            parserId: props.parserId, 
            _updatedAt: Date.now()
        });
    }, [ props.parserId ]);

    function onAdd(record) {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onSave() {
        if (modalForm.type == 'add') {
            app.service.parseStreamSave({parserId: props.parserId, ...modalForm.data})
                .then(body => {
                    setModalForm(false);
                    setFilters({_updatedAt: Date.now()});
                })
        }

        if (modalForm.type == 'update') {
            app.service.parseStreamUpdate(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({_updatedAt: Date.now()});
                })
        }
    }

    function onUpdate(record) {
        return () => {
            app.service.parseStreamDetail({streamId: record.streamId})
                .then(body => {
                    setModalForm({
                        type: 'update',
                        title: '编辑',
                        data: {
                            ...body
                        }
                    })
                })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.parseStreamDelete)(record).then(body => {
                setFilters({_updatedAt: Date.now()});
            })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    function parseStreamService(args) {
        if (args.parserId) {
            return app.service.parseStreamList(args);
        }
        return Promise.resolve([]);
    }

    return (
        <div className={styles.container}>
            <div className={styles.actions}>
                <Button type="primary" onClick={onAdd} disabled={!props.parserId}>新增解析流</Button>
            </div>
            <div className={styles.results}>
                <Table size="middle" bordered filters={filters} service={parseStreamService}>
                    <Table.Column title="序号" dataIndex="_index" render={_index => _index+1} />
                    <Table.Column title="解析流名称" dataIndex="streamName" />
                    <Table.Column title="解析模板" dataIndex={["template", "templateName"]} />
                    <Table.Column title="输入通道" dataIndex={["pipeline", "pipelineName"]} />
                    <Table.Column title="输出通道" dataIndex="pipelineOuts" render={value => value.map(item => item.pipeline.pipelineName).join('\n')} />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </div>
            {modalForm && <ModalForm {...modalFormProps} />}
        </div>
    )
}