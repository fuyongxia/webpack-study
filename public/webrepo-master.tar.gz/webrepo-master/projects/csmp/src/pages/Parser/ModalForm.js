import React, { useRef } from 'react';
import { Modal, Form, Row, Col, Input, Select, Button, Space, InputNumber } from 'antd';
import { Grid } from 'ui';
import ParseStream from './ParseStream';

export default function (props) {
    return (
        <Modal visible width={960} {...props} okText="关闭" onOk={props.onOk}>
            <Form {...props} >
                <Grid labelWidth="90px" gutter={16}>
                    <Grid.Row>
                        <Form.Item
                            label="解析器名称"
                            name="parserName"
                        >
                            <Input />
                        </Form.Item>
                        <></>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                            label="解析器地址"
                            name="parserIp"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="解析器端口"
                            name="parserPort"
                        >
                            <InputNumber style={{ width: '100%'}} />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row style={{textAlign: 'right'}}>
                        <Button type="primary" htmlType="submit">保存</Button>
                    </Grid.Row>
                </Grid>
            </Form>
            <ParseStream parserId={props.data.parserId} />
        </Modal>
    )
}