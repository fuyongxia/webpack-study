import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space } from 'antd';
import { useModalForm, useService, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { confirm, Constant, Filters, Page, Table, Results, renderer } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        if (modalForm.type == 'add') {
            app.service.remoteApiSave(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({ _updatedAt: Date.now() });
                })
        }

        if (modalForm.type == 'update') {
            app.service.remoteApiUpdate(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.remoteApiDelete)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="外部数据接口管理">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="接口名称"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table filters={filters} service={app.service.remoteApiList} >
                    <Table.Column title="接口名称" dataIndex="apiName" />
                    <Table.Column title="接口代码" dataIndex="apiCode"  />
                    <Table.Column title="接口地址" dataIndex="apiUrl"  />
                    <Table.Column title="接口方法" dataIndex="httpMethod"  />
                    <Table.Column title="内容格式" dataIndex="contentType"  />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            {modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}


export default function(props) {
    const constants = useService(app.service.remoteApiAttrs, {});
    return (
        <Constant.Provider value={constants}>
            <Index />
        </Constant.Provider>
    )
}