import { Form, Input, Modal } from 'antd';
import React, { useContext } from 'react';
import { Constant, Grid, Select } from 'ui';

export default function (props) {
    const constants = useContext(Constant.Context);
    return (
        <Modal width={640} visible {...props}>
            <Form {...props}>
                <Grid labelWidth="90px" gutter={16}>
                    <Grid.Row>
                        <Grid.Col offset={3} span={18}>
                            <Form.Item
                                label="接口名称"
                                name="apiName"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="接口代码"
                                name="apiCode"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="接口地址"
                                name="apiUrl"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="接口方法"
                                name="httpMethod"
                            >
                                <Select>
                                    {constants.method.map(item => (
                                        <Select.Option value={item}>{item}</Select.Option>
                                    ))}
                                </Select>
                            </Form.Item>
                            <Form.Item
                                label="请求格式"
                                name="contentType"
                            >
                                <Select>
                                    {constants.contentType.map(item => (
                                        <Select.Option value={item}>{item}</Select.Option>
                                    ))}
                                </Select>
                            </Form.Item>
                            <Form.Item
                                label="响应内容字段"
                                name="responseField"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="记录索引字段"
                                name="indexKey"
                            >
                                <Input />
                            </Form.Item>
                        </Grid.Col>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}