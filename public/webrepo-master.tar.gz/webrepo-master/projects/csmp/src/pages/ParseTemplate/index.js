import React from 'react';
import { Input, Button, Space, Modal } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { Page, Filters, Results, Table, confirm } from 'ui';
import { useTableFilters, useModalForm } from 'hooks';
import ModalForm from './ModalForm1';

export default function (props) {
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false);

    function onSave() {
        if (modalForm.type == 'add') {
            app.service.parseTemplateSave(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({_updatedAt: Date.now()});
                })
        }

        if (modalForm.type == 'update') {
            app.service.parseTemplateUpdate(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({_updatedAt: Date.now()});
                })
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {rules:[{ruleType:20}]}
        })
    }

    function onUpdate(record) {
        return () => {
            app.service.parseTemplateDetail({ templateId: record.templateId})
                .then(body => {
                    setModalForm({
                        type: 'update',
                        title: '修改',
                        data: body
                    })
        
                })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.parseTemplateDelete)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="解析模板管理">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="解析模板名称"
                    name="templateName"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="解析模板列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table filters={filters} service={app.service.parseTemplateList}>
                    <Table.Column title="解析模板名称" dataIndex="templateName"  />
                    <Table.Column title="模板编号" dataIndex="templateCode"   />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            {modalForm && <ModalForm {...modalFormProps} refreshTable={()=> setFilters({_updatedAt: Date.now()})}/>}
        </Page>
    )
}