import React, { useState } from 'react';
import { Modal, Form, Input, Select, Button, Space, Card } from 'antd';
import { useStyles } from 'hooks';
import { Grid, ScrollView } from 'ui';
import TemplateField from './TemplateField';
import EnumField from './EnumField';
import OutputField from './OutputField';

export default function (props) {
    const styles = useStyles({
        section: {
            marginTop: 12
        }
    });

    return (
        <Modal width={860} visible {...props}>
            <Form {...props}>
                <Grid labelWidth="100px" gutter={16}>
                    <Grid.Row>
                        <Form.Item
                            label="模板名称"
                            name="templateName"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="模板编号"
                            name="templateCode"
                        >
                            <Input />
                        </Form.Item>
                    </Grid.Row>
                </Grid>
                <ScrollView maxHeight={500} style={{ paddingRight: 5 }}>
                    <Card className={styles.section} type="inner" title="正则定义 regex">
                        <Form.Item noStyle name="regexs">
                            <TemplateField />
                        </Form.Item>
                    </Card>
                    <Card className={styles.section} type="inner" title="转义定义 enum">
                        <Form.Item noStyle name="enums">
                            <EnumField />
                        </Form.Item>
                    </Card>
                    <Card className={styles.section} type="inner" title="插件定义 plugin">
                        <Form.Item noStyle name="plugins">
                            <TemplateField />
                        </Form.Item>
                    </Card>
                    <Card className={styles.section} type="inner" title="临时变量定义 var">
                        <Form.Item noStyle name="variables">
                            <TemplateField />
                        </Form.Item>
                    </Card>
                    <Card className={styles.section} type="inner" title="输出字段定义 field">
                        <Form.Item noStyle name="fields">
                            <OutputField />
                        </Form.Item>
                    </Card>
                    <Card className={styles.section} type="inner" title="过滤定义 filter">
                        <Form.Item noStyle name="filters">
                            <TemplateField />
                        </Form.Item>
                    </Card>
                </ScrollView>
            </Form>
        </Modal>
    )
}