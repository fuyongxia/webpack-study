import { MinusCircleOutlined, PlusCircleOutlined } from '@ant-design/icons';
import { Form, Input, Space, Button, Checkbox } from 'antd';
import { useList } from 'hooks';
import React, { useEffect} from 'react';
import { Grid } from 'ui';

export default function (props) {
    const { list, onAdd, onRemove, onChange } = useList((props.value || []).map(item => ({
        ...item,
        hasCond: !!item.condExpress
    })));

    useEffect(() => {
        if (props.onChange) {
            props.onChange(list.map(item => ({
                ...item,
                condExpress: item.hasCond ? item.condExpress : '' 
            })));
        }
    }, [ JSON.stringify(list) ])

    return (
        <Grid labelWidth="60px">
            <Grid.Row style={{marginBottom: 10}}>
                <Button type="dashed" onClick={onAdd} style={{ width: '100%'}}>添加</Button>
            </Grid.Row>
            {list.map((item, index) => (
                <Grid.Row gutter={16}>
                    <Grid.Col span={6}>
                        <Form.Item
                            label="名称"
                        >
                            <Input value={item.defName} onChange={onChange('defName', index)} />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={11}>
                        <Form.Item
                            label="表达式"
                        >
                            <Input value={item.defExpress} onChange={onChange('defExpress', index)} />
                        </Form.Item>
                        {item.hasCond && (
                            <Form.Item
                                label="条件"
                            >
                                <Input value={item.condExpress} onChange={onChange('condExpress', index)} />
                            </Form.Item>
                        )}
                    </Grid.Col>
                    <Grid.Col span={5}>
                        <Form.Item
                            label="条件输出"
                        >
                            <Checkbox style={{marginLeft: 10}} checked={item.hasCond} onChange={e => onChange('hasCond', index)(e.target.checked)} />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={2}>
                        <Space align="center" style={{ height: 30, fontSize: 22, color: '#999' }}>
                            <MinusCircleOutlined onClick={onRemove(index)} />
                        </Space>
                    </Grid.Col>
                </Grid.Row>
            ))}
        </Grid>
    )
}