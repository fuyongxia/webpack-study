import { MinusCircleOutlined, PlusCircleOutlined } from '@ant-design/icons';
import { Form, Input, Space, Button } from 'antd';
import { useList } from 'hooks';
import React, { useEffect} from 'react';
import { Grid } from 'ui';


function SubField(props) {
    const { list, onAdd, onRemove, onChange } = useList(props.value || []);

    useEffect(() => {
        if (props.onChange) {
            props.onChange(list);
        }
    }, [ JSON.stringify(list) ])

    return (
        <Grid labelWidth="50px">
            {list.map((item, index) => (
                <Grid.Row gutter={16}>
                    <Grid.Col span={6}>
                        <Form.Item
                            label="转义值"
                        >
                            <Input value={item.originValue} onChange={onChange('originValue', index)} />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={16}>
                        <Form.Item
                            label="转义为"
                        >
                            <Input value={item.escapeValue} onChange={onChange('escapeValue', index)} />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={2}>
                        <Space align="center" style={{ height: 30, fontSize: 22, color: '#999' }}>
                            <MinusCircleOutlined onClick={onRemove(index)} />
                        </Space>
                    </Grid.Col>
                </Grid.Row>
            ))}
            <Grid.Row style={{ marginBottom: 10 }}>
                <Button type="dashed" onClick={onAdd} style={{ width: '100%' }}>添加</Button>
            </Grid.Row>
        </Grid>
    )
}

export default function (props) {
    const { list, onAdd, onRemove, onChange } = useList(props.value || []);

    useEffect(() => {
        if (props.onChange) {
            props.onChange(list);
        }
    }, [ JSON.stringify(list) ])

    return (
        <Grid labelWidth="60px">
            <Grid.Row style={{marginBottom: 10}}>
                <Button type="dashed" onClick={onAdd} style={{ width: '100%'}}>添加</Button>
            </Grid.Row>
            {list.map((item, index) => (
                <Grid.Row gutter={16}>
                    <Grid.Col span={6}>
                        <Form.Item
                            label="名称"
                        >
                            <Input value={item.defName} onChange={onChange('defName', index)} />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={16}>
                        <Form.Item
                            colon=""
                        >
                            <SubField value={item.defItems} onChange={onChange('defItems', index)} />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={2}>
                        <Space align="center" style={{ height: 30, fontSize: 22, color: '#999' }}>
                            <MinusCircleOutlined onClick={onRemove(index)} />
                        </Space>
                    </Grid.Col>
                </Grid.Row>
            ))}
        </Grid>
    )
}