import { Row, Col, Input, Modal, Select, Button, Radio, Tag, Space, message, Dropdown, Collapse, Form } from 'antd';
import { PlusOutlined, CloseCircleOutlined } from '@ant-design/icons';
// import Form from '../../components/Form';
import React, { useEffect, useState } from 'react';
import _ from 'lodash';
import { TitleIcon, Grid, ScrollView } from 'ui';

export default function FromModal(props) {
    const [parsableFieldList, setParsableFieldList] = useState([]);
    const [removableFieldList, setRemovableFieldList] = useState({});
    const [form] = Form.useForm();

    useEffect(() => {
        // form.resetFields()
        form.setFieldsValue(props.data)
    }, [props.data])


    function getAbledFields(allFields, ableFields, index) {
        ableFields = ableFields[index].map(item => {
            return allFields[item]
        })
        return ableFields

    }

    function doParse() {
        console.log(props)
        props.form.validateFields().then(data => {
            // data.rules[0].defSource = ''
            console.log(data)
            // app.service.parseTemplate(data).then(result => {

            // props.onCancel();
            // props.refreshTable();
            const index = data.rules.length;
            const { fields = [], parsableFields = [], removableFields = [] } = { fields: ['a', 'b', 'c', 'd'], parsableFields: [[], [0, 2]], removableFields: [[], [1, 3]] };
            parsableFieldList[index] = getAbledFields(fields, parsableFields, index)
            removableFieldList[index] = getAbledFields(fields, removableFields, index)
            setParsableFieldList([...parsableFieldList])
            setRemovableFieldList([...removableFieldList])




            // })
        }).catch(() => { })


    }

    function AddRule(add) {
        add({ ruleType: 20 })
    }

    function onValuesChange(data, e) {

        const key = Object.keys(data)[0];
        if (key == 'rules') {
            const rules = _.cloneDeep(props.data[key])
            const index = data[key].length - 1;
            rules[index] = Object.assign(rules[index] || {}, data[key][index])
            props.onValuesChange({ rules });
            return;
        }
        props.onValuesChange(data)
    }
    function getPanelHeader(index) {
        const rules = props.data.rules;
        const ruleTypeObj = _.find(ruleTypes, (item) => {
            return item.id == rules[index].ruleType
        }) || {}
        return `${index + 1}.${ruleTypeObj.name}`


    }
    const layout = {
        labelCol: {
            span: 6,
        },
        wrapperCol: {
            span: 18,
        },
    };
    const layout1 = {
        labelCol: {
            span: 3,
        },
        wrapperCol: {
            span: 21,
        },
    };
    const ruleTypes = [
        { id: 10, name: 'KV分隔符解析' },
        { id: 11, name: 'KV正则解析' },
        { id: 20, name: 'LogFormat解析' },
        { id: 30, name: 'JSON解析' },
        { id: 40, name: '正则式解析' },
        { id: 50, name: '地理位置解析' },
        { id: 90, name: '删除输出字段' },
        { id: 100, name: '高阶表达式解析' },
    ]


    const { data = {} } = props;
    console.log(props, 'props.data')
    console.log(parsableFieldList, 'parse', parsableFieldList.length)
    console.log(removableFieldList, 'remove')
    return (
        <Modal visible width={760}  {...props} footer={null} >
            <Form  {...layout} {...props} onValuesChange={onValuesChange} >
                <Grid.Row>
                    <Grid.Col span={12}>
                        <Form.Item label="模板名称" name='templateName' rules={[{ required: true }]}>
                            <Input />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={12}>
                        <Form.Item label="模板编号" name='templateCode' rules={[{ required: true }]}>
                            <Input />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={24}>
                        <Form.Item {...layout1} label="日志样例" name='sampleContent' rules={[{ required: true }]}>
                            <Input.TextArea rows={5} />
                        </Form.Item>
                    </Grid.Col>
                </Grid.Row>
                <TitleIcon title='规则列表' />
                <Grid.Col offset={3}>
                    <ScrollView maxHeight={500} style={{ paddingRight: 5 }}>
                        <Form.List name="rules">
                            {(fields, { add, remove }) => (
                                <>
                                    {fields.map(({ key, name, fieldKey, ...restField }, index) => {

                                        return !(data.rules[index] || {}).hidden ? (
                                            <Collapse
                                                defaultActiveKey={[key]}
                                                // onChange={(key) => { console.log(key) }}
                                                expandIconPosition={'left'}
                                                style={{ marginBottom: 15 }}
                                            >
                                                <Collapse.Panel header={getPanelHeader(index)} key={key} extra={<CloseCircleOutlined
                                                    onClick={() => {
                                                        if (fields.length == 1) return;
                                                        data.rules[index].hidden = true;
                                                        props.onValuesChange({ rules: data.rules })
                                                    }}
                                                    style={{ marginTop: 5, color: '#ff00009c' }} />}>

                                                    <Form.Item label="解析类型"
                                                        {...restField}

                                                        fieldKey={[fieldKey, 'ruleType']}
                                                        name={[name, 'ruleType']}
                                                        rules={[{ required: true }]}>
                                                        <Select>
                                                            {_.map(ruleTypes, (item, key) => {
                                                                return <Select.Option value={item.id}>{item.name}</Select.Option>
                                                            })}
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item label="来源字段"
                                                        {...restField}

                                                        fieldKey={[fieldKey, 'defSource']}
                                                        name={[name, 'defSource']}
                                                    // rules={[{ required: true }]}
                                                    >
                                                        <Select>
                                                            <Select.Option value={'source'}>原始日志</Select.Option>
                                                            {index !== 0 && _.map(data.rules[index].ruleType == 90 ? (removableFieldList[index] || _.last(removableFieldList)) : (parsableFieldList[index] || _.last(parsableFieldList)),
                                                                (item, index) => {
                                                                    return <Select.Option value={item}>{item}</Select.Option>
                                                                })}
                                                        </Select>
                                                    </Form.Item>
                                                    {(data.rules[index].ruleType == 20 || data.rules[index].ruleType == 40 || data.rules[index].ruleType == 100) && <Form.Item label={{ 20: "规则表达式", 40: "正则表达式", 100: "高阶表达式" }[data.rules[index].ruleType]}
                                                        {...restField}

                                                        fieldKey={[fieldKey, 'defExpress']}
                                                        name={[name, 'defExpress']}
                                                        rules={[{ required: true }]}>
                                                        <Input.TextArea />
                                                    </Form.Item>}
                                                    {(data.rules[index].ruleType == 11) && <Form.Item label="KEY正则表达式"
                                                        {...restField}

                                                        fieldKey={[fieldKey, 'keyRegex']}
                                                        name={[name, 'keyRegex']}
                                                        rules={[{ required: true }]}>
                                                        <Input.TextArea />
                                                    </Form.Item>}
                                                    {(data.rules[index].ruleType == 11) && <Form.Item label="VALUE正则表达式"
                                                        {...restField}

                                                        fieldKey={[fieldKey, 'valueRegex']}
                                                        name={[name, 'valueRegex']}
                                                        rules={[{ required: true }]}>
                                                        <Input.TextArea />
                                                    </Form.Item>}
                                                    {(data.rules[index].ruleType == 30 || data.rules[index].ruleType == 50) && <Form.Item label="结果字段名"
                                                        {...restField}

                                                        fieldKey={[fieldKey, 'fieldName']}
                                                        name={[name, 'fieldName']}
                                                        rules={[{ required: true }]}>
                                                        <Input.TextArea />
                                                    </Form.Item>}
                                                    {(data.rules[index].ruleType == 30) && <Form.Item label="置于顶层"
                                                        {...restField}

                                                        fieldKey={[fieldKey, 'topLevel']}
                                                        name={[name, 'topLevel']}
                                                        rules={[{ required: true }]}>
                                                        <Radio.Group>
                                                            <Radio value={true}>是</Radio>
                                                            <Radio value={false}>否</Radio>
                                                        </Radio.Group>
                                                    </Form.Item>}
                                                    {(data.rules[index].ruleType == 10) && <Form.Item label="KV分隔符"
                                                        {...restField}

                                                        fieldKey={[fieldKey, 'kvDelimiter']}
                                                        name={[name, 'kvDelimiter']}
                                                        rules={[{ required: true }]}>
                                                        <Input />
                                                    </Form.Item>}
                                                    {(data.rules[index].ruleType == 10) && <Form.Item label="VALUE去引号"
                                                        {...restField}

                                                        fieldKey={[fieldKey, 'removeQuotes']}
                                                        name={[name, 'removeQuotes']}
                                                        rules={[{ required: true }]}>
                                                        <Radio.Group>
                                                            <Radio value={true}>是</Radio>
                                                            <Radio value={false}>否</Radio>
                                                        </Radio.Group>
                                                    </Form.Item>}


                                                </Collapse.Panel>
                                            </Collapse>
                                        ) : null
                                    }
                                    )}

                                    <Button type="dashed" block onClick={() => { console.log(add); AddRule(add) }} block icon={<PlusOutlined />}>
                                        添加规则
                            </Button>

                                </>
                            )}
                        </Form.List>
                    </ScrollView>
                </Grid.Col>


                <div>
                    <Button type='primary' onClick={doParse} >解析样例</Button>
                </div>

            </Form>

        </Modal>
    )
}
