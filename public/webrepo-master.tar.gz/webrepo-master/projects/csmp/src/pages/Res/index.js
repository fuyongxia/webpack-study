import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space } from 'antd';
import { useModalForm, useService, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { confirm, Constant, Filters, Page, Table, Results, renderer, util } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({ });
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        if (modalForm.type == 'add') {
            app.service.resSave(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({ _updatedAt: Date.now() });
                })
        }

        if (modalForm.type == 'update') {
            app.service.resUpdate(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {
                authResAdditional: [
                    {
                      "authResAdditionalKey": "icon",
                      "authResAdditionalName": "图标",
                      "authResAdditionalValue": "",
                    }
                ]
            }
        })
    }

    function onAdd(record) {
        return () => {
            setModalForm({
                type: 'add',
                title: '新增',
                data: {
                    authResPid: record.authResId,
                    authResAdditional: [
                        {
                          "authResAdditionalKey": "icon",
                          "authResAdditionalName": "图标",
                          "authResAdditionalValue": "",
                        }
                    ]
                }
            })
        }
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: {
                    ...record,
                    authResAdditional: record.authResAdditional.length == 0 ? [
                        {
                          "authResAdditionalKey": "icon",
                          "authResAdditionalName": "图标",
                          "authResAdditionalValue": "",
                        }
                    ] : record.authResAdditional
                }
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.resDelete)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    return (
        <Page title="权限资源管理">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="名称"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd({ authResId: 0})}>新增</Button>
                ]}
            >
               {Table.create({
                    filters,
                    service: (args) => {
                        return app.service.resList({...args, pageSize: 0 })
                            .then(body => {
                                const root = util.denormalize(body.results || body, {
                                    id: 'authResId',
                                    pid: 'authResPid',
                                    root: {
                                        authResId: 0
                                    },
                                })
                                return root.children;
                            })
                    },
                    columns: [
                        { 
                            title: '名称',
                            dataIndex: 'authResName'
                        },
                        { 
                            title: '标识',
                            dataIndex: 'authResCode'
                        },
                        { 
                            title: '类型',
                            dataIndex: 'authResType',
                            render: renderer.enumRender({ data: constants.authResType })
                        },
                        { 
                            title: '描述',
                            dataIndex: 'authResDesc'
                        },
                        { 
                            title: '操作',
                            render: function(value, record) {
                                return (
                                    <Space>
                                        <a onClick={onAdd(record)}>新增</a>
                                        <a onClick={onUpdate(record)}>编辑</a>
                                        <a onClick={onRemove(record)}>删除</a>
                                    </Space>
                                )
                            }
                        },
                    ]
                })}
            </Results>
            {modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}


export default function(props) {
    const constants = useService(app.service.authAttrs, {});

    return (
        <Constant.Provider value={constants}>
            <Index />
        </Constant.Provider>
    )
}