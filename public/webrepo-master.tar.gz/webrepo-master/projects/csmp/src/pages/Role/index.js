import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space } from 'antd';
import { useModalForm, useService, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { confirm, Constant, Filters, Page, Table, Results, renderer } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        if (modalForm.type == 'add') {
            app.service.roleSave(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({ _updatedAt: Date.now() });
                })
        }

        if (modalForm.type == 'update') {
            app.service.roleUpdate(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.roleDelete)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    return (
        <Page title="角色管理">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="名称"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                {Table.create({
                    filters,
                    service: app.service.roleList,
                    columns: [
                        { 
                            title: '名称',
                            dataIndex: 'authRoleName'
                        },
                        { 
                            title: '标识',
                            dataIndex: 'authRoleCode'
                        },
                        { 
                            title: '描述',
                            dataIndex: 'authRoleDesc'
                        },
                        { 
                            title: '操作',
                            render: function(value, record) {
                                return (
                                    <Space>
                                        <a onClick={onUpdate(record)}>编辑</a>
                                        <a onClick={onRemove(record)}>删除</a>
                                    </Space>
                                )
                            }
                        },
                    ]
                })}
            </Results>
            {modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}


export default function(props) {
    return (
        <Constant.Provider >
            <Index />
        </Constant.Provider>
    )
}