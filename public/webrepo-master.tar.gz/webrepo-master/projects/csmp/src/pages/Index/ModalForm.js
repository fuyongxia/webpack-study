import React from 'react';
import { Modal, Form, Row, Col, Input, Select, Button, Space } from 'antd';
import { Grid } from 'ui';

export default function (props) {
    return (
        <Modal width={800} visible {...props}>
            <Form {...props}>
                <Grid labelWidth="90px" gutter={16}>
                    
                </Grid>
            </Form>
        </Modal>
    )
}