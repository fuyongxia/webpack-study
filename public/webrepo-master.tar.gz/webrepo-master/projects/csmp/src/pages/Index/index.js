import React from 'react';
import { Input, Button, Table, Space, Modal } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { Page, Filters, Results } from 'ui';
import { useTableFilters, useTableResults, useModalForm } from 'hooks';
import ModalForm from './ModalForm';

export default function (props) {
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { tableProps } = useTableResults(app.service.accessPointList, [ filters._updatedAt ], { filters })
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        if (modalForm.type == 'add') {

        }

        if (modalForm.type == 'update') {
            
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'add',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove() {
        return () => {
            Modal.config({
                title: '确认',
                conent: '确认执行所选操作？',
                onOk() {

                }
            })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="页面名称">
            <Filters>
                <Filters.Item
                    label="接入器名称"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                {Table.create({
                    filters,
                    service: app.service,
                    columns: [
                        {
                            title: '序号',
                            dataIndex: '_index'
                        },
                        {
                            title: '解析模板名称',
                            dataIndex: ''
                        },
                        {
                            title: '模板编号',
                            dataIndex: ''
                        },
                        {
                            title: '操作',
                            render: actionRender 
                        }
                    ]
                })}
            </Results>
            {modalForm && <ModalForm {...modalFormProps} />}
            
        </Page>
    )
}