import React, { useState, useEffect, useContext } from 'react';
import { Table, Constant, renderer, util } from 'ui';

export default function (props) {
    const [ results, setResults ] = useState([]);
    const [ selection, setSelection ] = useState([]);

    const constants = useContext(Constant.Context);

    useEffect(() => {
        if (props.authGrantOwnerValue) {
            app.service.grantList({ pageSize: 0, authGrantOwnerType: props.authGrantOwnerType, authGrantOwnerValue: props.authGrantOwnerValue })
                .then(body => {
                    body = body.results || body || [];
                    setSelection(body.map(item => item.authGrantTargetValue));
                })
        }
    }, [ props.authGrantOwnerValue ])

    function getSelected(id, selected) {
        const rets = {};

        function traverse(node) {
            if (!rets[node.authResId]) {
                rets[node.authResId] = node.authResId;
            }
            const children = node.children || [];
            for (let i of children) {
                rets[i.authResId] = rets[i.authResPid] + '-' + i.authResId;
                traverse(i);
            }
        }
        traverse({ authResId: "0", children: results });

        const parents = rets[id].split('-');
        const children = Object.keys(rets).filter(item => rets[item].startsWith(rets[id]));

        if (selected) {
           return parents.concat(children);
        } else {
            return children;
        }
    }

    return (
        <div>
            {Table.create({
                filters: {},
                rowKey: 'authResId',
                rowSelection: {
                    onSelect(record, selected) {
                        let keys = [];
                        if (selected) {
                            keys = _.union(selection, getSelected(record.authResId, selected));
                        } else {
                            keys = _.difference(selection, getSelected(record.authResId, selected));
                        }
                        if (props.authGrantOwnerValue) {
                            app.service.grantMerge({
                                authGrantAction: 1,
                                authGrantOwnerType: props.authGrantOwnerType,
                                authGrantOwnerValue: props.authGrantOwnerValue,
                                authGrantTargetType: 1,
                                authGrantTargetValue: keys.join(',')
                            })
                        }
                        setSelection(keys);
                    },
                    onSelectAll(selected) {
                        const keys = selected ? getSelected('0') : [];
                        if (props.authGrantOwnerValue) {
                            app.service.grantMerge({
                                authGrantAction: 1,
                                authGrantOwnerType: props.authGrantOwnerType,
                                authGrantOwnerValue: props.authGrantOwnerValue,
                                authGrantTargetType: 1,
                                authGrantTargetValue: keys.join(',')
                            })
                        }
                        setSelection(keys);
                    },
                    selectedRowKeys: selection,
                },
                service: (args) => {
                    return app.service.resList({ ...args, pageSize: 99999 })
                        .then(body => {
                            const root = util.denormalize(body.results || body, {
                                id: 'authResId',
                                pid: 'authResPid',
                                root: { authResId: 0 },
                            })
                            setResults(root.children);
                            return root.children;
                        })
                },
                columns: [
                    {
                        title: '名称',
                        dataIndex: 'authResName'
                    },
                    {
                        title: '标识',
                        dataIndex: 'authResCode'
                    },
                    {
                        title: '类型',
                        dataIndex: 'authResType',
                        render: renderer.enumRender({ data: constants.authResType })
                    },
                    {
                        title: '描述',
                        dataIndex: 'authResDesc'
                    }
                ]
            })}
        </div>
    )
}