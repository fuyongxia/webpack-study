import { Form, Input, InputNumber, Modal, Card, Tabs, Menu } from 'antd';
import React, { useContext, useState, useEffect } from 'react';
import { Constant, Grid, Select, util } from 'ui';
import ResTable from './ResTable';
import UserTable from './UserTable';

export default function (props) {
    const [ selection, setSelection ] = useState([]);
    const [ curOrg, setCurOrg ] = useState();
    const [ orgs, setOrgs ] = useState([]);

    useEffect(() => {
        return app.service.orgList({ pageSize: 99999 })
            .then(body => {
                const root = util.denormalize(body.results || body, {
                    id: 'authOrgId',
                    pid: 'authOrgPid',
                    root: {
                        authOrgId: 0
                    },
                })
                setOrgs(root.children);
                if (root.children.length) {
                    onSelect(root.children[0])();
                }
            })
    }, [])

    function onSelect(item) {
        return () => {
            setCurOrg(item);
            setSelection([item.authOrgId]);
        }
    }

    function getClassName(item) {
        if(selection.indexOf(item.authOrgId) !== -1) {
            return 'ant-menu-item-selected';
        }
        return '';
    }

    function renderOrg(items) {
        return items.map(item => {
            if (item.children && item.children.length) {
                return (
                    <Menu.SubMenu onTitleClick={onSelect(item)}  className={getClassName(item)} title={item.authOrgName}>
                        {renderOrg(item.children)}
                    </Menu.SubMenu>
                )
            } else {
                return (
                    <Menu.Item className={getClassName(item)} onClick={onSelect(item)}>{item.authOrgName}</Menu.Item>
                )
            }
        });
    }

    return (
        <Grid>
            <Grid.Row gutter={32}>
                <Grid.Col span={4}>
                    <Menu mode="inline" selectedKeys={[]}>
                        {renderOrg(orgs)}
                    </Menu>
                </Grid.Col>
                <Grid.Col span={18}>
                    <Tabs>
                        <Tabs.TabPane tab="授权到权限" key="1">
                            <ResTable authGrantOwnerType={4} authGrantOwnerValue={curOrg && curOrg.authOrgId} />
                        </Tabs.TabPane>
                        <Tabs.TabPane tab="授权到用户" key="2">
                            <UserTable filters={{ authOrgId: curOrg && curOrg.authOrgId }} />
                        </Tabs.TabPane>
                    </Tabs>
                </Grid.Col>
            </Grid.Row>
        </Grid>
    )
}