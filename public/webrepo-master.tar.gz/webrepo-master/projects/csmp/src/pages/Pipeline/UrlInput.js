import { MinusCircleOutlined, PlusCircleOutlined } from '@ant-design/icons';
import { Form, Input, Space, Button } from 'antd';
import { useList } from 'hooks';
import React, { useEffect} from 'react';
import { Grid } from 'ui';

export default function (props) {
    const { list, setList, onAdd, onRemove, onChange } = useList((props.value || []).map(item => ({
        ..._.omit(item, 'pipelineInfo'),
        ...JSON.parse(item.pipelineInfo || '{}')
    })));

    useEffect(() => {
        setList((props.value || []).map(item => ({
            ...item,
            ...JSON.parse(item.pipelineInfo || '{}')
        })));
    }, [ JSON.stringify(props.value)])

    useEffect(() => {
        if (props.onChange) {
            props.onChange(list.map(item => ({
                balanceId: item.balanceId,
                pipelineId: item.pipelineId,
                pipelineInfo: JSON.stringify(_.omit(item, ['balanceId', 'pipelineId', 'pipelineInfo']))
            })));
        }
    }, [ JSON.stringify(list) ])

    return (
        <Grid>
            {list.map((item, index) => (
                <Grid.Row gutter={16}>
                    <Grid.Col span={props.balanceStatus == 1 ? 22 : 24}>
                        <Form.Item
                            colon=""
                            label=""
                        >
                            <Input value={item.url} onChange={onChange('url', index)} />
                        </Form.Item>
                    </Grid.Col>
                    {props.balanceStatus == 1 && (
                        <Grid.Col span={2}>
                            <Space align="center" style={{ height: 30, fontSize: 22, color: '#999' }}>
                                {index == 0 && <PlusCircleOutlined onClick={onAdd} />}
                                {index !== 0 && <MinusCircleOutlined onClick={onRemove(index)} />}
                            </Space>
                        </Grid.Col>
                    )}
                </Grid.Row>
            ))}
        </Grid>
    )
}