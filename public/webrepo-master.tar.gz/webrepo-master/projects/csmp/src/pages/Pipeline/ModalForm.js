import { Form, Input, InputNumber, Radio, Modal } from 'antd';
import React, { useContext } from 'react';
import { Constant, Grid, Select } from 'ui';
import OtherInput from './OtherInput';
import UrlInput from './UrlInput';

export default function (props) {
    const { pipelineType = [] } = useContext(Constant.Context);

    function onValuesChange(data) {
        if ('pipelineType' in data) {
            data.pipelineBalances = [{}];
        }
        if ('balanceStatus' in data) {
            data.pipelineBalances = [{}];
        }
        props.onValuesChange(data);
    }

    return (
        <Modal width={640} visible {...props} >
            <Form {...props} onValuesChange={onValuesChange}>
                <Grid labelWidth="100px" gutter={16}>
                    <Grid.Row>
                        <Grid.Col span={18} offset={3}>
                            <Form.Item
                                label="通道名称"
                                name="pipelineName"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="通道类型"
                                name="pipelineType"
                            >
                                <Select data={pipelineType} />
                            </Form.Item>
                            {props.data.pipelineType == '5' && (
                                <Form.Item
                                    label="启用负载均衡"
                                    name="balanceStatus"
                                >
                                    <Radio.Group>
                                        <Radio value={1}>是</Radio>
                                        <Radio value={0}>否</Radio>
                                    </Radio.Group>
                                </Form.Item>
                            )}
                            {props.data.pipelineType !== '5' && (
                                <Form.Item noStyle name="pipelineBalances">
                                    <OtherInput pipelineType={props.data.pipelineType} />
                                </Form.Item>
                            )}
                            {props.data.pipelineType == '5' && (
                                <Form.Item label="通道地址端口"  name="pipelineBalances">
                                    <UrlInput balanceStatus={props.data.balanceStatus} pipelineType={props.data.pipelineType}  />
                                </Form.Item>
                            )}
                        </Grid.Col>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}