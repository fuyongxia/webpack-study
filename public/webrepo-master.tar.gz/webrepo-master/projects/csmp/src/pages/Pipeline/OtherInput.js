import { MinusCircleOutlined, PlusCircleOutlined } from '@ant-design/icons';
import { Form, Input, InputNumber, Space, Button } from 'antd';
import { useList } from 'hooks';
import React, { useEffect} from 'react';
import { Grid } from 'ui';

export default function (props) {
    const { list, setList, onAdd, onRemove, onChange } = useList((props.value || []).map(item => ({
        ..._.omit(item, 'pipelineInfo'),
        ...JSON.parse(item.pipelineInfo || '{}')
    })));

    useEffect(() => {
        setList((props.value || []).map(item => ({
            ...item,
            ...JSON.parse(item.pipelineInfo || '{}')
        })));
    }, [ JSON.stringify(props.value)])

    useEffect(() => {
        if (props.onChange) {
            props.onChange(list.map(item => ({
                balanceId: item.balanceId,
                pipelineId: item.pipelineId,
                pipelineInfo: JSON.stringify(_.omit(item, ['balanceId', 'pipelineId', 'pipelineInfo']))
            })));
        }
    }, [ JSON.stringify(list) ])

    const getInputProps = function(field, item, index) {
        return {
            value: item[field],
            onChange: onChange(field, index)
        }
    }
    
    return (
        <Grid labelWidth="100px">
            {list.map((item, index) => (
                <Grid.Row gutter={16}>
                    <Grid.Col span={24}>
                            {props.pipelineType == '1' && (
                                <>
                                    <Form.Item
                                        label="bootstrap"
                                    >
                                        <Input {...getInputProps('bootstrap', item, index)} />
                                    </Form.Item>
                                    <Form.Item
                                        label="concurrency"
                                    >
                                        <InputNumber {...getInputProps('concurrency', item, index)} />
                                    </Form.Item>
                                    <Form.Item
                                        label="group"
                                    >
                                        <Input {...getInputProps('group', item, index)} />
                                    </Form.Item>
                                    <Form.Item
                                        label="topic"
                                    >
                                        <Input {...getInputProps('topic', item, index)} />
                                    </Form.Item>
                                </>  
                            )}
                            {props.pipelineType == '2' && (
                                <>
                                    <Form.Item
                                        label="cluster"
                                    >
                                        <Input {...getInputProps('cluster', item, index)}/>
                                    </Form.Item>
                                    <Form.Item
                                        label="hosts"
                                    >
                                        <Input {...getInputProps('hosts', item, index)} />
                                    </Form.Item>
                                    <Form.Item
                                        label="index"
                                    >
                                        <Input {...getInputProps('index', item, index)} />
                                    </Form.Item>
                                    <Form.Item
                                        label="password"
                                    >
                                        <Input {...getInputProps('password', item, index)} />
                                    </Form.Item>
                                    <Form.Item
                                        label="username"
                                    >
                                        <Input {...getInputProps('username', item, index)}  />
                                    </Form.Item>
                                    <Form.Item
                                        label="version"
                                    >
                                        <Input {...getInputProps('version', item, index)}  />
                                    </Form.Item>
                                </>
                            )}
                            {props.pipelineType == '3' && (
                                <>
                                    <Form.Item
                                        label="url"
                                    >
                                        <Input {...getInputProps('url', item, index)}  />
                                    </Form.Item>
                                    <Form.Item
                                        label="username"
                                    >
                                        <Input {...getInputProps('username', item, index)} />
                                    </Form.Item>
                                    <Form.Item
                                        label="password"
                                    >
                                        <Input {...getInputProps('password', item, index)} />
                                    </Form.Item>
                                </>
                            )}
                            {props.pipelineType == '4' && (
                                <>
                                    <Form.Item
                                        label="contentType"
                                    >
                                        <Input {...getInputProps('contentType', item, index)}  />
                                    </Form.Item>
                                    <Form.Item
                                        label="method"
                                    >
                                        <Input {...getInputProps('method', item, index)} />
                                    </Form.Item>
                                    <Form.Item
                                        label="url"
                                    >
                                        <Input {...getInputProps('url', item, index)} />
                                    </Form.Item>
                                </>
                            )}
                    </Grid.Col>
                </Grid.Row>
            ))}
        </Grid>
    )
}