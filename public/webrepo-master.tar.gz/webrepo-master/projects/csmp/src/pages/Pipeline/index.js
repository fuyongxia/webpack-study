import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space } from 'antd';
import { useModalForm, useTableFilters, useService } from 'hooks';
import React, { useContext } from 'react';
import { confirm, Constant, Filters, Page, renderer, Results, Table } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const { pipelineType = [] } = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        if (modalForm.type == 'add') {
            app.service.pipelineSave({
                ...modalForm.data,
                pipelineBalances: modalForm.data.pipelineBalances.filter(item => item.pipelineInfo !== '{}')
            })
                .then(body => {
                    setModalForm(false);
                    setFilters({_updatedAt: Date.now()});
                })
        }

        if (modalForm.type == 'update') {
            console.log(modalForm.data);
            app.service.pipelineUpdate({
                ...modalForm.data,
                pipelineBalances: modalForm.data.pipelineBalances.filter(item => item.pipelineInfo !== '{}')
            })
                .then(body => {
                    setModalForm(false);
                    setFilters({_updatedAt: Date.now()});
                })
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.pipelineDelete)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="数据通道管理">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="数据通道名称"
                    name="pipelineName"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="数据通道列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table filters={filters} service={app.service.pipelineList}>
                    <Table.Column title="通道名称" dataIndex="pipelineName" />
                    <Table.Column title="通道类型" dataIndex="pipelineType" render={renderer.enumRender({ data: pipelineType })} />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            {modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function(props) {
    const constants = useService(app.service.pipelineAttrs, {});
    return (
        <Constant.Provider value={constants}>
            <Index />
        </Constant.Provider>
    )
}