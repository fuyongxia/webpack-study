import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space } from 'antd';
import { useModalForm, useService, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { confirm, Constant, renderer, Table, Filters, Page, Results } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const { accessPointStatus, accessPointType } = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        if (modalForm.type == 'add') {
            app.service.accessPointSave(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({_updatedAt: Date.now()});
                })
        }

        if (modalForm.type == 'update') {
            app.service.accessPointUpdate(modalForm.data)
                .then(body => {
                    setModalForm(false);
                    setFilters({_updatedAt: Date.now()});
                })
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.accessPointDelete)(record).then(body => {
                setFilters({_updatedAt: Date.now()});
            })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    console.log(accessPointType, accessPointStatus);

    return (
        <Page title="接入点管理">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="接入点名称"
                    name="pointName"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="接入点列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table filters={filters} service={app.service.accessPointList}>
                    <Table.Column title="接入器名称" dataIndex="access" render={value=> value && value.accessName} />
                    <Table.Column title="接入点名称" dataIndex="pointName" />
                    <Table.Column title="类型" dataIndex="pointType" render={renderer.enumRender({ data: accessPointType })} />
                    <Table.Column title="路径" dataIndex="baseDir" />
                    <Table.Column title="状态" dataIndex="pointStatus"  render={renderer.enumRender({ data: accessPointStatus})} />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            {modalForm && <ModalForm  {...modalFormProps} />}
        </Page>
    )
}

export default function(props) {
    const constants = useService(app.service.accessAttrs, {});

    return (
        <Constant.Provider value={constants}>
            <Index />
        </Constant.Provider>
    )
}