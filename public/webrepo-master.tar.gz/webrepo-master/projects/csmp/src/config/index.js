export default {
    request: {
        onRequest: function (req, onRequest) {
            req.headers.Authorization = 'Bearer ' + app.storage.get('access_token');
            return onRequest(req);
        },
        onResponse: function (res) {
            if (res.status == 401) {
                return res.json()
                    .then(result => {
                        return Promise.reject(result);
                    })
            }

            if (res.status != 200) {
                return Promise.reject({ code: res.status, message: res.statusText });
            }

            return res.json()
                .then(result => {
                    const { code, body, message } = result;
                    if (code == null) {
                        return result;
                    }
                    if (code === '000000') {
                        return body;
                    }
                    return Promise.reject({ code, body, message });
                });
        }
    },

    service: {
        items: {
            accessList: 'POST /api/v1/manage/access/list',

            accessPointList: 'POST /api/v1/manage/access/point/list',
            accessPointSave: 'POST /api/v1/manage/access/point/save',
            accessPointUpdate: 'POST /api/v1/manage/access/point/update',
            accessPointDetail: 'POST /api/v1/manage/access/point/detail',
            accessPointDelete: 'POST /api/v1/manage/access/point/delete',

            accessAttrs: 'POST /api/v1/manage/access/attrs',
            accessDetail: 'POST /api/v1/manage/access/detail',
            accessList: 'POST /api/v1/manage/access/list',
            accessSave: 'POST /api/v1/manage/access/save',
            accessUpdate: 'POST /api/v1/manage/access/update',
            accessDelete: 'POST /api/v1/manage/access/delete',

            pipelineAttrs: 'POST /api/v1/manage/pipeline/attrs',
            pipelineList: 'POST /api/v1/manage/pipeline/list',
            pipelineSave: 'POST /api/v1/manage/pipeline/save',
            pipelineUpdate: 'POST /api/v1/manage/pipeline/update',
            pipelineDelete: 'POST /api/v1/manage/pipeline/delete',
            pipelineDetail: 'POST /api/v1/manage/pipeline/detail',

            parseTemplateAttrs: 'POST /api/v1/manage/parse/template/attrs',
            parseTemplateList: 'POST /api/v1/manage/parse/template/list',
            parseTemplateSave: 'POST /api/v1/manage/parse/template/save',
            parseTemplateUpdate: 'POST /api/v1/manage/parse/template/update',
            parseTemplateDelete: 'POST /api/v1/manage/parse/template/delete',
            parseTemplateDetail: 'POST /api/v1/manage/parse/template/detail',
            parseTemplate:'POST api/v1/manage/parse/template/parse',


            parseStreamList: 'POST /api/v1/manage/parse/stream/list',
            parseStreamSave: 'POST /api/v1/manage/parse/stream/save',
            parseStreamUpdate: 'POST /api/v1/manage/parse/stream/update',
            parseStreamDelete: 'POST /api/v1/manage/parse/stream/delete',
            parseStreamDetail: 'POST /api/v1/manage/parse/stream/detail',

            parserList: 'POST /api/v1/manage/parser/list',
            parserSave: 'POST /api/v1/manage/parser/save',
            parserUpdate: 'POST /api/v1/manage/parser/update',
            parserDelete: 'POST /api/v1/manage/parser/delete',
            parserDetail: 'POST /api/v1/manage/parser/detail',
            parserStart: 'POST /api/v1/manage/parser/start',
            parserStop: 'POST /api/v1/manage/parser/stop',

            remoteApiAttrs: 'POST /api/v1/manage/remote/api/attrs',
            remoteApiList: 'POST /api/v1/manage/remote/api/list',
            remoteApiSave: 'POST /api/v1/manage/remote/api/save',
            remoteApiUpdate: 'POST /api/v1/manage/remote/api/update',
            remoteApiDelete: 'POST /api/v1/manage/remote/api/delete',
            remoteApiDetail: 'POST /api/v1/manage/remote/api/detail',
           
            orgList: `POST ${LOGIN_API_PREFIX}auth/org/list/${LOGIN_USER_SCOPE}`,
            orgSave: `POST ${LOGIN_API_PREFIX}auth/org/save/${LOGIN_USER_SCOPE}`,
            orgUpdate: `POST ${LOGIN_API_PREFIX}auth/org/update/${LOGIN_USER_SCOPE}`,
            orgDelete: `POST ${LOGIN_API_PREFIX}auth/org/delete/${LOGIN_USER_SCOPE}`,

            userList: `POST ${LOGIN_API_PREFIX}auth/user/list/${LOGIN_USER_SCOPE}`,
            userSave: `POST ${LOGIN_API_PREFIX}auth/user/save/${LOGIN_USER_SCOPE}`,
            userUpdate: `POST ${LOGIN_API_PREFIX}auth/user/update/${LOGIN_USER_SCOPE}`,
            userDelete: `POST ${LOGIN_API_PREFIX}auth/user/delete/${LOGIN_USER_SCOPE}`,
            userPassword: `POST ${LOGIN_API_PREFIX}auth/user/update/password/${LOGIN_USER_SCOPE}`,

            roleList: `POST ${LOGIN_API_PREFIX}auth/role/list/${LOGIN_RESOURCE_SCOPE}`,
            roleSave: `POST ${LOGIN_API_PREFIX}auth/role/save/${LOGIN_RESOURCE_SCOPE}`,
            roleUpdate: `POST ${LOGIN_API_PREFIX}auth/role/update/${LOGIN_RESOURCE_SCOPE}`,
            roleDelete: `POST ${LOGIN_API_PREFIX}auth/role/delete/${LOGIN_RESOURCE_SCOPE}`,

            roleUserSave: `POST ${LOGIN_API_PREFIX}auth/role/user/relation/save/${LOGIN_RESOURCE_SCOPE}`,
            roleUserDelete: `POST ${LOGIN_API_PREFIX}auth/role/user/relation/delete/${LOGIN_RESOURCE_SCOPE}`,

            orgUserSave: `POST ${LOGIN_API_PREFIX}auth/org/user/relation/save/${LOGIN_USER_SCOPE}`,
            orgUserDelete: `POST ${LOGIN_API_PREFIX}auth/org/user/relation/delete/${LOGIN_USER_SCOPE}`,

            resList: `POST ${LOGIN_API_PREFIX}auth/res/list/${LOGIN_RESOURCE_SCOPE}`,
            resSave: `POST ${LOGIN_API_PREFIX}auth/res/save/${LOGIN_RESOURCE_SCOPE}`,
            resUpdate: `POST ${LOGIN_API_PREFIX}auth/res/update/${LOGIN_RESOURCE_SCOPE}`,
            resDelete: `POST ${LOGIN_API_PREFIX}auth/res/delete/${LOGIN_RESOURCE_SCOPE}`,

            authAttrs: `POST ${LOGIN_API_PREFIX}auth/common/attrs`,

            grantList: `POST ${LOGIN_API_PREFIX}auth/grant/list`,
            grantSave: `POST ${LOGIN_API_PREFIX}auth/grant/save`,
            grantUpdate: `POST ${LOGIN_API_PREFIX}auth/grant/update`,
            grantMerge: `POST ${LOGIN_API_PREFIX}auth/grant/merge`,
            grantDelete: `POST ${LOGIN_API_PREFIX}auth/grant/delete`,
           
            
            getUserInfo: (data, options) => {
                return app.request.post(`${LOGIN_DOMAIN}/api/v1/authorization/oidc/userinfo?access-origin=${LOGIN_ACCESS_ORIGIN}`, data, options) 
            },

            getGrantResource: (data, options) => {
                return app.request.post(`${LOGIN_DOMAIN}/api/v1/authorization/oidc/grant/resource?access-origin=${LOGIN_ACCESS_ORIGIN}`, data, options)
            }
        }
    }
}