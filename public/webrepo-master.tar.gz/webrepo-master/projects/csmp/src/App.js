import React from "react";
import Main from './layouts/Main';
import { HashRouter as Router, Switch, Route, Redirect } from "react-router-dom";
import Access from 'access';
import AccessPoinit from 'access-point';
import Pipeline from 'pipeline';
import ParseTempalte from 'parse-template';
import Parser from 'parser';
import RemoteApi from 'remote-api';
import OrgPage from './pages/Org';
import RolePage from './pages/Role';
import UserPage from './pages/User';
import ResPage from './pages/Res';
import GrantPage from './pages/Grant';
import CallbackPage from './pages/Callback';

export default function (props) {
    return (
        <>
            <Router>
                <Switch>
                    <Route exact path="/">
                        <Redirect to="/access" />
                    </Route>
                    <Route path="/callback">
                        <CallbackPage />
                    </Route>
                    <Route path="/access_point">
                        <Main><AccessPoinit /></Main>
                    </Route>
                    <Route path="/access">
                        <Main><Access /></Main>
                    </Route>
                    <Route path="/pipeline">
                        <Main><Pipeline /></Main>
                    </Route>
                    <Route path="/parse_template">
                        <Main><ParseTempalte /></Main>
                    </Route>
                    <Route path="/parser">
                        <Main><Parser /></Main>
                    </Route>
                    <Route path="/remote_api">
                        <Main><RemoteApi /></Main>
                    </Route>
                    <Route path="/auth/org">
                        <Main><OrgPage /></Main>
                    </Route>
                    <Route path="/auth/role">
                        <Main><RolePage /></Main>
                    </Route>
                    <Route path="/auth/user">
                        <Main><UserPage /></Main>
                    </Route>
                    <Route path="/auth/res">
                        <Main><ResPage /></Main>
                    </Route>
                    <Route path="/auth/grant">
                        <Main><GrantPage /></Main>
                    </Route>
                </Switch>
            </Router>
        </>
    )
}