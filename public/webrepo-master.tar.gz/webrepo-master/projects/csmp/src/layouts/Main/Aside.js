import { MenuUnfoldOutlined } from '@ant-design/icons';
import { Layout, Menu } from 'antd';
import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import { util } from 'ui';
import style from './layout.module.less';

export default function () {
    const [ items, setItems ] = useState([]);
    const [ collapsed, setCollapsed ] = React.useState(false);

    useEffect(() => {
        app.service.getGrantResource({ authResType: 1, pageSize: 0 })
            .then(body => {
                body = body.filter(item => item.type == 'resource').map(item => ({ ...JSON.parse(item.data) })).filter(item => item.authResType == 1);
                const root = util.denormalize(body, {
                    id: 'authResId',
                    pid: 'authResPid',
                    root: { authResId: 0 },
                })
                setItems(root.children || []);
            })
    }, []);

    function buildMenuItem(item) {
        if (item.children) {
            return (
                <Menu.SubMenu title={item.authResName}>
                    {item.children.map(buildMenuItem)}
                </Menu.SubMenu>
            )
        } else {
            return (
                <Menu.Item >
                    <Link to={item.authResCode}>{item.authResName}</Link>
                </Menu.Item>
            )
        }
    }

    return (
        <>
            <div
                style={{
                    width: collapsed ? 48 : 208,
                    overflow: 'hidden',
                    flex: `0 0 ${collapsed ? 48 : 208}px`,
                    maxWidth: collapsed ? 48 : 208,
                    minWidth: collapsed ? 48 : 208,
                    transition: `background-color 0.3s, min-width 0.3s, max-width 0.3s cubic-bezier(0.645, 0.045, 0.355, 1)`,
                }}
            >
            </div>
            <Layout.Sider
                width={208}
                className={style.aside}
                theme="light" 
                trigger={null}
                collapsible
                collapsed={collapsed}
                collapsedWidth={48}
                onCollapse = {(collapse) => {
                    setCollapsed(collapse);
                }}
            >
                <div className={style.menu} >
                    <Menu
                        mode="inline"
                        inlineIndent={16}
                        defaultSelectedKeys={['1']}
                        defaultOpenKeys={['sub1']}
                        style={{ height: '100%', borderRight: 0 }}
                    >
                            {items.map(buildMenuItem)}
                    </Menu>
                </div>
                <div className={style.links}>
                    <Menu
                        theme={"light"}
                        inlineIndent={16}
                        selectedKeys={[]}
                        openKeys={[]}
                        mode="inline"
                    >
                        <Menu.Item 
                            className={style.collapse}
                            title={false}
                            onClick={() => {
                                setCollapsed(!collapsed);
                            }}
                        >
                            <MenuUnfoldOutlined />  &nbsp;
                        </Menu.Item>
                    </Menu>
                </div>
            </Layout.Sider>
        </>
    )
}