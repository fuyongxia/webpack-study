import React, { useState, useEffect } from 'react';

const Context = React.createContext({});

function Provider(props) {
    const [ value, setValue ] = useState(props.value || {});

    useEffect(() => {
        setValue({
            ...value,
            ...props.value
        })
    }, [ props.value ])

    return (
        <Context.Provider value={value}>
            {props.children}
        </Context.Provider>
    )
}

export default {
    Context: Context,
    Provider: Provider
}