import React from 'react';
export default function (props){
    return (
    <div>
        <span style={{display:'inline-block', width:5,height:15,background:'orange',marginRight:10}}></span>
        <span style={{position:'relative',top:-2}}>{props.title}</span>
        </div>
    )

}
