import React from 'react';
import moment from 'moment';
import { Space } from 'antd';

function dateRender(format = 'YYYY/MM/DD HH:mm:ss') {
    return (value) => {
        return value && moment(value).format(format)
    }
}

function enumRender(options) {
    function Text(props) {
        const { value, labelField, valueField, data } = props;

        const matched = data.find(item => (
            item[valueField] == value
        ));

        if (matched) {
            return matched[labelField];
        }

        return ''
    }

    Text.defaultProps = {
        data: [],
        labelField: 'name',
        valueField: 'value',
    }

    return (value) => {
        return (
            <Text value={value} {...options} />
        )
    }
}



function actionRender(items) {
    return (value, record) => {
        return (
            <Space>
                {items.map(item => (
                    <a onClick={item.action(record)}>{item.title}</a>
                ))}
            </Space>
        )
    }
}

function ipRender() {
    return (ips) => {
        return (
            <pre style={{fontSize: 14, lineHeight: 1.5}}>
                {(ips || '').split(',').join('\n')}
            </pre>
        )
    }
}

export default { dateRender, enumRender, actionRender, ipRender };