import React, { useState, useEffect, useRef } from 'react';
import { Form } from 'antd';
import jss from './jss';
import _ from 'lodash'

function useConstructor(callback = ()=> {}) {
    const inited = useRef(false);
    if (!inited.current) {
        callback();
        inited.current = true;
    }
} 

function useStyles(styleSheet, deps) {
    const sheetRef = useRef(null);
    const [ inited, setInited ] = useState(false);

    if (!inited) {
        sheetRef.current = jss
            .createStyleSheet(styleSheet)
            .attach();
        setInited(true);
    }

    useEffect(() => {
        sheetRef.current.update(deps);
        return () => {
            sheetRef.current.detach();
        }
    }, deps ? [deps] : []);

    return sheetRef.current.classes;
}

function useValue({ value, onChange }) {
    const [ state, setState ] = useState(value);

    useEffect(() => {
        setState(value);
    }, [ value ])

    return [
        state,
        function(args) {
            setState(args);
            if (onChange) {
                onChange(args);
            }
        }
    ]
}

function useList(initialValues) {
    const [ list, setList ] = useState(initialValues);

    return {
        list,
        setList,
        onAdd() {
            setList([{}].concat(list))
        },
        onRemove(index) {
            return () => {
                const copy = list.slice();
                copy.splice(index, 1);
                setList(copy);
            }
        },
        onChange(field, index) {
            return (e) => {
                const copy = list.slice();
                copy[index][field] = e.target ? e.target.value : e;
                setList(copy);
            } 
        }
    }
}

function useService(service, params) {
    const [ data, setData ] = useState({});

    useEffect(() => {
        service(params).then(body => {
            setData(body);
        })
    }, [ JSON.stringify(params) ]);

    return data;
}

function useTableFilters(initState, options) {
    const [form] = Form.useForm();
    const [filters, setFilters] = useState(initState);

    const updateFilters = updatedValues => {
        form.setFieldsValue(updatedValues);
        setFilters(prevState => ({
            ...prevState,
            ...updatedValues
        }))
    };

    return {
        filters,
        setFilters: updateFilters,
        filtersProps: {
            form: form,
            initialValues: filters,
            onValuesChange: updateFilters,
            onFinish: () => {
                setFilters({ ...filters, _updatedAt: Date.now() });
            },
            ...options
        }
    }
}

function useTableResults(service, deps = [], options = {}) {
    const [props, setProps] = useState(options);

    function setTable(args) {
        setProps(prevProps => {
            return { ...prevProps, ...args }
        })
    }

    function fetchData(params) {
        setTable({ loading: true });
        service(params).then(body => {
            body = body || [];
            if (body.length) {
                setTable({
                    loading: false,
                    dataSource: body
                })
            } else {
                setTable({
                    loading: false,
                    pagination: {
                        ...props.pagination,
                        current: body.pageNo,
                        pageSize: body.pageSize,
                        total: body.totalCount
                    },
                    dataSource: ( body.results || []).map((item, index) => ({
                        _index: (body.pageNo - 1)*body.pageSize + index + 1,
                        ...item
                    }))
                })
            }
        }).catch(error => {
            setTable({
                loading: false
            })
            throw error;
        })
    }

    useEffect(() => {
        service && fetchData(options.filters);
    }, deps);

    return {
        table: props,
        setTable: setTable,
        tableProps: {
            ...props,
            onChange(pagination, filters, sorter, extra) {
                if (extra.action == 'paginate') {
                    service && fetchData({
                        ...options.filters,
                        pageNum: pagination.current,
                        pageSize: pagination.pageSize
                    })
                }
                if (props.onChange) {
                    props.onChange(pagination, filters, sorter, extra)
                }
            }
        }
    }
}

function useModalForm(state, options = {}) {
    const [form] = Form.useForm();
    const [modalForm, setModalForm] = useState(state);

    useEffect(() => {
        if (modalForm) {
            form.resetFields();
        }
    }, [Boolean(modalForm)])

    const defaultOptions = {
        form,
        initialValues: modalForm.data,
        onOk() {
            form.submit();
        },
        onCancel() {
            setModalForm(false);
        },
        onValuesChange(data) {
            
            if (modalForm.type == 'view') {
                form.setFieldsValue(modalForm.data);
                return;
            }
            
            form.setFieldsValue(data);
            setModalForm({
                ...modalForm,
                data: {
                    ...modalForm.data,
                    ...data
                }
            })
        },
        footer: modalForm.type == 'view' ? null : undefined
    }

    return {
        modalForm,
        setModalForm,
        modalFormProps: {
            ...modalForm,
            ...defaultOptions,
            ...options
        }
    }
}

export { useConstructor, useValue, useList, useStyles, useService, useTableFilters, useTableResults, useModalForm };