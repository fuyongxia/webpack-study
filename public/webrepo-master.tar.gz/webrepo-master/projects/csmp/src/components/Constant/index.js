import React, { useState, useEffect } from 'react';

const Context = React.createContext({});

function Provider(props) {
    const [ value, setValue ] = useState(props.value || {});

    useEffect(() => {
        if (props.service) {
            props.service(props.params).then(body => {
                setValue({
                    ...value,
                    ...body
                })
            })
        }
    }, [])

    return (
        <Context.Provider value={value}>
            {props.children}
        </Context.Provider>
    )
}

export default {
    Context: Context,
    Provider: Provider
}