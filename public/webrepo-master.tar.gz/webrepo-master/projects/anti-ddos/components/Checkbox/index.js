import React from 'react';
import Adapter from '@sbtd/adapter';
import { Checkbox as AntCheckbox } from 'antd';

function Checkbox(props) {
    function parse(value) {
        return value === props.trueValue;
    }

    function valueOf(e) {
        return e.target.checked ? props.trueValue: props.falseValue
    }

    return (
        <Adapter valueProp="checked" parse={parse} valueOf={valueOf} value={props.value} onChange={props.onChange} >
            <AntCheckbox {...props} />
        </Adapter>
    )
}

Checkbox.defaultProps = {
    trueValue: 'ON',
    falseValue: 'OFF'
}

export default Checkbox;