import React, { useEffect, useState } from 'react';
import { Select as AntSelect } from 'antd';

function Select(props) {
    const { service, params, fieldPath, labelField, valueField } = props;
    const [loading, setLoading] = useState(false);
    const [options, setOptions] = useState([]);

    useEffect(() => {
        if (service) {
            setLoading(true);
            service(params).then(body => {
                body = body[fieldPath] || body;
                setOptions(body);
                setLoading(false);
            }).catch(error => {
                setLoading(false);
                throw error;
            })
        }
    }, [JSON.stringify(params)])

    return (
        <AntSelect loading={loading} {...props} >
            {options.map(item => (
                <AntSelect.Option value={item[valueField]} {...item}>{item[labelField]}</AntSelect.Option>
            ))}
            {props.children}
        </AntSelect>
    )
}

Select.Option = AntSelect.Option;
Select.OptGroup = AntSelect.OptGroup;

Select.defaultProps = {
    fieldPath: 'content',
    labelField: 'label',
    valueField: 'value',
}

export default Select;