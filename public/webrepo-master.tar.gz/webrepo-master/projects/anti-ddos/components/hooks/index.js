import { useState, useEffect, useRef } from 'react';
import { Form } from 'antd';
import jss from './jss';

function useConstructor(callback = ()=> {}) {
    const inited = useRef(false);
    if (!inited.current) {
        callback();
        inited.current = true;
    }
}

function useStyles(styleSheet, deps) {
    const sheetRef = useRef(null);

    useConstructor(() => {
        sheetRef.current = jss
            .createStyleSheet(styleSheet)
            .attach();
    })

    useEffect(() => {
        sheetRef.current.update(deps);
        return () => {
            sheetRef.current.detach();
        }
    }, [JSON.stringify(deps)]);

    return sheetRef.current.classes;
}

function useService(api, params = {}) {
    const [ data, setData ] = useState();

    useEffect(() => {
        api(params)
            .then(body => {
                setData(body);
            })
    }, [ JSON.stringify(params)] );

    return data;
}

function useValue({ value, onChange }) {
    const [ val, setVal ] = useState(value);

    useEffect(() => {
        setVal(value);
    }, [ JSON.stringify(value)])

    return [
        val,
        function(args) {
            setVal(args);
            onChange && onChange(args);
        }
    ]
}

function useFilterForm(state, options) {
    const [ form ] = Form.useForm();
    const [filterForm, setFilterForm] = useState(state);

    return {
        filterForm,
        setFilterForm,
        filterFormProps: {
            form,
            initialValues: filterForm,
            onValuesChange: data => {
                form.setFieldsValue(data);
                setFilterForm({
                    ...filterForm,
                    ...data
                });
            },
            onFinish: () => {
                setFilterForm({ ...filterForm, _updatedAt: Date.now() });
            },
            ...options
        }
    }
}

function useModalForm(state, options = {}) {
    const [form] = Form.useForm();
    const [modalForm, setModalForm] = useState(state);

    useEffect(() => {
        if (modalForm) {
            form.resetFields();
        }
    }, [Boolean(modalForm)])

    const defaultOptions = {
        form,
        initialValues: modalForm.data,
        onOk() {
            form.submit();
        },
        onCancel() {
            setModalForm(false);
        },
        onValuesChange(data) {
            form.setFieldsValue(data);
            setModalForm({
                ...modalForm,
                data: {
                    ...modalForm.data,
                    ...data
                }
            })
        },
        maskClosable: false
    }

    return {
        modalForm,
        setModalForm,
        modalFormProps: {
            ...modalForm,
            ...defaultOptions,
            ...options
        }
    }
}

function useTable(service, deps = [], options = {}) {
    const [props, setProps] = useState(options);

    function setTable(args) {
        setProps({ ...props, ...args })
    }

    function fetchData(params) {
        setTable({ loading: true });
        service(params).then(body => {
            body = body || [];
            if (body.length) {
                setTable({
                    loading: false,
                    dataSource: body
                })
            } else {
                setTable({
                    loading: false,
                    pagination: {
                        ...props.pagination,
                        current: body.pageNum,
                        pageSize: body.pageSize,
                        total: body.recordTotal,
                        showTotal: (total, range) => `共 ${total} 条记录`
                    },
                    dataSource: body.content || []
                })
            }
        }).catch(error => {
            setTable({
                loading: false
            })
            throw error;
        })
    }

    useEffect(() => {
        fetchData(props.filters);
    }, deps);

    return {
        setTable,
        tableProps: {
            ...props,
            onChange(pagination, filters, sorter, extra) {
                if (extra.action == 'paginate') {
                    fetchData({
                        ...props.filters,
                        pageNum: pagination.current,
                        pageSize: pagination.pageSize
                    })
                }
                if (props.onChange) {
                    props.onChange(pagination, filters, sorter, extra)
                }
            }
        } 
    }
}

export { useConstructor, useStyles, useValue, useService, useTable, useFilterForm, useModalForm };