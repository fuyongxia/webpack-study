import "core-js/stable";
import "regenerator-runtime/runtime";
import React from "react";
import ReactDOM from "react-dom";
import angela from 'angela';
import { ConfigProvider, message, Select } from 'antd';
import zhCN from 'antd/lib/locale/zh_CN';
import App from "./App";
import Config from './config';
import './style.less';

global.app = angela(Config);

app.error(error => {
  if (error.code == '200010' || error.code == '200005') {
    app.storage.remove('access_token');
    location.href = app.config.loginUrl;
  } else {
    console.error(error.message);
    if (error.code) {
      message.error(error.message);
    }
  }
})

ReactDOM.render(
  <ConfigProvider locale={zhCN} componentSize="middle" >
    <App />
  </ConfigProvider>,
  document.getElementById("root")
);