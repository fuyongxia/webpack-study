import { Button, Card, Form, InputNumber, message, Radio, Select, Space } from 'antd';
import React, { useEffect, useRef, useState, useContext } from 'react';
import { Route, Switch } from "react-router-dom";
import { Constant, Grid, Page } from 'ui';
import FilterCondition from './FilterCondition';

function Index(props) {
    const constants = useContext(Constant.Context);
    const formRef = useRef();
    const [ data, setData ] = useState({});

    useEffect(() => {
        app.service.storageView()
            .then(body => {
                if (!body.filterConditions || body.filterConditions.length == 0) {
                    body.filterConditions = [{}]
                }
                setData(body);
                formRef.current.setFieldsValue(body);
            })
    }, [])

    const radioStyle = {
        display: 'block',
        height: '30px',
        lineHeight: '30px',
    };

    function onFinish() {
        app.service.storageEdit(data)
            .then(body => {
                message.success('保存成功');
            })
    }

    function onValuesChange(changedData) {
        setData({
            ...data,
            ...changedData
        })
    }

    return (
        <Page title="存储策略">
            <Form ref={formRef} onValuesChange={onValuesChange} onFinish={onFinish}>
                <Card title="攻击告警存储策略">
                    <Grid>
                        <Grid.Row>
                            <Grid.Col span={12} offset={3}>
                                <Form.Item noStyle name="alarmSelectType">
                                    <Radio.Group>
                                        <Radio value="DEFAULT" style={radioStyle}>默认存储30天</Radio>
                                        <Radio value="DEFINED" style={radioStyle}>自定义攻击告警存储时间</Radio>
                                    </Radio.Group>
                                </Form.Item>
                            </Grid.Col>
                        </Grid.Row>
                        <Grid.Row style={{ marginTop: 16 }}>
                            <Grid.Col span={12} offset={4}>
                                <Form.Item
                                    label="低级别告警"
                                >
                                    <div style={{ display: 'flex' }}>
                                        <Form.Item noStyle name="lowValue"><InputNumber  style={{ flex: 1 }} /></Form.Item>
                                        <Form.Item noStyle name="lowUnit">
                                            <Select style={{ width: 120 }}>
                                                <Select.Option value="DAY">天</Select.Option>
                                                <Select.Option value="WEEK">周</Select.Option>
                                                <Select.Option value="MONTH">月</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </div>
                                </Form.Item>
                                <Form.Item
                                    label="中级别告警"
                                >
                                    <div style={{ display: 'flex' }}>
                                        <Form.Item noStyle name="middleValue"><InputNumber  style={{ flex: 1 }} /></Form.Item>
                                        <Form.Item noStyle name="middleUnit">
                                            <Select style={{ width: 120 }}>
                                                <Select.Option value="DAY">天</Select.Option>
                                                <Select.Option value="WEEK">周</Select.Option>
                                                <Select.Option value="MONTH">月</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </div>
                                </Form.Item>
                                <Form.Item
                                    label="高级别告警"
                                >
                                    <div style={{ display: 'flex' }}>
                                        <Form.Item noStyle name="highValue"><InputNumber  style={{ flex: 1 }} /></Form.Item>
                                        <Form.Item noStyle name="highUnit">
                                            <Select style={{ width: 120 }}>
                                                <Select.Option value="DAY">天</Select.Option>
                                                <Select.Option value="WEEK">周</Select.Option>
                                                <Select.Option value="MONTH">月</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </div>
                                </Form.Item>
                            </Grid.Col>
                        </Grid.Row>
                    </Grid>
                </Card>
                <Card title="原始Flow存储策略" style={{ marginTop: 16 }}>
                    <Grid>
                        <Grid.Row>
                            <Grid.Col span={12} offset={3}>
                                <Form.Item noStyle name="flowSelectType">
                                    <Radio.Group>
                                        <Radio value="DEFAULT" style={radioStyle}>默认存储30天</Radio>
                                        <Radio value="DEFINED" style={radioStyle}>自定义原始Flow存储策略</Radio>
                                    </Radio.Group>
                                </Form.Item>
                            </Grid.Col>
                        </Grid.Row>
                        <Grid.Row style={{ marginTop: 16 }}>
                            <Grid.Col span={12} offset={4}>
                                <Form.Item
                                    label="存储时长"
                                >
                                    <div style={{ display: 'flex' }}>
                                        <Form.Item noStyle name="storageValue"><InputNumber  style={{ flex: 1 }} /></Form.Item>
                                        <Form.Item noStyle name="storageUnit">
                                            <Select style={{ width: 120 }}>
                                                <Select.Option value="DAY">天</Select.Option>
                                                <Select.Option value="WEEK">周</Select.Option>
                                                <Select.Option value="MONTH">月</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </div>
                                </Form.Item>
                                <Form.Item
                                    label="存储前采样"
                                    name="sampleValue"
                                >
                                    <InputNumber style={{width: '100%'}} />
                                </Form.Item>
                                <Form.Item
                                    label="存储前过滤"
                                    name="filterConditions"
                                >
                                    <FilterCondition />
                                </Form.Item>
                            </Grid.Col>
                        </Grid.Row>
                    </Grid>
                </Card>
                <Card title="流量分析方案数据存储策略" style={{ marginTop: 16 }}>
                    <Grid>
                        <Grid.Row>
                            <Grid.Col span={12} offset={3}>
                                <Form.Item noStyle name="flowPlanSelectType">
                                    <Radio.Group>
                                        <Radio value="DEFAULT" style={radioStyle}>默认存储30天</Radio>
                                        <Radio value="DEFINED" style={radioStyle}>自定义流量分析方案存储时间</Radio>
                                    </Radio.Group>
                                </Form.Item>
                            </Grid.Col>
                        </Grid.Row>
                        <Grid.Row style={{ marginTop: 16 }}>
                            <Grid.Col span={12} offset={4}>
                                <Form.Item
                                    label="存储时长"
                                >
                                    <div style={{ display: 'flex' }}>
                                        <Form.Item noStyle name="flowPlanStorageValue"><InputNumber  style={{ flex: 1 }} /></Form.Item>
                                        <Form.Item noStyle name="flowPlanStorageUnit">
                                            <Select style={{ width: 120 }}>
                                                <Select.Option value="DAY">天</Select.Option>
                                                <Select.Option value="WEEK">周</Select.Option>
                                                <Select.Option value="MONTH">月</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </div>
                                </Form.Item>
                            </Grid.Col>
                        </Grid.Row>
                    </Grid>
                </Card>
                <Card title="回溯分析方案数据存储策略" style={{ marginTop: 16 }}>
                    <Grid>
                        <Grid.Row>
                            <Grid.Col span={12} offset={3}>
                                <Form.Item noStyle name="traceSelectType">
                                    <Radio.Group>
                                        <Radio value="DEFAULT" style={radioStyle}>默认存储30天</Radio>
                                        <Radio value="DEFINED" style={radioStyle}>自定义流量分析方案存储时间</Radio>
                                    </Radio.Group>
                                </Form.Item>
                            </Grid.Col>
                        </Grid.Row>
                        <Grid.Row style={{ marginTop: 16 }}>
                            <Grid.Col span={12} offset={4}>
                                <Form.Item
                                    label="存储时长"
                                >
                                    <div style={{ display: 'flex' }}>
                                        <Form.Item noStyle name="traceStorageValue"><InputNumber  style={{ flex: 1 }} /></Form.Item>
                                        <Form.Item noStyle name="traceStorageUnit">
                                            <Select style={{ width: 120 }}>
                                                <Select.Option value="DAY">天</Select.Option>
                                                <Select.Option value="WEEK">周</Select.Option>
                                                <Select.Option value="MONTH">月</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </div>
                                </Form.Item>
                            </Grid.Col>
                        </Grid.Row>
                    </Grid>
                </Card>
                <div style={{marginTop: 16, textAlign: 'right' }}>
                    <Space >
                        <Button type="primary" htmlType="submit">保存</Button>
                    </Space>
                </div>
            </Form>
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/storage">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}