import React, { useState, useEffect, useContext } from 'react';
import { Input, Button } from 'antd';
import { PlusOutlined, MinusOutlined } from '@ant-design/icons';
import { Grid, Select, Constant } from 'ui';

export default function (props) {
    const constants = useContext(Constant.Context);
    const [filters, setFilters] = useState(props.value || []);

    useEffect(() => {
        setFilters(props.value || []);
    }, [ props.value ])

    function notifyChange(value) {
        if (props.onChange) {
            props.onChange(value);
        }
    }

    function onChange(index, field) {
        return e => {
            const newFilters = filters.slice();
            if (field == 'fieldValue') {
                newFilters[index][field] = e.target.value;
            } else {
                newFilters[index][field] = e;
            }
            setFilters(newFilters);
            notifyChange(newFilters);
        }
    }

    function onAdd(index) {
        return () => {
            const newFilters = filters.slice();
            newFilters.unshift({
                fieldName: '',
                expression: '',
                fieldValue: ''
            })
            setFilters(newFilters);
            notifyChange(newFilters);
        }
    }

    function onRemove(index) {
        return () => {
            const newFilters = filters.slice();
            newFilters.splice(index, 1);
            setFilters(newFilters);
            notifyChange(newFilters);
        }
    }

    return (
        <Grid>
            {filters.map((item, index) => (
                <Grid.Row gutter={16} style={{marginBottom: 5}}>
                    <Grid.Col span={9}>
                        <Select allowClear value={item.fieldName}  onChange={onChange(index, 'fieldName')} data={constants.flow_field} />
                    </Grid.Col>
                    <Grid.Col span={4}>
                        <Select allowClear value={item.expression}  onChange={onChange(index, 'expression')} data={constants.expression_list} />
                    </Grid.Col>
                    <Grid.Col span={9}>
                        <Input value={item.fieldValue} onChange={onChange(index, 'fieldValue')} />
                    </Grid.Col>
                    <Grid.Col span={2} style={{textAlign: 'right'}}>
                        {index == 0 && (
                            <Button shape="circle" type="primary" onClick={onAdd(index)} icon={<PlusOutlined />} />
                        )} 
                        {index !== 0 && (
                            <Button shape="circle" type="primary" onClick={onRemove(index)} icon={<MinusOutlined />} />
                        )}
                    </Grid.Col>
                </Grid.Row>
            ))}
        </Grid>
    )
}