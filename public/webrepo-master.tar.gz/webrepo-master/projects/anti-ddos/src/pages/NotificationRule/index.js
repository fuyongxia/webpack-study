import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { Route, Switch } from "react-router-dom";
import { Constant, Filters, Page, Results, Select, Table, confirm, renderer } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.notificationRuleEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.notificationRuleDelete)(record)
            .then(() => {
                setFilters({_updatedAt: Date.now()});
            })
        }
    }

    function groupRender(value) {
        return (
            <div>
                {value.map(item => (
                    <div>{item.name}</div>
                ))}
            </div>
        )
    }

    function onView(record) {
        return () => {
            app.service.notificationRuleView({ id: record.id})
                .then(body => {
                    setModalForm({
                        type: 'view',
                        title: '查看',
                        data: body
                    })
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onView(record)}>查看</a>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="通知规则">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="通知规则名称"
                    name="name"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="事件类型"
                    name="eventType"
                >
                    <Select data={constants.notification_event_type} allowClear />
                </Filters.Item>
                <Filters.Item
                    label="目标通知组"
                    name="notificationGroup"
                >
                    <Select allowClear params={{ pageSize: 9999 }} service={app.service.notificationGroupPage} labelField="name" valueField="id" />
                </Filters.Item>
            </Filters>
            <Results
                title="通知规则列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table filters={filters} service={app.service.notificationRulePage}>
                    <Table.Column title="通知规则名称" dataIndex="name" />
                    <Table.Column title="通知规则描述" dataIndex="description" />
                    <Table.Column title="事件类型" dataIndex="eventType" render={renderer.enumRender({ data: constants.notification_event_type})} />
                    <Table.Column title="目标通知组" dataIndex="groups" render={groupRender} />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/notification_rule">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}