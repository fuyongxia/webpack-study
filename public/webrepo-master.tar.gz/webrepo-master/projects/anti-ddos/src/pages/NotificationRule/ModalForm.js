import React, { useContext } from 'react';
import { Modal, Form, Row, Col, Input, Button, Space } from 'antd';
import { Grid, Select, Constant } from 'ui';

export default function (props) {
    const constants = useContext(Constant.Context);
    return (
        <Modal {...props} width={800} visible  >
            <Form {...props} >
                <Grid labelWidth="120px" gutter={16}>
                    <Grid.Row>
                        <Grid.Col offset={3} span={18}>
                            <Form.Item
                                label="通知规则名称"
                                name="name"
                                rules={[{ required: true }]}
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="通知规则描述"
                                name="description"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="事件类型"
                                name="eventType"
                            >
                                <Select data={constants.notification_event_type} />
                            </Form.Item>
                            <Form.Item
                                label="事件源"
                                name="eventResource"
                            >
                                <Select mode="multiple" params={{ pageSize: 9999 }} service={app.service.customerList} labelField="custname" valueField="custcode" />
                            </Form.Item>
                            <Form.Item
                                label="事件级别"
                                name="eventLevel"
                            >
                                <Select data={constants.notification_event_level} />
                            </Form.Item>
                            <Form.Item
                                label="目标通知组"
                                name="notificationGroup"
                            >
                                <Select mode="multiple" params={{ pageSize: 9999 }} service={app.service.notificationGroupList} labelField="name" valueField="id" />
                            </Form.Item>
                            <Form.Item
                                label="通知方式"
                                name="notificationMethod"
                            >
                                <Select data={constants.notification_method} />
                            </Form.Item>
                            <Form.Item
                                label="通知频率"
                                name="notificationFrequency"
                            >
                                <Select data={constants.notification_frequency} />
                            </Form.Item>
                        </Grid.Col>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}