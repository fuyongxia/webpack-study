import React, { useContext, useEffect } from 'react';
import { Route, Switch } from "react-router-dom";
import { Input, Button,Tooltip } from 'antd';
import { DeleteOutlined } from '@ant-design/icons';
import { Page, Filters, Results, Select, DatePicker, Constant, Table, confirm, renderer } from 'ui';
import { useTableFilters, useTableResults } from 'hooks';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { table, setTable, tableProps } = useTableResults(app.service.apiLogPage, [ filters._updatedAt ], { 
        filters,
        rowSelection: {
            selectedRowKeys: [],
            onChange: (keys) => {
                setTable({
                    rowSelection: {
                        ...table.rowSelection,
                        selectedRowKeys: keys
                    }
                })
            }
        }
     })

     useEffect(() => {
        setTable({
            rowSelection: {
                ...table.rowSelection,
                selectedRowKeys: []
            }
        })
     }, [ JSON.stringify(filters), JSON.stringify(table.pagination)])

    function onEmpty() {
        confirm(app.service.apiLogEmpty)()
            .then(body => {
                setFilters({ _updatedAt: Date.now() });
            })
    }

    function onRemove() {
        confirm(app.service.apiLogDelete)({ ids: table.rowSelection.selectedRowKeys })
        .then(body => {
            setFilters({ _updatedAt: Date.now() });
        })
    }

    function actionRender(value) {
        return (
            <Tooltip title={value}>
            <div className="ellipsis" style={{ float: 'left', maxWidth: '100%' }}>
              {value && value.substring(0, 20)+" ..."}
            </div>
          </Tooltip>

        )
    }


    return (
        <Page title="API调用日志">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="调用IP"
                    name="requestIp"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="被调用IP"
                    name="responseIp"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="调用接口"
                    name="interfaceName"
                >
                    <Select allowClear data={constants.jzkd_interface_type} />
                </Filters.Item>
                <Filters.Item
                    label="返回码"
                    name="responseCode"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item style={{width: '130%'}}
                    label="调用时间"
                >
                    <Filters.Item noStyle name="startTime">
                        <DatePicker showTime style={{width: '48%'}} />
                    </Filters.Item>
                    ~
                    <Filters.Item noStyle name="endTime">
                        <DatePicker showTime  style={{width: '48%'}} />
                    </Filters.Item>
                </Filters.Item>
            </Filters>
            <Results
                title="API调用日志列表"
                extra={[
                    <Button type="primary" onClick={onEmpty}>清空</Button>,
                    <Button disabled={!table.rowSelection.selectedRowKeys.length} icon={<DeleteOutlined />} type="primary" onClick={onRemove}>批量删除</Button>
                ]}
            >
                <Table rowKey="id" {...tableProps}>
                    <Table.Column title="调用IP" dataIndex="requestIp"  />
                    <Table.Column title="被调用IP" dataIndex="responseIp"  />
                    <Table.Column title="调用接口" dataIndex="interfaceName"  render={renderer.enumRender({ data: constants.jzkd_interface_type })}/>
                    <Table.Column title="调用结果" dataIndex="responseStatus" render={renderer.enumRender({ data: constants.result_type })} />
                    <Table.Column title="返回码" dataIndex="responseCode"  />
                    <Table.Column title="消息体" dataIndex="responseBody" ellipsis="true" render={actionRender} />
                    <Table.Column title="调用时间" dataIndex="requestTime" render={renderer.dateRender()} />
                </Table>
            </Results>
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/api_log">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}