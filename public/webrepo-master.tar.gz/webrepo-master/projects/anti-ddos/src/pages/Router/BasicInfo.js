import React, { useContext } from 'react';
import { Modal, Form, Row, Col, Input } from 'antd';
import { Grid, ScrollView, Select, Constant, ProvinceSelect, CitySelect } from 'ui';

export default function (props) {
    const { flow_source_manufacturer, flow_source_primary_type, flow_source_second_type } = useContext(Constant.Context);

    return (
        <ScrollView maxHeight="600px" minHeight="600px">
            <Grid labelWidth="120px" gutter={32}>
                <Grid.Row>
                    <Grid.Col offset={3} span={18}>
                        <Form.Item
                            label="网络设备名称"
                            name="name"
                            rules={[{ required: true }]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="网络设备描述"
                            name="description"
                        >
                            <Input.TextArea />
                        </Form.Item>
                        <Form.Item
                            label="网络设备大类"
                            name="primaryType"
                        >
                            <Select  data={flow_source_primary_type} />
                        </Form.Item>
                        <Form.Item
                            label="网络设备小类"
                            name="secondType"
                        >
                            <Select  data={flow_source_second_type} />
                        </Form.Item>
                        <Form.Item
                            label="部署省份"
                            name="deployProvince"
                        >
                            <ProvinceSelect />
                        </Form.Item>
                        <Form.Item
                            label="部署城市"
                            name="deployCity"
                        >
                            <CitySelect province={props.data.deployProvince} />
                        </Form.Item>
                        <Form.Item
                            label="部署网络"
                            name="deployNetwork"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="部署位置"
                            name="deployPosition"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="厂商"
                            name="manufacturer"
                        >
                            <Select data={flow_source_manufacturer} />
                        </Form.Item>
                        <Form.Item
                            label="型号"
                            name="model"
                        >
                            <Input />
                        </Form.Item>
                        {props.type == 'view' && (
                            <>
                                <Form.Item
                                    label="系统名称"
                                    name="sysName"
                                >
                                    <Input.TextArea />
                                </Form.Item>
                                <Form.Item
                                    label="系统描述"
                                    name="sysDescr"
                                >
                                    <Input.TextArea />
                                </Form.Item>
                            </>
                        )}
                    </Grid.Col>
                </Grid.Row>
            </Grid>
        </ScrollView>
    )
}