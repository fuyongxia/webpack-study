import React, { useContext } from 'react';
import { Form, Input, InputNumber, Button, Radio, message  } from 'antd';
import { Grid, ScrollView, Select, Ping, Constant, Switch } from 'ui';

export default function (props) {
    const { snmp_security_level, snmp_auth_protocol, snmp_privacy_protocol } = useContext(Constant.Context);

    function onSnmpTest() {
        app.service.routerSnmpTest(props.data)
            .then(body => {
                message.info(body);
            })
    }

    return (
        <ScrollView maxHeight="600px" minHeight="600px">
            <Grid labelWidth="150px" gutter={32}>
                <Grid.Row>
                    <h3>SNMP配置</h3>
                </Grid.Row>
                <Grid.Row>
                    <Grid.Col span={18}>
                        <Form.Item
                            label="查询IP"
                            name="snmpIp"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="端口号"
                            name="snmpPort"
                        >
                            <InputNumber defaultValue='161'/>
                        </Form.Item>
                        <Form.Item
                            label="版本"
                            name="snmpVersion"
                        >
                            <Radio.Group>
                                <Radio value="1">V2C</Radio>
                                <Radio value="3">V3</Radio>
                            </Radio.Group>
                        </Form.Item>
                        {props.data.snmpVersion == "1" && (
                            <>
                                <Form.Item
                                    label="Community团体名称"
                                    name="snmpCommunity"
                                >
                                    <Input />
                                </Form.Item>
                            </>
                        )}

                        {props.data.snmpVersion == "3" && (
                            <>
                                <Form.Item
                                    label="安全用户名"
                                    name="snmpAuthUsername"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="安全级别"
                                    name="snmpSecurityLevel"
                                >
                                    <Select data={snmp_security_level} />
                                </Form.Item>
                                <Form.Item
                                    label="认证协议"
                                    name="snmpAuthProtocol"
                                >
                                    <Select data={snmp_auth_protocol} />
                                </Form.Item>
                                <Form.Item
                                    label="认证密码"
                                    name="snmpAuthPwd"
                                >
                                    <Input.Password />
                                </Form.Item>
                                <Form.Item
                                    label="加密协议"
                                    name="snmpPrivacyProtocol"
                                >
                                    <Select data={snmp_privacy_protocol} />
                                </Form.Item>
                                <Form.Item
                                    label="加密密钥"
                                    name="snmpPrivacyKey"
                                >
                                    <Input.Password />
                                </Form.Item>
                            </>
                        )}
                        <Form.Item>
                            <Button type="primary" onClick={onSnmpTest}>SNMP连通性测试</Button>
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={5}>
                        <Form.Item>
                            <Ping ip={props.data.snmpIp} />
                        </Form.Item>
                    </Grid.Col>
                </Grid.Row>
            </Grid>
            <Grid labelWidth="150px" gutter={32}>
                <Grid.Row>
                    <Grid.Col>
                            <h3>SNMP轮询采集</h3>
                        </Grid.Col>
                    </Grid.Row>
                <Grid.Row>
                    <Grid.Col span={18}>
                        <Form.Item
                            label="开启SNMP轮询"
                            name="snmpPollingEnable"
                        >
                            <Switch />
                        </Form.Item>
                        <Form.Item
                            label="轮询间隔(分钟)"
                            name="snmpPollingInterval"
                        >
                            <InputNumber disabled defaultValue='5' />
                        </Form.Item>
                        <Form.Item
                            label="开启接口流量采集"
                            name="snmpPollingInetrfaceEnable"
                        >
                            <Switch />
                        </Form.Item>
                    </Grid.Col>
                    <Grid.Col span={5}>
                    </Grid.Col>
                </Grid.Row>
            </Grid>
        </ScrollView>
    )
}