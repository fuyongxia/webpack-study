import React, { useContext } from 'react';
import { Modal, Form, Row, Col, Input, InputNumber} from 'antd';
import { Grid, ScrollView, Switch, Checkbox, Select, Constant } from 'ui';

export default function () {
    const { flow_protocol_type } = useContext(Constant.Context);

    return(
        <ScrollView maxHeight="600px" minHeight="600px">
            <Grid labelWidth="180px" gutter={32}>
                <Grid.Row>
                <Grid.Col offset={3} span={18}>
                    <Form.Item
                        label="开启Flow采集"
                        name="flowEnable"
                    >
                        <Switch />
                    </Form.Item>
                    <Form.Item
                        label="Flow输出源IP"
                        name="flowExportIp"
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        label="Flow输出目的端口号"
                        name="flowExportPort"
                    >
                        <InputNumber />
                    </Form.Item>
                    <Form.Item
                        label="采样率"
                        name="flowExportSampling"
                    >
                        <InputNumber />
                    </Form.Item>
                    <Form.Item
                        label="关联检测设备"
                        name="managingAppliance"
                    >
                        <Select mode="multiple" service={app.service.appliancePage} params={{ pageSize: 99999 }} labelField="name" valueField="uuid" />
                    </Form.Item>
                    <Form.Item
                        label="Flow协议类型"
                        name="flowProtocolType"
                    >
                        <Select data={flow_protocol_type} />
                    </Form.Item>
                    <Form.Item
                        label="开启Flow中断告警"
                        name="flowStopAlertEnable"
                    >
                        <Checkbox />
                    </Form.Item>
                    <Form.Item
                        label="Flow中断时间阈值(秒)"
                        name="flowStopAlertTime"
                    >
                        <InputNumber />
                    </Form.Item>
                </Grid.Col>
                </Grid.Row>
            </Grid>
        </ScrollView>
    )
}