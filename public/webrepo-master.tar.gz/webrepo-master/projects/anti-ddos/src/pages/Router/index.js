import React, { useContext } from 'react';
import { Switch, Route } from "react-router-dom";
import { Input, Button, Space } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { Page, Select, Filters, Results, Table, Constant, Ping, confirm, renderer } from 'ui';
import { useTableFilters, useModalForm } from 'hooks';
import ModalForm from './ModalForm';

function Index(props) {
    const { connect_status, flow_source_primary_type, flow_source_second_type } = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.routerEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            })
            .catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    
    function onView(record) {
        return () => {
            setModalForm({
                type: 'view',
                title: '查看',
                data: record
            }) 
        }
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'add',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.routerDelete)(record)
                .then(body => {
                    setFilters({_updatedAt: Date.now()});
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <Ping ip={record.snmpIp} />
                <a onClick={onView(record)}>查看</a>
                <a onClick={onUpdate(record)}>修改</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    function statusRender(value, record) {
        if (value == '-'){
            return value;
        } else {
            return renderer.enumRender({ data: connect_status})(value);
        }
    }

    return (
        <Page title="网络设备">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="网络设备名称"
                    name="name"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="网络设备大类"
                    name="primaryType"
                >
                    <Select data={flow_source_primary_type} allowClear />
                </Filters.Item>
                <Filters.Item
                    label="网络设备小类"
                    name="secondType"
                >
                    <Select data={flow_source_second_type} allowClear />
                </Filters.Item>
                <Filters.Item
                    label="Flow输出IP"
                    name="flowExportIp"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="SNMP采集IP"
                    name="snmpIp"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="在线状态"
                    name="connectStatus"
                >
                    <Select data={connect_status} allowClear />
                </Filters.Item>
            </Filters>
            <Results
                title="网络设备列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table service={app.service.routerPage} filters={filters}>
                    <Table.Column title="网络设备名称" dataIndex="name" />
                    <Table.Column title="网络设备大类" dataIndex="primaryType" render={renderer.enumRender({ data: flow_source_primary_type})} />
                    <Table.Column title="网络设备小类" dataIndex="secondType" render={renderer.enumRender({ data: flow_source_second_type})} />
                    <Table.Column title="系统名称" dataIndex="sysName" />
                    <Table.Column title="Flow输出IP" dataIndex="flowExportIp" />
                    <Table.Column title="SNMP采集IP" dataIndex="snmpIp" />
                    <Table.Column title="关联检测设备" dataIndex="appliances" render={value => value.map(item =>item.name).join(", ")} />
                    <Table.Column title="状态" dataIndex="connectStatus"  render={statusRender} />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function (props) {
    const constants = {
        connect_status: [
            { name: '在线', value: 'ON'},
            { name: '离线', value: 'OFF'},
        ]
    }

    return (
        <Switch>
            <Route exact path="/router" children={(
                <Constant.Provider value={constants}>
                     <Index />
                </Constant.Provider>
            )} />
        </Switch>
    )
}