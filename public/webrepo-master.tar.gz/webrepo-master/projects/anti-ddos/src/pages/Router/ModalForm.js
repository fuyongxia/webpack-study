import React from 'react';
import { Modal, Form, Tabs } from 'antd';
import BasicInfo from './BasicInfo';
import FlowInfo from './FlowInfo';
import SnmpInfo from './SnmpInfo';

export default function (props) {
    function onValuesChange(data) {
        if ('deployProvince' in data) {
            data.deployCity = '';
        }
        props.onValuesChange(data);
    }

    return (
        <Modal width={800} visible {...props} footer={props.type == 'view' ? null : undefined} >
            <Form {...props} onValuesChange={onValuesChange}>
                <Tabs defaultActiveKey="1">
                    <Tabs.TabPane tab="基本信息" key="1">
                        <BasicInfo {...props} />
                    </Tabs.TabPane>
                    <Tabs.TabPane tab="Flow配置" key="2">
                        <FlowInfo {...props} />
                    </Tabs.TabPane>
                    <Tabs.TabPane tab="SNMP配置" key="3">
                        <SnmpInfo {...props} />
                    </Tabs.TabPane>
                </Tabs>
            </Form>
        </Modal>
    )
}