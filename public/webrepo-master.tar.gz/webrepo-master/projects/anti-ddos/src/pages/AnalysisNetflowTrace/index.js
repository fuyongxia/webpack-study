import { Space, InputNumber } from 'antd';
import { useTableFilters } from 'hooks';
import React, { useContext, useEffect, useState } from 'react';
import { Route, Switch, Link, useLocation } from "react-router-dom";
import { Constant, DatePicker, Filters, Page, Results, Select, Table, renderer } from 'ui';
import { Line } from '@ant-design/charts';

function Index(props) {
    const location = useLocation();
    const constants = useContext(Constant.Context);
    const [ chartData, setChartData ] = useState([]);
    const [ columns, setColumns ] = useState([]);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    
    React.useEffect(() => {
        const params = new URLSearchParams(location.search);
        if (params.get('planId')) {
            setFilters({
                planId: parseInt(params.get('planId'))
            })
        }
    }, [location]);

    useEffect(() => {
        if (filters.planId) {
            app.service.tracePlanView({ id: filters.planId})
                .then(body => {
                    const patterns = (body.patterns || []).map(
                        item => ({ value: item.columnName })
                    );
                    setColumns(_.intersectionBy(constants.flow_field, patterns, 'value'));
                })
        } else {
            setColumns([]);
        }
    }, [filters.planId])

    useEffect(() => {
        if (Object.keys(constants).length > 0) {
            setFilters({
                rangeType: constants.time_period[0].value,
                unitBy: 'bps',
                top: 100,
                _updatedAt: Date.now()
            })
        }
    }, [ Object.keys(constants).length ]);

    useEffect(() => {
        app.service.analysisNetflowTraceList(filters)
            .then(body => {
                const results = [];
                (body || []).map(item => {
                    results.push({
                        type: '平均流速',
                        value: item.bps,
                        datetime: renderer.dateRender()(item.datetime)
                    });
                    results.push({
                        type: '平均包速',
                        value: item.pps,
                        datetime: renderer.dateRender()(item.datetime)
                    });
                    results.push({
                        type: '总字节数',
                        value: item.allBytes,
                        datetime: renderer.dateRender()(item.datetime)
                    });
                    results.push({
                        type: '总包数',
                        value: item.allPackets,
                        datetime: renderer.dateRender()(item.datetime)
                    });
                })
                setChartData(results);
            })
    }, [ filters._updatedAt ] )

    function onFiltersChange(data) {
        if ('planId' in data) {
            data.columnName = ''
        }
        filtersProps.onValuesChange(data);
    }

    return (
        <Page title="流量回溯分析">
            <Filters {...filtersProps} onValuesChange={onFiltersChange}>
                <Filters.Item
                    label="方案名称"
                    name="planId"
                >
                    <Select allowClear params={{pageSize: 999}} service={app.service.tracePlanPage} labelField="name" valueField="id" />
                </Filters.Item>
                <Filters.Item
                    label="时间范围"
                    name="rangeType"
                >
                    <Select allowClear data={constants.time_period} />
                </Filters.Item>
                {filters.rangeType !== 'DEFINED' && (
                     <Filters.Item
                        span={12}
                     >
                    </Filters.Item>
                )}
                {filters.rangeType == 'DEFINED' && (
                    <Filters.Item
                        label="开始时间"
                        name="startTime"
                    >
                        <DatePicker />
                    </Filters.Item>
                )}
                {filters.rangeType == 'DEFINED' && (
                    <Filters.Item
                    label="结束时间"
                    name="endTime"
                    >
                        <DatePicker />
                    </Filters.Item>
                )}
                <Filters.Item
                    label="统计维度"
                    name="columnName"
                >
                    <Select allowClear data={columns} />
                </Filters.Item>
                <Filters.Item
                    label="统计单位"
                    name="unitBy"
                >
                    <Select allowClear>
                        <Select.Option value="bps">bps</Select.Option>
                        <Select.Option value="pps">pps</Select.Option>
                        <Select.Option value="bytes">bytes</Select.Option>
                        <Select.Option value="packets">packets</Select.Option>
                    </Select>
                </Filters.Item>
                <Filters.Item
                    label="TopN"
                    name="top"
                >
                    <InputNumber defaultValue="100"/>
                </Filters.Item>
            </Filters>
            <Results 
                title="流量曲线图"
            >
                <Line
                    className='chart-enlarge'
                    data={chartData}
                    xField="datetime"
                    yField="value"
                    seriesField="type"
                    legend={{ position: 'top' }}
                    smooth={true}
                    meta={{
                        value: {
                            formatter: function formatter(v) {
                                return renderer.flowRender()(v);
                              }
                        }
                    }}
                />
            </Results>
            <Results
                title="列表"
            >
                {Table.create({
                    filters: {
                        ...filters,
                        definedTime: filters.definedTime ? filters.definedTime.map(item => item.format('YYYY-MM-DD')).join(' - ') : null
                    },
                    service: app.service.analysisNetflowTracePage,
                    columns: [
                        {
                            title: '汇总列',
                            dataIndex: 'name'
                        },
                        {
                            title: '平均流速',
                            dataIndex: 'bps',
                            render: renderer.flowRender()
                        },
                        {
                            title: '平均包速',
                            dataIndex: 'pps',
                            render: renderer.flowRender()
                        },
                        {
                            title: '总字节数',
                            dataIndex: 'allBytes',
                            render: renderer.flowRender()
                        },
                        {
                            title: '总包数',
                            dataIndex: 'allPackets',
                            render: renderer.flowRender()
                        },
                        {
                            title: '总字节数占比',
                            dataIndex: 'bytesRate',
                            render: renderer.numToRateRender()
                        },
                        {
                            title: '总包数占比',
                            dataIndex: 'packetsRate',
                            render: renderer.numToRateRender()
                        },
                        {
                            title: '操作',
                            render: (value, record) => {
                                return (
                                    <Space>
                                        <Link>原始数据</Link>
                                        <Link>波动图</Link>
                                    </Space>
                                )
                            }
                        },
                    ]
                })}
            </Results>
        </Page>
    )
}


export default function (props) {
    return (
        <Switch>
            <Route exact path="/analysis_netflow_trace">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}