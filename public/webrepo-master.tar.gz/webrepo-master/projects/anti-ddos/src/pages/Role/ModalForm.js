import { Form, Input, InputNumber, Modal } from 'antd';
import React, { useContext } from 'react';
import { Constant, Grid, Select } from 'ui';

export default function (props) {
    const constants = useContext(Constant.Context);
    return (
        <Modal width={640} visible {...props}>
            <Form {...props}>
                <Grid labelWidth="38px" gutter={16}>
                    <Grid.Row>
                            <Form.Item
                                label="名称"
                                name="authRoleName"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="标识"
                                name="authRoleCode"
                            >
                                <Input />
                            </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                                label="描述"
                                name="authRoleDesc"
                            >
                                <Input.TextArea />
                            </Form.Item>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}