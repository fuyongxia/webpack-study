import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, InputNumber, Space } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React, { useContext, useEffect, useState } from 'react';
import { Route, Switch } from "react-router-dom";
import { confirm, Constant, Table, Select, Filters, Page, Results,renderer } from 'ui';
import { Line } from '@ant-design/charts';
import Condition from './Condition';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({
        conditions: [
            { fieldName: '', expression: '', fieldValue: '' }
        ]
    });
    const [ chartData, setChartData ] = useState([]);

    useEffect(() => {
        if (Object.keys(constants).length > 0) {
            setFilters({
                duration: 1,
                direction: constants.direction[0].value,
                unitBy: constants.unit[0].value,
                top: 100,
                _updatedAt: Date.now()
            })
        }
    }, [ Object.keys(constants).length ]);

    useEffect(() => {
        app.service.analysisNetflowList(filters)
            .then(body => {
                const results = [];
                (body || []).map(item => {
                    results.push({
                        type: '平均流速',
                        value: item.bps,
                        datetime: renderer.dateRender()(item.datetime)
                    })
                    results.push({
                        type: '平均包速',
                        value: item.pps,
                        datetime: renderer.dateRender()(item.datetime)
                    })
                    results.push({
                        type: '总字节数',
                        value: item.allBytes,
                        datetime: renderer.dateRender()(item.datetime)
                    })
                    results.push({
                        type: '总包数',
                        value: item.allPackets,
                        datetime: renderer.dateRender()(item.datetime)
                    })
                })
                setChartData(results);
            })

    }, [ filters._updatedAt ])



    return (
        <Page title="实时流量分析">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="持续时间"
                    name="duration"
                >
                    <Select allowClear>
                        <Select.Option value={1}>1分钟</Select.Option>
                        <Select.Option value={5}>5分钟</Select.Option>
                        <Select.Option value={10}>10分钟</Select.Option>
                        <Select.Option value={15}>15分钟</Select.Option>
                        <Select.Option value={30}>30分钟</Select.Option>
                        <Select.Option value={60}>60分钟</Select.Option>
                    </Select>
                </Filters.Item>
                <Filters.Item
                    label="网络边界"
                    name="networkBoundary"
                >
                    <Select allowClear params={{pageSize: 999 }} service={app.service.groupPage} labelField="name" valueField="uuid" />
                </Filters.Item>
                <Filters.Item
                    label="流量方向"
                    name="direction"
                >
                    <Select allowClear data={constants.direction} />
                </Filters.Item>
                <Filters.Item
                    span={12}
                    label="Flow过滤条件"
                    name="conditions"
                >
                    <Condition />
                </Filters.Item>
                <Filters.Item
                    span={12}
                >
                </Filters.Item>
                <Filters.Item
                    label="统计内容"
                    name="contentBy"
                >
                    <Select allowClear data={constants.flow_field} />
                </Filters.Item>
                <Filters.Item
                    label="统计单位"
                    name="unitBy"
                >
                    <Select allowClear data={constants.unit} />
                </Filters.Item>
                <Filters.Item
                    label="TopN"
                    name="top"
                >
                    <InputNumber />
                </Filters.Item>
            </Filters>
            <Results>
                <Line
                    className='chart-enlarge'
                    data={chartData}
                    xField="datetime"
                    yField="value"
                    seriesField="type"
                    legend={{ position: 'top' }}
                    meta={{
                        value: {
                            formatter: function formatter(v) {
                                return renderer.flowRender()(v);
                              }
                        }
                    }} 
                />
            </Results>
            <Results
                title="列表"
            >
                {Table.create({
                    filters,
                    service: app.service.analysisNetflowPage,
                    columns: [
                        {
                            title: '汇总列',
                            dataIndex: 'name'
                        },
                        {
                            title: '平均流速',
                            dataIndex: 'bps',
                            render: renderer.flowRender()
                        },
                        {
                            title: '平均包速',
                            dataIndex: 'pps',
                            render: renderer.flowRender()
                        },
                        {
                            title: '总字节数',
                            dataIndex: 'allBytes',
                            render: renderer.flowRender()
                        },
                        {
                            title: '总包数',
                            dataIndex: 'allPackets',
                            render: renderer.flowRender()
                        },
                        {
                            title: '总字节数占比',
                            dataIndex: 'bytesRate',
                            render: renderer.numToRateRender()
                        },
                        {
                            title: '总包数占比',
                            dataIndex: 'packetsRate',
                            render: renderer.numToRateRender()
                        },
                    ]   
                })}
            </Results>
        </Page>
    )
}

export default function (props) {
    const constants = {
        direction: [
            { name: '双向', value: 'ALL' },
            { name: '入向', value: 'IN' },
            { name: '出向', value: 'OUT' },
        ],
        unit: [
            { name: 'bps', value: 'bps' },
            { name: 'pps', value: 'pps' },
            { name: 'bytes', value: 'bytes' },
            { name: 'packets', value: 'packets' },
        ]
    }

    return (
        <Switch>
            <Route exact path="/analysis_netflow">
                <Constant.Provider value={constants}>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}