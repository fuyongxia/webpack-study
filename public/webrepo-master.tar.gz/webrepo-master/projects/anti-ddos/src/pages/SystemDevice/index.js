import { Card, Table } from 'antd';
import { useStyles, useTableFilters } from 'hooks';
import React, { useContext, useEffect, useState } from 'react';
import { Route, Switch } from "react-router-dom";
import { Constant, Filters, Page, RangePicker, Select, renderer} from 'ui';
import AreaChart from './AreaChart';
import {ArrowUpOutlined, ArrowDownOutlined} from '@ant-design/icons';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, filtersProps } = useTableFilters({});
    const [ chartData, setChartData] = useState([]);
    const [ dataSource, setDataSource ] = useState([]);

    useEffect(() => {
        app.service.monitorSystemDevice()
            .then(body => {
                setDataSource(body || []);
            })
    }, []);

    useEffect(() => {
        app.service.monitorSystemDeviceItems({
            ...filters,
            definedTime: (filters.definedTime || []).map(item => item.format('YYYY-MM-DD')).join(' - ')
        })
            .then(body => {
                setChartData(body || []);
            })
            .catch(error => {
                setChartData([]);
            })
    }, [filters._updatedAt])

    const styles = useStyles({
        "detail": {
            lineHeight: 2,
            paddingLeft: 0,
            listStyle: 'none',
            '& label': {
                fontWeight: 'bold',
                display: 'inline-block',
                width: 80
            }
        }
    })
    const type = filters.type;
    const config = {
        className: 'chart-enlarge',
        data: chartData,
        xField: 'xStr',
        yField: 'yValue',
        xAxis: { tickCount: 5 },
        yAxis: {
            label: {
              formatter: function formatter(v) {
                switch (type) {
                    case 'CPU_RATE':
                    case 'MEM_RATE':
                    case 'DISK_RATE':
                        return v+'%';
                    case 'NET_UP_RATE':
                    case 'NET_DOWN_RATE':
                        return renderer.flowRender(' ', 0)(v)+'bps';
                    default:
                        return v+'%';
                }
              },
            },
        }, 
        slider: {
            start: 0.1,
            end: 0.9,
            trendCfg: { isArea: true },
        },
        tooltip: {
            trigger: 'item',
            formatter: function(value) {
                let toolValue = "";
                let toolName = filtersRender(type);
                switch (type) {
                    case 'CPU_RATE':
                    case 'MEM_RATE':
                    case 'DISK_RATE':
                        toolValue = value.yValue + "%";
                        break;
                    case 'NET_UP_RATE':
                    case 'NET_DOWN_RATE':
                        toolValue = renderer.flowRender()(value.yValue) + "bps";
                        break;
                    default:
                        break;
                }
                return { name: toolName, value: toolValue };
            }
        }       
    }

    function filtersRender(value) {
        const filterType = {};
        if (constants.attack_filter_type == null) {
            return;
        }
        constants.resource_type.forEach(item => {
            filterType[item.value] = item.name;
        })
        return filterType[value];
    }

    return (
        <Page title="系统负载">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="设备名称"
                    name="applianceId"
                >
                    <Select allowClear params={{ pageSize: 99999 }} service={app.service.appliancePage} labelField="name" valueField="uuid" />
                </Filters.Item>
                <Filters.Item
                    label="负载类型"
                    name="type"
                >
                    <Select allowClear data={constants.resource_type} />
                </Filters.Item>
                <Filters.Item
                    label="时间范围"
                    name="period"
                >
                    <Select allowClear>
                        <Select.Option value="TODAY">今日</Select.Option>
                        <Select.Option value="YESTERDAY">昨日</Select.Option>
                        <Select.Option value="WEEK">本周</Select.Option>
                        <Select.Option value="MONTH">本月</Select.Option>
                        <Select.Option value="YEAR">本年</Select.Option>
                        <Select.Option value="DEFINED">自定义</Select.Option>
                    </Select>
                </Filters.Item>
                {filters.period == 'DEFINED' && (
                    <Filters.Item
                        label="自定义时间段"
                        name="definedTime"
                    >
                        <RangePicker />
                    </Filters.Item>
                )}
            </Filters>
            <Card style={{ margin: "16px 0"}}>
                <AreaChart cfg={config} />
            </Card>
            <Card>
                <Table 
                    rowKey="uuid"
                    dataSource={dataSource}
                    expandable={{
                        expandedRowRender: record => (
                            <ul className={styles.detail}>
                                <li>
                                    <label>硬件配置</label> CPU数量：{record.analysisSystemCount.cpuCount} 内存大小：{renderer.flowRender(' ', 2,1024)(record.analysisSystemCount.memSize)} 磁盘大小：{renderer.flowRender(' ', 2,1024)(record.analysisSystemCount.diskSize)} 网卡数量：{record.analysisSystemCount.networkCardCount}
                                </li>
                                <li>
                                    <label>软件版本</label>  {record.analysisSystemCount.softwareVersion}
                                </li>
                                <li>
                                    <label>License</label> {record.analysisSystemCount.license}
                                </li>
                                <li>
                                    <label>备份状态</label> {record.analysisSystemCount.backupStatus}
                                </li>
                            </ul>
                        )
                    }}
                >
                    <Table.Column title="名称" dataIndex="name" />
                    <Table.Column title="类型" dataIndex="applianceType" render={renderer.enumRender({ data: constants.appliance_type})} />
                    <Table.Column title="IP地址" dataIndex="ip" />
                    <Table.Column title="状态" dataIndex={['analysisSystemCount', 'status']} render={renderer.enumRender({ data: constants.appliance_status})} />
                    <Table.Column title="CPU使用率" dataIndex={['analysisSystemCount', 'cpuRate']} render={renderer.percentRender()}  />
                    <Table.Column title="内存使用率" dataIndex={['analysisSystemCount', 'memRate']} render={renderer.percentRender()} />
                    <Table.Column title="磁盘使用率" dataIndex={['analysisSystemCount', 'diskRate']} render={renderer.percentRender()} />
                    <Table.Column title="网络使用率" 
                     render = {(record) => {
                         return (
                             <div>
                                <ArrowUpOutlined /> {renderer.flowRender(' bps')(record.analysisSystemCount.upNetworkSpeed)}
                                <br />
                                <ArrowDownOutlined /> {renderer.flowRender(' bps')(record.analysisSystemCount.downNetworkSpeed)}
                             </div>
                            )
                        }}
                    />
                    <Table.Column title="采集时间" dataIndex={['analysisSystemCount', 'dateTime']} render={renderer.dateRender()} />
                </Table>
            </Card>
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/system_device">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}