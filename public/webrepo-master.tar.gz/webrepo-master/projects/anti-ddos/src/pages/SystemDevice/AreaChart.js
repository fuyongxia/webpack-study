import React, { useState, useEffect } from 'react';
import { Area } from '@ant-design/charts';

export default function(props) {
    const [ cfg, setCfg ] = useState(props.cfg || {});

    useEffect(() => {
        setCfg(props.cfg);
    }, [JSON.stringify(props.cfg)])

    return (
        <Area {...cfg} />
    )
}