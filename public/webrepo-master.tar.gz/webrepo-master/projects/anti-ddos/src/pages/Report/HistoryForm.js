import React, { useState } from 'react';
import { Modal, Form, Button, Table } from 'antd';
import { confirm, renderer } from 'ui';
import { useTableResults } from 'hooks';

export default function (props) {
    const [filters, setFilters] = useState({ id: props.data.id });
    const { table, setTable, tableProps } = useTableResults(app.service.reportHistoryPage, [filters._updatedAt], {
        filters,
        rowSelection: {
            selectedRowKeys: [],
            onChange: (keys) => {
                setTable({
                    rowSelection: {
                        ...table.rowSelection,
                        selectedRowKeys: keys
                    }
                })
            }
        },
        columns: [
            {
                title: '报表流水号',
                dataIndex: 'reportNum'
            },
            {
                title: '报表生成时间',
                dataIndex: 'reportCreateTime',
                render: renderer.dateRender()
            },
            {
                title: '报表发送时间',
                dataIndex: 'reportSendTime',
                render: renderer.dateRender()
            },
            {
                title: '操作',
                render() {
                    return (
                        <a>下载</a>
                    )
                }
            },
        ],
        rowKey: 'id',
        size: 'middle',
        bordered: true
    })

    function onRemove() {
        confirm(app.service.reportHistoryDelete)({ id: table.rowSelection.selectedRowKeys.join(',') })
            .then(body => {
                setTable({
                    rowSelection: {
                        ...table.rowSelection,
                        selectedRowKeys: []
                    }
                })
                setFilters({ _updatedAt: Date.now() });
            })
    }

    return (
        <Modal {...props} width={960} visible>
            <Form {...props}>
                <div style={{marginBottom: 10}}>
                    <Button type="primary" disabled={!table.rowSelection.selectedRowKeys.length} onClick={onRemove}>删除</Button>
                </div>
                <Table {...tableProps} />
            </Form>
        </Modal>
    )
}