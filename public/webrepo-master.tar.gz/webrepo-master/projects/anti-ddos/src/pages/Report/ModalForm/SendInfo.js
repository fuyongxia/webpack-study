import { Form, Input, InputNumber, Space } from 'antd';
import React, { useContext, useState, useEffect } from 'react';
import { Grid, Switch, Select, Constant } from 'ui';

export default function (props) {
    const constants = useContext(Constant.Context);
    const [ emailAddress, setEmailAddress ] = useState('');

    useEffect(() => {
        if (props.data.notifyGroupId) {
            app.service.notificationGroupView({ id: props.data.notifyGroupId })
            .then(body => {
                setEmailAddress(body.emailAddress.split(',').join('\n'));
            })
        } else {
            setEmailAddress('');
        }
    }, [props.data.notifyGroupId]);

    return (
        <Grid labelWidth="100px">
            <Grid.Row>
                <Grid.Col span={18} offset={3}>
                    <Form.Item
                        label="开启邮件发送"
                        name="sendSwitch"
                    >
                        <Switch />
                    </Form.Item>
                    <Form.Item
                        label="通知组"
                        name="notifyGroupId"
                    >
                        <Select params={{pageSize: 999}} service={app.service.notificationGroupPage} labelField="name" valueField="id" />
                    </Form.Item>
                    <Form.Item
                        label="邮件列表"
                    >
                        <Input.TextArea value={emailAddress} readOnly rows={7} />
                    </Form.Item>
                    <Form.Item
                        label="邮件格式"
                        name="fileMode"
                    >
                        <Select data={constants.file_mode} />
                    </Form.Item>
                    <Form.Item
                        label="发送时间"
                        name="execType"
                    >
                        <Select data={constants.exec_type} />
                    </Form.Item>
                    {props.data.execType == 'DAY' && (
                        <>
                            <Form.Item
                                colon={false}
                                label=" "
                            >
                                <Space>
                                    <span>小时</span>
                                    <Form.Item noStyle name="h">
                                        <InputNumber min={0} max={23}/>
                                    </Form.Item>
                                    <span>分钟</span>
                                    <Form.Item noStyle name="m">
                                        <InputNumber min={0} max={59}/>
                                    </Form.Item>
                                </Space>
                            </Form.Item>
                        </>
                    )}
                    {props.data.execType == 'WEEK' && (
                        <>
                            <Form.Item
                                colon={false}
                                label=" "
                            >
                                <Space>
                                    <span>星期</span>
                                    <Form.Item noStyle name="w">
                                        <InputNumber min={1} max={7}/>
                                    </Form.Item>
                                    <span>小时</span>
                                    <Form.Item noStyle name="h">
                                        <InputNumber min={0} max={23}/>
                                    </Form.Item>
                                    <span>分钟</span>
                                    <Form.Item noStyle name="m">
                                        <InputNumber min={0} max={59}/>
                                    </Form.Item>
                                </Space>
                            </Form.Item>
                        </>
                    )}
                    {props.data.execType == 'MONTH' && (
                        <>
                            <Form.Item
                                colon={false}
                                label=" "
                            >
                                <Space>
                                    <span>天</span>
                                    <Form.Item noStyle name="d">
                                        <InputNumber min={1} max={31}/>
                                    </Form.Item>
                                    <span>小时</span>
                                    <Form.Item noStyle name="h">
                                        <InputNumber min={0} max={23}/>
                                    </Form.Item>
                                    <span>分钟</span>
                                    <Form.Item noStyle name="m">
                                        <InputNumber min={0} max={59}/>
                                    </Form.Item>
                                </Space>
                            </Form.Item>
                        </>
                    )}
                </Grid.Col>
            </Grid.Row>
        </Grid>
    )
}