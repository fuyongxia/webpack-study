import Adapter from 'adapter';
import { Form, Input, Checkbox } from 'antd';
import React, { useState, useEffect, useContext } from 'react';
import { Grid, Select, Constant, Adpater } from 'ui';

export default function (props) {
    const constants = useContext(Constant.Context);
    const [ plans, setPlans ] = useState([]);
    const [ columns, setColumns ] = useState([]);

    useEffect(() => {
         app.service.tracePlanPage({ pageSize: 999 })
            .then(body => {
                setPlans(body.content);
            })
    }, []);

    useEffect(() => {
        const matched = plans.find(item => item.id = props.data.planId );
        if (matched) {
           setColumns(matched.patterns.map(item => ({ name: item.columnName, value: item.columnName })));
        } else {
            setColumns([]);
        }
    }, [props.data.planId, plans.length])

    return (
        <Grid labelWidth="100px">
            <Grid.Row>
                <Form.Item
                    label="报表类型"
                    name="reportType"
                >
                    <Select data={constants.report_type} />
                </Form.Item>
                <Form.Item
                    label="统计周期"
                    name="period"
                >
                    <Select data={constants.period} />
                </Form.Item>
            </Grid.Row>
            {props.data.reportType == 'ATTACK' && (
                <>
                    <Grid.Row>
                        <Form.Item
                            label="报表对象"
                            name="attackCustomId"
                        >
                            <Select params={{ pageSize: 99999 }} service={app.service.customerPage} labelField="custname" valueField="custid" />
                        </Form.Item>
                        <div />
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                            label="报表内容"
                        >
                            <Grid.Row style={{marginTop: 8}}>
                                <Form.Item noStyle name="attackList">
                                    <Adapter
                                        parse={(value) => {
                                            return value ? value.split(',').filter(Boolean) : [];
                                        }}
                                        valueOf={(value) => {
                                            return value ? value.join(","): '';
                                        }}
                                    >
                                        <Checkbox.Group>
                                            {_.chunk(constants.attack_analysis_type, 3).map(items => (
                                                <Grid.Row gutter={32} style={{marginBottom: 10}}>
                                                    {items.map(item => (
                                                        <Grid.Col span={8}>
                                                            <Checkbox value={item.value}>{item.name}</Checkbox>
                                                        </Grid.Col>
                                                    ))}
                                                </Grid.Row>
                                            ))}
                                        </Checkbox.Group>
                                    </Adapter>
                                </Form.Item>
                            </Grid.Row>
                        </Form.Item>
                    </Grid.Row>
                </>
            )}
            {props.data.reportType == 'TRACE' && (
                <>
                    <Grid.Row>
                            <Form.Item
                                label="报表内容"
                                name="planId"
                            >
                                <Select params={{pageSize: 99999 }} service={app.service.tracePlanPage} labelField="name" valueField="id" />
                            </Form.Item>
                            <div />
                    </Grid.Row>
                    <Grid.Row>
                            <Form.Item
                                label="统计维度"
                                name="columnName"
                            >
                                <Select data={columns} />
                            </Form.Item>
                            <Form.Item
                                label="TopN"
                                name="topn"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="统计单位"
                                name="unitBy"
                            >
                                <Select data={constants.unit}  />
                            </Form.Item>
                    </Grid.Row>
                </>
            )}
        </Grid>
    )
}