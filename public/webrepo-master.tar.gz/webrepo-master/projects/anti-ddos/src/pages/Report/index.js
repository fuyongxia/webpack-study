import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { Route, Switch } from "react-router-dom";
import { confirm, Constant, Filters, Page, renderer, Results, Select, Table } from 'ui';
import ModalForm from './ModalForm';
import HistoryForm from './HistoryForm';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });
    const { modalForm:historyForm, setModalForm:setHistoryForm, modalFormProps: historyFormProps} = useModalForm(false, {});

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.reportEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onView(record) {
        return () => {
            setModalForm({
                type: 'view',
                title: '查看',
                data: record
            })
        }
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onHistory(record) {
        return () => {
            setHistoryForm({
                //type: 'view',
                title: '报表结果',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.reportDelete)(record)
                .then(body => {
                    setFilters({_updatedAt: Date.now()});
                })
        }
    }

    return (
        <Page title="报表">
            {Filters.create({ 
                props: filtersProps, 
                items: [
                    {
                        label: '报表名称',
                        name: 'name',
                        component: <Input />
                    },
                    {
                        label: '报表类型',
                        name: 'reportType',
                        component: <Select allowClear data={constants.report_type} />
                    },
                    {
                        label: '通知组',
                        name: 'notifyGroupId',
                        component: <Select allowClear params={{pageSize: 999}} service={app.service.notificationGroupPage} labelField="name" valueField="id" />
                    },
                    {
                        label: '统计周期',
                        name: 'period',
                        component: <Select allowClear allowClear data={constants.period} />
                    }
                ]
            })}
            <Results
                title="列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                {Table.create({
                    filters: filters,
                    service: app.service.reportPage,
                    columns: [
                        {
                            title: '报表名称',
                            dataIndex: 'name'
                        },
                        {
                            title: '报表类型',
                            dataIndex: 'reportType',
                            render: renderer.enumRender({ data: constants.report_type })
                        },
                        {
                            title: '统计周期',
                            dataIndex: 'period',
                            render: renderer.enumRender({ data: constants.period })
                        },
                        {
                            title: '通知组',
                            dataIndex: ['notifyGroup', 'name'],
                        },
                        {
                            title: '最近一次生成时间',
                            dataIndex: 'lastCreateTime',
                            render: renderer.dateRender()
                        },
                        { 
                            title: '操作',
                            render: (value, record) => {
                                return (
                                    <Space>
                                        <a onClick={onView(record)}>查看</a>
                                        <a onClick={onUpdate(record)}>编辑</a>
                                        <a onClick={onRemove(record)}>删除</a>
                                        <a onClick={onHistory(record)}>报表历史</a>
                                    </Space>
                                )
                            }
                        }
                    ]
                })}
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
            { historyForm && <HistoryForm {...historyFormProps} />}
        </Page>
    )
}

export default function(props) {
    const constants = {
        unit: [
            { name: 'bps', value: 'bps' },
            { name: 'pps', value: 'pps' },
            { name: 'bytes', value: 'bytes' },
            { name: 'packets', value: 'packets' },
        ],
        period: [
            { name: '日', value: 'DAY' },
            { name: '周', value: 'WEEK' },
            { name: '月', value: 'MONTH' },
        ],
        report_type: [
            { name: '攻击分析', value: 'ATTACK'},
            { name: '回溯分析', value: 'TRACE'},
        ],
        exec_type: [
            { name: '立即', value: 'NOW' },
            { name: '每天', value: 'DAY' },
            { name: '每周', value: 'WEEK' },
            { name: '每月', value: 'MONTH' },
        ],
        file_mode: [
            { name: 'EXCEL', value: 'EXCEL'},
            { name: 'PDF', value: 'PDF'},
        ]
    }

    return (
        <Switch>
            <Route exact path="/report">
                <Constant.Provider value={constants}>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}