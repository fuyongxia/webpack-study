import { Form, Modal, Tabs } from 'antd';
import React from 'react';
import { ScrollView } from 'ui';
import BaseInfo from './BaseInfo';
import Content from './Content';
import SendInfo from './SendInfo';

export default function (props) {

    function onValuesChange(data) {
        if('planId' in data) {
            data.columnName = '';
        }
        props.onValuesChange(data);
    }

    return (
        <Modal {...props} width={960} visible >
            <Form {...props} onValuesChange={onValuesChange} >
                <ScrollView minHeight={500} maxHeight={500}>
                    <Tabs defaultActiveKey="1">
                        <Tabs.TabPane tab="基本信息" key="1">
                            <BaseInfo {...props} />
                        </Tabs.TabPane>
                        <Tabs.TabPane tab="报表内容" key="2">
                            <Content {...props} />
                        </Tabs.TabPane>
                        <Tabs.TabPane tab="报表发送" key="3">
                            <SendInfo {...props} />
                        </Tabs.TabPane>
                    </Tabs>
                </ScrollView>
            </Form>
        </Modal>
    )
}