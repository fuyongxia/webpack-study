import React from 'react';
import { Switch as RouterSwitch, Route, useHistory, useLocation } from "react-router-dom";

function Index(props) {
    let history = useHistory();
    let location = useLocation();

    React.useEffect(() => {
        const params  = new URLSearchParams(location.hash.slice(1));
        app.storage.set('access_token', params.get('access_token'));
        history.push(params.get('callback_url') || app.config.homeUrl || '/');
    }, [location]);

    return '正在跳转中...';
}

export default function (props) {
    return (
        <RouterSwitch>
            <Route exact path="/callback" children={(
                <Index />
            )} />
        </RouterSwitch>
    )
}