import { Input, Form } from 'antd';
import { Grid } from 'ui';
import React, { useState } from 'react';

export default function(props) {    
    const [ list, setList ] = useState(props.value || []);

    function onValueChange(item, index) {
        return (e) => {
            const newVal = list.slice();
            newVal[index].authResAdditionalValue = e.target.value;
            setList(newVal);
            onChange(newVal);
        }
    }

    function onChange(newVal) {
        if(props.onChange) {
            props.onChange(newVal);
        }
    }

    return (
        <Grid>
            {list.map((item ,index) => (
                <Grid.Row>
                    <Form.Item
                        label={item.authResAdditionalName}
                    >
                        <Input value={item.authResAdditionalValue} onChange={onValueChange(item, index)} />
                    </Form.Item>
                    <></>
                </Grid.Row>
            ))}
        </Grid>
    )
}