import { Form, Input, InputNumber, Modal } from 'antd';
import React, { useContext } from 'react';
import { Constant, Grid, Select } from 'ui';
import Addition from './Addition';

export default function (props) {
    const constants = useContext(Constant.Context);
    return (
        <Modal width={720} visible {...props}>
            <Form {...props}>
                <Grid labelWidth="38px" gutter={16}>
                    <Grid.Row>
                            <Form.Item
                                label="名称"
                                name="authResName"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="标识"
                                name="authResCode"
                            >
                                <Input />
                            </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                            <Form.Item
                                label="类型"
                                name="authResType"
                            >
                                <Select data={constants.authResType} />
                            </Form.Item>
                            <Form.Item
                                label="排序"
                                name="authResIndex"
                            >
                                <InputNumber />
                            </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                                label="描述"
                                name="authResDesc"
                            >
                                <Input.TextArea />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                            name="authResAdditional"                        
                        >
                            <Addition />
                        </Form.Item>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}