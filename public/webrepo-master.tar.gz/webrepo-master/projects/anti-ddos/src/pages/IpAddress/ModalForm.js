import React, { useContext } from 'react';
import { Form, Input, Modal } from 'antd';
import { Grid, Select, Constant, ScrollView } from 'ui';

export default function (props) {
    const constants = useContext(Constant.Context);

    function onValuesChange(data) {
        if ('country' in data) {
            data.province = '';
            data.city = '';
        }
        if ('province' in data) {
            data.city = '';
        }
        props.onValuesChange(data);
    }

    return (
        <Modal {...props} width={800} visible >
            <ScrollView minHeight="600px" maxHeight="600px">
                <Form {...props} onValuesChange={onValuesChange} >
                    <Grid labelWidth="120px">
                        <Grid.Row>
                            <Grid.Col offset={3} span={18}>
                                <Form.Item
                                    label="IP"
                                    name="ip"
                                    rules={[{ required: true }]}
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="网络"
                                    name="origin"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="黑名单"
                                    name="blackList"
                                >
                                    <Select data={constants.black_list} />
                                </Form.Item>
                                <Form.Item
                                    label="国家"
                                    name="country"
                                >
                                    <Select allowClear params={{ id: 0}} service={app.service.worldAreaList} labelField="name" valueField="name" />
                                </Form.Item>
                                <Form.Item
                                    label="省份"
                                    name="province"
                                >
                                    <Select allowClear params={{ level: 0, name: props.data.country}} service={app.service.worldAreaList} labelField="name" valueField="name" />
                                </Form.Item>
                                <Form.Item
                                    label="城市"
                                    name="city"
                                >
                                    <Select allowClear params={{ level: 1, name: props.data.province}} service={app.service.worldAreaList} labelField="name" valueField="name" />
                                </Form.Item>
                                <Form.Item
                                    label="组织"
                                    name="ownerDomain"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="运营商"
                                    name="ispDomain"
                                >
                                    <Select allowClear data={constants.isp_domain} labelField="name" valueField="name"/>
                                </Form.Item>
                                <Form.Item
                                    label="经度"
                                    name="latitude"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="纬度"
                                    name="longitude"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="时区"
                                    name="timezone"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="时差"
                                    name="utcOffset"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="区域代码"
                                    name="chinaAdminCode"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="国家代码"
                                    name="iddCode"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="国家代号"
                                    name="countryCode"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="洲际代号"
                                    name="continentCode"
                                >
                                    <Input />
                                </Form.Item>
                            </Grid.Col>
                        </Grid.Row>
                    </Grid>
                </Form>
            </ScrollView>
        </Modal>
    )
}