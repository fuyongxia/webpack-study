import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { Route, Switch } from "react-router-dom";
import { confirm, Constant, Filters, Page, Results, Table, Select, renderer } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.ipAddressEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.ipAddressDelete)(record)
                .then(()=> {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    return (
        <Page title="IP地址库">
            {Filters.create({
                props: {
                    ...filtersProps,
                    onValuesChange: function(data) {
                        if ('country' in data) {
                            data.province = '';
                            data.city = '';
                        }
                        if ('province' in data) {
                            data.city = '';
                        }
                        filtersProps.onValuesChange(data);
                    }
                },
                items: [
                    {
                        label: 'IP地址',
                        name: 'ip',
                        component: <Input />
                    },
                    {
                        label: '运营商',
                        name: 'ispDomain',
                        component: <Select allowClear data={constants.isp_domain} />
                    },
                    {
                        label: '网络',
                        name: 'network',
                        component: <Input />
                    },
                   /*  {
                        label: '来源',
                        name: 'origin',
                        component: <Input />
                    }, */
                    {
                        label: '国家',
                        name: 'country',
                        component: <Select allowClear params={{ id: 0}} service={app.service.worldAreaList} labelField="name" valueField="name" />
                    },
                    {
                        label: '省份',
                        name: 'province',
                        component: <Select allowClear params={{ level: 0, name: filters.country}} service={app.service.worldAreaList} labelField="name" valueField="name" />
                    },
                    {
                        label: '城市',
                        name: 'city',
                        component: <Select allowClear params={{ level: 1, name: filters.province}} service={app.service.worldAreaList} labelField="name" valueField="name" />
                    },
                    {
                        label: '监测对象',
                        name: 'monitorObjectId',
                        component: <Select allowClear service={app.service.customerPage} labelField="custname" valueField="custid" />
                    },
                    {
                        label: '黑名单',
                        name: 'blackList',
                        component: <Select allowClear data={constants.black_list} />
                    }
                ]
            })}
            <Results
                title="列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                {Table.create({
                    filters,
                    service: app.service.ipAddressPage,
                    columns: [
                        {
                            title: 'IP',
                            dataIndex: 'ip'
                        },
                        {
                            title: '运营商',
                            dataIndex: 'ispDomain',
                            //render: renderer.enumRender({ data: constants.isp_domain })
                        },
                        {
                            title: '网络',
                            dataIndex: 'network'
                        },
                        /* {
                            title: '来源',
                            dataIndex: 'origin'
                        }, */
                        {
                            title: '国家',
                            dataIndex: 'country'
                        },
                        {
                            title: '省份',
                            dataIndex: 'province'
                        },
                        {
                            title: '城市',
                            dataIndex: 'city'
                        },
                        {
                            title: '检测对象',
                            dataIndex: ['baseCustomer', 'custname']
                        },
                        {
                            title: '黑名单',
                            dataIndex: 'blackList',
                            render: renderer.enumRender({ data: constants.black_list })
                        },
                        {
                            title: '更新时间',
                            dataIndex: 'updateTime',
                            render: renderer.dateRender()
                        },
                        {
                            title: '操作',
                            render: renderer.actionRender([
                                {
                                    title: '编辑',
                                    action: onUpdate
                                },
                                {
                                    title: '删除',
                                    action: onRemove
                                },
                            ])
                        },
                    ]
                })}
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function (props) {
    const constants = {
        black_list: [
            { name: '是', value: 'Y' },
            { name: '否', value: 'N' },
        ]
    }

    return (
        <Switch>
            <Route exact path="/ip_address">
                <Constant.Provider value={constants}>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}