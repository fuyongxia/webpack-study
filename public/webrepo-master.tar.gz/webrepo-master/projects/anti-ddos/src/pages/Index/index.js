import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space, Table } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React from 'react';
import { Route, Switch } from "react-router-dom";
import { confirm, Constant, Filters, Page, Results } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove() {
        return () => {
            confirm
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="页面名称">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="接入器名称"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table service={app.service.accessPointList} filters={filters}>
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/appliance">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}