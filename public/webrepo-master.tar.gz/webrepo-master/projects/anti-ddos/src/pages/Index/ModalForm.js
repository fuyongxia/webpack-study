import React, { useContext } from 'react';
import { Modal, Form, Row, Col, Input, Select, Button, Space } from 'antd';
import { Grid } from 'ui';

export default function (props) {
    return (
        <Modal {...props} width={800} visible >
            <Form {...props} >
                <Grid labelWidth="90px" gutter={16}>
                </Grid>
            </Form>
        </Modal>
    )
}