import { Form, Tabs, Button } from 'antd';
import { useTableFilters } from 'hooks';
import JsFileDownload from 'js-file-download';
import React, { useContext, useEffect, useState } from 'react';
import { Route, Switch, useLocation } from "react-router-dom";
import { Constant, Grid, Select, Table, Filters, Page, Results, renderer } from 'ui';
import FlowN from './FlowN';
import TopN from './TopN';
import { ExportOutlined } from '@ant-design/icons';

function Index(props) {
    const constants = useContext(Constant.Context);
    const location = useLocation();
    const params = new URLSearchParams(location.search);

    const [attackInfo, setAttackInfo] = useState({});
    const { filters, setFilters, filtersProps } = useTableFilters({
        boundaryType: 'ALL',
        boundaryValue: '',
        attackId: params.get('attackId'),
        origin: params.get('origin')
    });

    useEffect(() => {
        app.service.attackDdosInfo(filters)
            .then(body => {
                setAttackInfo(body);
            })
    }, [filters._updatedAt])

    const onExport = function () {
        fetch("api/v1/unicontroller/attack/ddos/flowTopExport", {
            method: 'POST',
            body: JSON.stringify(filters),
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${app.storage.get('access_token')}`
            },
            credentials: 'include',
            responseType: 'blob'
        })
            .then(res => {
                const fileConfig = res.headers.get('content-disposition');
                const name = fileConfig.split('filename=')[1];
                const filename = decodeURIComponent(name.split('.')[0]) + '.' + name.split('.')[1];
                return res.blob()
                    .then(blob => {
                        JsFileDownload(blob, filename, 'application/vnd.ms-excel')
                    })
            })
            .catch(error => console.error('Error:', error));
    }

    return (
        <Page title="攻击统计">
            <Filters {...filtersProps}
                extra={[
                    <Button type="primary" onClick={onExport}><ExportOutlined />导出</Button>
                ]}
            >
                <Filters.Item
                    label="网络边界"
                    name="boundaryType"
                >
                    <Select allowClear data={constants.net_boundary_type} />
                </Filters.Item>
                {filters.boundaryType == 'FLOW_RESOURCE' && (
                    <Filters.Item
                        label=""
                        colon=""
                        name="boundaryValue"
                    >
                        <Select allowClear params={{ pageSize: 999 }} service={app.service.routerPage} labelField="name" valueField="routerid" />
                    </Filters.Item>
                )}
            </Filters>
            <Results>
                <Grid>
                    <Grid.Row>
                        <Form.Item label="攻击ID">{_.get(attackInfo, 'attackId')}</Form.Item>
                        <Form.Item label="监测对象">{_.get(attackInfo, ['cust', 'custname'])}</Form.Item>
                        <Form.Item label="对象类型">{renderer.enumRender({ data: constants.detect_object_type })(_.get(attackInfo, ['cust', 'type']))}</Form.Item>
                        <Form.Item label="攻击目标">{_.get(attackInfo, 'attackTarget')}</Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item label="攻击类型">{_.get(attackInfo, ['attackTypeObject', 'primaryName'])}</Form.Item>
                        <Form.Item label="告警级别">{renderer.enumRender({ data: constants.attack_level })(_.get(attackInfo, 'level'))}</Form.Item>
                        <Form.Item label="攻击方向">{renderer.enumRender({ data: constants.attack_direction })(_.get(attackInfo, 'direction'))}</Form.Item>
                        <Form.Item label="当前状态">{renderer.enumRender({ data: constants.attack_status })(_.get(attackInfo, 'status'))}</Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item label="开始时间">{renderer.dateRender()(_.get(attackInfo, 'startTime'))}</Form.Item>
                        <Form.Item label="结束时间">{renderer.dateRender()(_.get(attackInfo, 'endTime'))}</Form.Item>
                        <Form.Item label="持续时间">{renderer.durationRender()(_.get(attackInfo, 'duration'))}</Form.Item>
                        <Form.Item label=""></Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item label="流速峰值">{renderer.flowRender()(_.get(attackInfo, 'maxBps'))}</Form.Item>
                        <Form.Item label="包速峰值">{renderer.flowRender()(_.get(attackInfo, 'maxPps'))}</Form.Item>
                        <Form.Item label="总字节数">{renderer.flowRender()(_.get(attackInfo, 'btyecount'))}</Form.Item>
                        <Form.Item label="总包数">{renderer.flowRender()(_.get(attackInfo, 'packcount'))}</Form.Item>
                    </Grid.Row>
                </Grid>
            </Results>
            <Results>
                <Tabs defaultActiveKey="1">
                    <Tabs.TabPane tab="Flow特征摘要" key="1">
                        <FlowN {...filters} />
                    </Tabs.TabPane>
                    {!filters.origin && (
                        <>
                            <Tabs.TabPane tab="Top源IP" key="2">
                                <TopN {...filters} topType="SRC_IP" />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="Top目的IP" key="21">
                                <TopN {...filters} topType="DST_IP" />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="Top源端口" key="3">
                                <TopN {...filters} topType="SRC_PORT" />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="Top目的端口" key="31">
                                <TopN {...filters} topType="DST_PORT" />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="Top协议" key="4">
                                <TopN {...filters} topType="PROTOCOL" />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="TopTCP标识" key="5">
                                <TopN {...filters} topType="FLAG" />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="Top源运营商" key="6">
                                <TopN {...filters} topType="VENDOR" />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="Top源城市" key="7">
                                <TopN {...filters} topType="CITY" />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="Top源应用" key="8">
                                <TopN {...filters} topType="SRC_APP" />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="Top目的应用" key="81">
                                <TopN {...filters} topType="DST_APP" />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="Top接口" key="9">
                                <TopN {...filters} topType="INTERFACE" />
                            </Tabs.TabPane>
                        </>
                    )}
                </Tabs>
            </Results>
        </Page>
    )
}

export default function (props) {
    const constants = {
        net_boundary_type: [
            { name: '全网范围', value: 'ALL' },
            { name: '对象网络边界', value: 'OBJECT' },
            { name: '网络设备', value: 'FLOW_RESOURCE' },
        ]
    }

    return (
        <Switch>
            <Route exact path="/attack_count">
                <Constant.Provider value={constants}>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}