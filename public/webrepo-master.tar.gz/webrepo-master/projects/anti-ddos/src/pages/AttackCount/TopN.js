import React, { useState, useContext } from 'react';
import { Grid, ScrollView, Table, Constant, renderer } from 'ui';
import { Pie } from '@ant-design/charts';

export default function(props) {
    const [ chartData, setChartData ] = useState([]);
    const constants = useContext(Constant.Context);

    let columns = [];
    if (props.topType == 'SRC_IP') {
        columns = [
            {
                title: '源IP地址',
                dataIndex: 'name'
            },
            {
                title: '虚假源',
                dataIndex: 'isRealIp',
                render: renderer.enumRender({ data: constants.ip_is_real})
            }
        ]
    }

    if (props.topType == 'DST_IP') {
        columns = [
            {
                title: '目的IP地址',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'SRC_PORT' || props.topType == 'DST_PORT') {
        columns = [
            {
                title: '端口号',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'PROTOCOL') {
        columns = [
            {
                title: '协议',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'FLAG') {
        columns = [
            {
                title: 'TCP标识',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'VENDOR') {
        columns = [
            {
                title: '运营商',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'CITY') {
        columns = [
            {
                title: '城市',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'SRC_APP' || props.topType == 'DST_APP') {
        columns = [
            {
                title: '应用',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'INTERFACE') {
        columns = [
            {
                title: '接口',
                dataIndex: 'name'
            },
            {
                title: '路由器',
                dataIndex: 'router'
            },
            {
                title: '方向',
                dataIndex: 'direction',
                render: renderer.enumRender({ data: constants.attack_direction})
            },
            {
                title: '网络边界',
                dataIndex: 'boundary'
            },
        ]
    }


    return (
        <ScrollView minHeight={1080} maxHeight={1080}>
        <Grid>
            <Grid.Row gutter={32}>
                <Pie
                {...{
                    appendPadding: 10,
                    data: chartData,
                    angleField: 'bps',
                    colorField: 'name',
                    radius: 0.8,
                }}
                />
                <Pie
                {...{
                    appendPadding: 10,
                    data: chartData,
                    angleField: 'pps',
                    colorField: 'name',
                    radius: 0.8,
                }}
                />
            </Grid.Row>
            <Grid.Row>
                {Table.create({
                    filters: {
                        attackId: props.attackId,
                        boundaryType: props.boundaryType,
                        boundaryValue: props.boundaryValue,
                        topType: props.topType,
                        _updatedAt: props._updatedAt
                    },
                    service: _.wrap(app.service.attackDdosCount, (func, args) => {
                        return func(args).then(body => {
                            setChartData(body);
                            return body;
                        })
                    }),
                    columns: [
                        ...columns,
                        {
                            title: '平均流速(bps)',
                            dataIndex: 'bps',
                            render: renderer.flowRender()
                        },
                        {
                            title: '平均包速(pps)',
                            dataIndex: 'pps',
                            render: renderer.flowRender()
                        },
                        {
                            title: '总字节数(bytes)',
                            dataIndex: 'bytecount',
                            render: renderer.flowRender()
                        },
                        {
                            title: '总包数(pckts)',
                            dataIndex: 'packcount',
                            render: renderer.flowRender()
                        },
                        {
                            title: '总字节数占比',
                            dataIndex: 'byteRate'
                        },
                        {
                            title: '总包数占比',
                            dataIndex: 'packRate'
                        },
                        {
                            title: '操作'
                        }
                    ]
                })}
            </Grid.Row>
        </Grid>
        </ScrollView>
    )

}