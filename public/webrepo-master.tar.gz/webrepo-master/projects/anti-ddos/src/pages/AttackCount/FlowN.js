import React, { useState, useContext } from 'react';
import {Constant, Grid, ScrollView, Table, renderer } from 'ui';
import { useStyles } from 'hooks';

function AttrTable(props) {
    const constants = useContext(Constant.Context);

    const classes = useStyles({
        'attrTable': {
            '& tr td': {
                height: 36
            }
        }
    })

    let columns = [];
    if (props.topType == 'SRC_IP') {
        columns = [
            {
                title: '源IP地址',
                dataIndex: 'name'
            },
            {
                title: '虚假源',
                dataIndex: 'isRealIp',
                render: renderer.enumRender({ data: constants.ip_is_real})
            }
        ]
    }

    if (props.topType == 'DST_IP') {
        columns = [
            {
                title: '目的IP地址',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'SRC_PORT') {
        columns = [
            {
                title: '源端口号',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'DST_PORT') {
        columns = [
            {
                title: '目的端口号',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'PROTOCOL') {
        columns = [
            {
                title: '协议',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'FLAG') {
        columns = [
            {
                title: 'TCP标识',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'VENDOR') {
        columns = [
            {
                title: '运营商',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'CITY') {
        columns = [
            {
                title: '城市',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'SRC_APP') {
        columns = [
            {
                title: '源应用',
                dataIndex: 'name'
            }
        ]
    }

    if(props.topType == 'DST_APP') {
        columns = [
            {
                title: '目的应用',
                dataIndex: 'name'
            }
        ]
    }

    if (props.topType == 'INTERFACE') {
        columns = [
            {
                title: '接口',
                dataIndex: 'name'
            },
            {
                title: '路由器',
                dataIndex: 'router'
            },
            {
                title: '方向',
                dataIndex: 'direction',
                render: renderer.enumRender({ data: constants.attack_direction})
            },
            {
                title: '网络边界',
                dataIndex: 'boundary'
            },
        ]
    }

    return (
        <ScrollView >
            {Table.create({
                className: classes.attrTable,
                filters: {
                    attackId: props.attackId,
                    boundaryType: props.boundaryType,
                    boundaryValue: props.boundaryValue,
                    topType: props.topType,
                    _updatedAt: props._updatedAt
                },
                service: (args) => {
                    return app.service.attackDdosCount(args)
                        .then(body => {
                            if (body.length > 5) {
                                return body.slice(0, 5);
                            } else {
                                return _.merge([{}, {}, {}, {}, {}], body);
                            }
                        })
                },
                columns: [
                    ...columns,
                    {
                        title: '流速(bps)',
                        dataIndex: 'bps',
                        render: renderer.flowRender()
                    },
                    {
                        title: '流速占比',
                        dataIndex: 'bpsRate'
                    },
                    {
                        title: '包速(pps)',
                        dataIndex: 'pps',
                        render: renderer.flowRender()
                    },
                    {
                        title: '包速占比',
                        dataIndex: 'ppsRate'
                    }
                ],
                size: 'small',
                bordered: true,
                pagination: false,
                style: {
                    marginBottom: 10
                }
            })}
        </ScrollView>
    )
}

export default function (props) {
    return (
        <ScrollView minHeight={1080}>
            <Grid gutter={32}>
                <Grid.Row>
                    <Grid.Col span={12}>
                        <AttrTable {...props} topType="SRC_IP" />
                        <AttrTable {...props} topType="DST_IP" />
                        <AttrTable {...props} topType="PROTOCOL" />
                        <AttrTable {...props} topType="VENDOR" />
                        <AttrTable {...props} topType="CITY" />
                    </Grid.Col>
                    <Grid.Col span={12}>
                    <AttrTable {...props} topType="SRC_PORT" />
                        <AttrTable {...props} topType="DST_PORT" />
                        <AttrTable {...props} topType="FLAG" />
                        <AttrTable {...props} topType="SRC_APP" />
                        <AttrTable {...props} topType="DST_APP" />
                    </Grid.Col>
                </Grid.Row>
                <Grid.Row>
                    <AttrTable {...props} topType="INTERFACE" />
                </Grid.Row>
            </Grid>
        </ScrollView>
    )
}