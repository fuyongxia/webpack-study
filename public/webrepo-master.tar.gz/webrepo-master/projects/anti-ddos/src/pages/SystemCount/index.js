import React, { useState, useEffect } from 'react';
import { Grid, Page, Constant } from 'ui';
import { Route, Switch } from "react-router-dom";
import StatItem from './StatItem';

function Index(props) {
    const [ data, setData ] = useState([]);

    useEffect(() => {
        app.service.monitorSystemCount()
            .then(body => {
                setData(body || []);
            })
    }, []);

    return (
        <Page title="资源统计">
            <Grid gutter={16}>
                <Grid.Row>
                    <StatItem title="监测设备" data={data.filter(item => item.type == 'DEVICE')} />
                    <StatItem title="数据采集" data={data.filter(item => item.type == 'DATA')} />
                </Grid.Row>
                <Grid.Row>
                    <StatItem title="网络设备接口" data={data.filter(item => item.type == 'INTERFACE')} />
                    <StatItem title="网络边界" data={data.filter(item => item.type == 'BOUNDARY')} />
                </Grid.Row>
                <Grid.Row>
                    <StatItem title="用户/通知" data={data.filter(item => item.type == 'USER')} />
                    <StatItem title="监测对象" data={data.filter(item => item.type == 'OBJECT')} />
                </Grid.Row>
                <Grid.Row>
                    <StatItem title="应用" data={data.filter(item => item.type == 'APP')} />
                    <StatItem title="IP地址库" data={data.filter(item => item.type == 'IP')} />
                </Grid.Row>
            </Grid>
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/system_count">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}