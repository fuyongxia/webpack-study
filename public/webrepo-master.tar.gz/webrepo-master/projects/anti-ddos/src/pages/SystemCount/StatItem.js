import React from 'react';
import { Card } from 'antd';
import { useStyles } from 'hooks';

export default function (props) {
    const styles = useStyles({
        "table": {
            width: '100%',
            "& th,td": {
                border: '1px solid #ddd',
                lineHeight: 2.5,
                padding: '0 10px'
            }
        }
    });

    const { data = [] } = props;
    return (
        <Card title={props.title} style={{ marginTop: 16 }}>
            <table className={styles.table}>
                <thead>
                    <tr>
                        <th>资源类别</th>
                        <th>资源描述</th>
                        <th>已配数量</th>
                        <th>上限数量</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map(item => (
                        <tr>
                            <td>{item.name}</td>
                            <td>{item.desc}</td>
                            <td>{item.item.usedSize}</td>
                            <td>{item.item.maxSize}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </Card>
    )
}