import React, { useContext } from 'react';
import { Form, Input } from 'antd';
import { Grid, Select, Constant } from 'ui';

export default function(props) {
    const constants = useContext(Constant.Context);
    return (
        <Grid labelWidth="120px">
            <Grid.Row>
                <Grid.Col offset={3} span={18}>
                    <Form.Item
                        label="匹配方式"
                        name="matchconditionType"
                    >
                        <Select data={constants.detect_object_match} />
                    </Form.Item>
                    <Form.Item
                        label="匹配内容"
                        name="matchcondition"
                    >
                        <Input.TextArea />
                    </Form.Item>
                </Grid.Col>
            </Grid.Row>
        </Grid>

    )
}