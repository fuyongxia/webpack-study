import { Button, Input, message, Radio, Space, Table } from 'antd';
import React, { useEffect, useState } from 'react';
import { Select, Switch } from 'ui';

export default function(props) {
    const [options, setOptions] = useState({
        status: 'all'
    });
    const [results, setResults] = useState([]);

    useEffect(() => {
        const body = props.value || {};
        setOptions({
            ...options,
            ipv4Enable: body.ipv4Enable || "OFF",
            ipv6Enable: body.ipv6Enable || "OFF"
        })
        if (!body.thresholdSetting){
            return;
        }
        setResults((body.thresholdSetting).map((item, index) => ({
            ...item, _index: index + 1
        })));
    }, [])

    useEffect(() => {
        if (props.onChange) {
            props.onChange({
                ipv4Enable: options.ipv4Enable,
                ipv6Enable: options.ipv6Enable,
                thresholdSetting: results
            })
        }
    }, [JSON.stringify(results), JSON.stringify(options)])

    function onFieldChange(record, field) {
        return value => {
            const records = results.slice();
            const matched = records.find(item => item.id == record.id);
            if (matched) {
                matched[field] = value.target ? value.target.value : value;
                setResults(records);
            }
        }
    }

    function prototypeRender(value, record) {
        return (
            <Space direction="vertical" align="center" size="large">
                <span>IPv4</span>
                <span>IPv6</span>
            </Space>
        )
    }

    function switchRender(value, record) {
        return (
            <Space direction="vertical" align="center">
                <Switch value={record.ipv4PpsEnable}  onChange={onFieldChange(record, 'ipv4PpsEnable')}  />
                <Switch value={record.ipv4BpsEnable}  onChange={onFieldChange(record, 'ipv4BpsEnable')}  />
                <Switch value={record.ipv6PpsEnable}  onChange={onFieldChange(record, 'ipv6PpsEnable')}  />
                <Switch value={record.ipv6bpsEnable}  onChange={onFieldChange(record, 'ipv6bpsEnable')}  />
            </Space>
        )
    }

    function triggerRender(value, record) {
        return (
            <Space>
                <Space direction="vertical" align="center">
                    <Input size="small" value={record.ipv4PpsTriggerRate} onChange={onFieldChange(record, 'ipv4PpsTriggerRate')} />
                    <Input size="small" value={record.ipv4BpsTriggerRate} onChange={onFieldChange(record, 'ipv4BpsTriggerRate')} />
                    <Input size="small" value={record.ipv6PpsTriggerRate} onChange={onFieldChange(record, 'ipv6PpsTriggerRate')} />
                    <Input size="small" value={record.ipv6BpsTriggerRate} onChange={onFieldChange(record, 'ipv6BpsTriggerRate')} />
                </Space>
                <Space direction="vertical" align="center">
                    <Select size="small" value={record.ipv4PpsTriggerUnit}  onChange={onFieldChange(record, 'ipv4PpsTriggerUnit')}  style={{ width: 90 }}>
                        <Select.Option value="pps">pps</Select.Option>
                        <Select.Option value="Kpps">Kpps</Select.Option>
                        <Select.Option value="Mpps">Mpps</Select.Option>
                    </Select>
                    <Select size="small"  value={record.ipv4BpsTriggerUnit} onChange={onFieldChange(record, 'ipv4BpsTriggerUnit')}  style={{ width: 90 }}>
                        <Select.Option value="bps">bps</Select.Option>
                        <Select.Option value="Kbps">Kbps</Select.Option>
                        <Select.Option value="Mbps">Mbps</Select.Option>
                    </Select>
                    <Select size="small"  value={record.ipv6PpsTriggerUnit} onChange={onFieldChange(record, 'ipv6PpsTriggerUnit')}  style={{ width: 90 }}>
                        <Select.Option value="pps">pps</Select.Option>
                        <Select.Option value="Kpps">Kpps</Select.Option>
                        <Select.Option value="Mpps">Mpps</Select.Option>
                    </Select>
                    <Select size="small"  value={record.ipv6BpsTriggerUnit} onChange={onFieldChange(record, 'ipv6BpsTriggerUnit')}  style={{ width: 90 }}>
                        <Select.Option value="bps">bps</Select.Option>
                        <Select.Option value="Kbps">Kbps</Select.Option>
                        <Select.Option value="Mbps">Mbps</Select.Option>
                    </Select>
                </Space>
            </Space>
        )
    }

    function severityRender(value, record) {
        return (
            <Space>
                <Space direction="vertical" align="center">
                    <Input size="small" value={record.ipv4PpsSeverityRate}  onChange={onFieldChange(record, 'ipv4PpsSeverityRate')} />
                    <Input size="small" value={record.ipv4BpsSeverityRate}  onChange={onFieldChange(record, 'ipv4BpsSeverityRate')} />
                    <Input size="small" value={record.ipv6PpsSeverityRate}  onChange={onFieldChange(record, 'ipv6PpsSeverityRate')} />
                    <Input size="small" value={record.ipv6BpsSeverityRate}  onChange={onFieldChange(record, 'ipv6BpsSeverityRate')} />
                </Space>
                <Space direction="vertical" align="center">
                     <Select size="small" value={record.ipv4PpsSeverityUnit}  onChange={onFieldChange(record, 'ipv4PpsSeverityUnit')} style={{ width: 90 }}>
                        <Select.Option value="pps">pps</Select.Option>
                        <Select.Option value="Kpps">Kpps</Select.Option>
                        <Select.Option value="Mpps">Mpps</Select.Option>
                    </Select>
                    <Select size="small"  value={record.ipv4BpsSeverityUnit}  onChange={onFieldChange(record, 'ipv4BpsSeverityUnit')} style={{ width: 90 }}>
                        <Select.Option value="bps">bps</Select.Option>
                        <Select.Option value="Kbps">Kbps</Select.Option>
                        <Select.Option value="Mbps">Mbps</Select.Option>
                    </Select>
                    <Select size="small" value={record.ipv6PpsSeverityUnit}  onChange={onFieldChange(record, 'ipv6PpsSeverityUnit')} style={{ width: 90 }}>
                        <Select.Option value="pps">pps</Select.Option>
                        <Select.Option value="Kpps">Kpps</Select.Option>
                        <Select.Option value="Mpps">Mpps</Select.Option>
                    </Select>
                    <Select size="small"  value={record.ipv6BpsSeverityUnit}  onChange={onFieldChange(record, 'ipv6BpsSeverityUnit')} style={{ width: 90 }}>
                        <Select.Option value="bps">bps</Select.Option>
                        <Select.Option value="Kbps">Kbps</Select.Option>
                        <Select.Option value="Mbps">Mbps</Select.Option>
                    </Select>
                </Space>
            </Space>
        )
    }

    function getResults() {
        let filteredResults = results;

        if (options.status == 'enabled') {
            filteredResults = filteredResults.filter(item => [
                item.ipv4PpsEnable,
                item.ipv4BpsEnable,
                item.ipv6PpsEnable,
                item.ipv6bpsEnable
            ].some(item => item == 'ON'))
        }

        return filteredResults;
    }

    function onOptionChange(field) {
        return (value) => {
            setOptions({
                ...options,
                [field]: value.target ? value.target.value : value
            })
        }
    }

    function onLoad() {
        app.service.wholeThresholdView({})
            .then(body =>{
                setOptions({
                    ...options,
                    ipv4Enable: body.ipv4Enable,
                    ipv6Enable: body.ipv6Enable
                })
                setResults(body.thresholdSetting.slice());
                message.info('加载成功');
            })
    }


    return (
        <div>
            <Space>
                <div style={{ marginRight: 20 }}>
                        <label style={{ marginRight: 10 }}>开启DDoS攻击检测</label>
                        <Space>
                            <div> IPv4 <Switch value={options.ipv4Enable} onChange={onOptionChange('ipv4Enable')} /> </div>
                            <div> IPv6 <Switch value={options.ipv6Enable} onChange={onOptionChange('ipv6Enable')} /> </div>
                        </Space>
                </div>
                <Radio.Group value={options.status} onChange={onOptionChange('status')}>
                        <Radio value="all">显示所有</Radio>
                        <Radio value="enabled">显示开启</Radio>
                </Radio.Group>
                <Button type="primary" onClick={onLoad} >加载全局默认阈值</Button>
            </Space>
            <div style={{marginTop: 20}}>
                <Table dataSource={getResults()} bordered size="middle">
                    <Table.Column title="ID" dataIndex="_index" />
                    <Table.Column title="攻击类型" dataIndex="protocolType" />
                    <Table.Column title="协议类型" render={prototypeRender} />
                    <Table.Column title="是否开启" render={switchRender} />
                    <Table.Column title="触发速率" render={triggerRender} />
                    <Table.Column title="高危速率" render={severityRender} />
                </Table>
            </div>
        </div>

    )
}