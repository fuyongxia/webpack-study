import React, { useContext } from 'react';
import { Switch, Route } from "react-router-dom";
import { Input, Button, Space, Modal } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { Page, Filters, Results, Select, Table, Constant, renderer, confirm } from 'ui';
import { useTableFilters, useTableResults, useModalForm } from 'hooks';
import ModalForm from './ModalForm';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.customerEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onView(record) {
        return () => {
            app.service.customerView({custcode: record.custcode})
                .then(body => {
                    setModalForm({
                        type: 'view',
                        title: '查看',
                        data: body
                    })
                })
        }
    }

    function onUpdate(record) {
        return () => {
            app.service.customerView({custcode: record.custcode})
            .then(body => {
                setModalForm({
                    type: 'update',
                    title: '修改',
                    data: body
                })
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.customerDelete)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onView(record)}>查看</a>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="监测对象">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="对象ID"
                    name="custcode"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="对象名称"
                    name="custname"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="对象类型"
                    name="type"
                >
                    <Select allowClear data={constants.detect_object_type} />
                </Filters.Item>
                <Filters.Item
                    label="对象等级"
                    name="level"
                >
                    <Select allowClear data={constants.detect_object_level} />
                </Filters.Item>
                <Filters.Item
                    label="城市"
                    name="city"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="网络边界类型"
                    name="netboundaryType"
                >
                    <Select allowClear data={constants.netboundary_type} />
                </Filters.Item>
            </Filters>
            <Results
                title="监测对象列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table service={app.service.customerPage} filters={filters}>
                    <Table.Column title="对象ID" dataIndex="custcode" />
                    <Table.Column title="对象名称" dataIndex="custname" />
                    <Table.Column title="对象类型" dataIndex="type" render={renderer.enumRender({ data: constants.detect_object_type})} />
                    <Table.Column title="对象等级" dataIndex="level" render={renderer.enumRender({ data: constants.detect_object_level})} />
                    <Table.Column title="城市" dataIndex="city" />
                    <Table.Column title="匹配条件" dataIndex="matchcondition" render={renderer.lineRender()} />
                    <Table.Column title="网络边界类型" dataIndex="netboundaryType" render={renderer.enumRender({ data: constants.netboundary_type})} />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function (props) {
    const constants = {
        netboundary_type: [
            { name: '全网', value: 'DEFAULT'},
            { name: '自定义', value: 'DEFINED'},
        ]
    }

    return (
        <Switch>
            <Route exact path="/customer" children={(
                <Constant.Provider value={constants}>
                     <Index />
                </Constant.Provider>
            )} />
        </Switch>
    )
}