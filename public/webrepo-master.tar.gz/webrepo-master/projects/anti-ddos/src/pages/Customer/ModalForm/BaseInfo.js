import React, { useContext } from 'react';
import { Form, Input } from 'antd';
import { Grid, Select, Constant, ProvinceSelect, CitySelect } from 'ui';

export default function(props) {
    const constants = useContext(Constant.Context);

    return (
        <Grid labelWidth="120px">
            <Grid.Row>
                <Grid.Col offset={3} span={18}>
                    {props.type == 'view' && (
                        <Form.Item
                            label="对象ID"
                            name="custcode"
                        >
                            <Input />
                        </Form.Item>
                    )}
                    <Form.Item
                        label="对象名称"
                        name="custname"
                        rules={[{ required: true }]}
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        label="对象描述"
                        name="description"
                    >
                        <Input.TextArea />
                    </Form.Item>
                    <Form.Item
                        label="对象类型"
                        name="type"
                        rules={[{ required: true }]}
                    >
                        <Select data={constants.detect_object_type} />
                    </Form.Item>
                    <Form.Item
                        label="对象所属省份"
                        name="province"
                    >
                        <ProvinceSelect />
                    </Form.Item>
                    <Form.Item
                        label="对象所属城市"
                        name="city"
                    >
                        <CitySelect province={props.data.province} />
                    </Form.Item>
                    <Form.Item
                        label="对象等级"
                        name="level"
                    >
                         <Select data={constants.detect_object_level} />
                    </Form.Item>
                    <Form.Item
                        label="带宽"
                        name="bandwidth"
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        label="网络边界类型"
                        name="netboundaryType"
                        rules={[{ required: true }]}
                    >
                        <Select data={constants.netboundary_type} />
                    </Form.Item>
                    {props.data.netboundaryType == 'DEFINED' && (
                        <Form.Item
                            label="网络边界"
                            name="netboundary"
                            rules={[{ required: true }]}
                        >
                            <Select service={app.service.groupPage} labelField="name" valueField="uuid" />
                        </Form.Item>
                    )}
                </Grid.Col>
            </Grid.Row>
        </Grid>
    )
}