import React from 'react';
import { Modal, Form, Tabs } from 'antd';
import { ScrollView } from 'ui';
import BaseInfo from './BaseInfo';
import Condition from './Condition';
import Threshold from './Threshold';

export default function (props) {
    function onValuesChange(data) {
        if ('province' in data) {
            data.city = '';
        }
        props.onValuesChange(data);
    }

    return (
        <Modal {...props} width={1000} visible >
            <ScrollView minHeight="600px" maxHeight="600px">
            <Form {...props} onValuesChange={onValuesChange} >
                <Tabs defaultActiveKey="1" >
                    <Tabs.TabPane key="1" tab="基本信息">
                        <BaseInfo {...props} />
                    </Tabs.TabPane>
                    <Tabs.TabPane key="2" tab="匹配条件">
                        <Condition {...props} />
                    </Tabs.TabPane>
                    <Tabs.TabPane key="3" tab="检测阈值">
                        <Form.Item name="thresholdData" noStyle>
                            <Threshold />
                        </Form.Item>
                    </Tabs.TabPane>
                </Tabs>
            </Form>
            </ScrollView>
        </Modal>
    )
}