import { PlusOutlined } from '@ant-design/icons';
import { Switch, Route } from "react-router-dom";
import { Button, Input, InputNumber, Space } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React from 'react';
import { confirm, Filters, Page, Results, Table, Constant } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.applicationEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'add',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.applicationDelete)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now });
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="应用管理">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="应用名称"
                    name="name"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="TCP端口"
                    name="tcpPorts"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="UDP端口"
                    name="udpPorts"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="应用列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table filters={filters} service={app.service.applicationPage}>
                    <Table.Column title="应用名称"  dataIndex="name" />
                    <Table.Column title="应用描述"  dataIndex="description" />
                    <Table.Column title="TCP端口"  dataIndex="tcpPorts" />
                    <Table.Column title="UDP端口"  dataIndex="udpPorts" />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/application">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}