import React, { useRef } from 'react';
import { Modal, Form, Row, Col, Input, InputNumber, Select, Button, Space } from 'antd';
import { Grid } from 'ui';

export default function (props) {
    const formRef = useRef(null);
    return (
        <Modal {...props} width={800} visible onOk={()=>formRef.current.submit()} >
            <Form ref={formRef} {...props} >
                <Grid labelWidth="90px" gutter={16}>
                    <Grid.Row>
                        <Grid.Col span={18} offset={3}>
                        <Form.Item
                            label="应用名称"
                            name="name"
                            rules={[{ required: true }]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="应用描述"
                            name="description"
                        >
                            <Input.TextArea />
                        </Form.Item>
                        <Form.Item
                            label="TCP端口"
                            name="tcpPorts"
                            extra="请输入0~65535范围内端口号并以逗号分隔"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item 
                            label="UDP端口"
                            name="udpPorts"
                            extra="请输入0~65535范围内端口号并以逗号分隔"
                        >
                            <Input />
                        </Form.Item>
                        </Grid.Col>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}