import { Form, Input, Modal, TreeSelect } from 'antd';
import React, { useEffect, useState } from 'react';
import { Grid, Select, util } from 'ui';

export default function (props) {
    const [ orgs, setOrgs ] = useState([]);

    useEffect(() => {
        app.service.orgList({ pageSize: 0 })
            .then(body => {
                const root = util.denormalize(body.results || body, {
                    id: 'authOrgId',
                    pid: 'authOrgPid',
                    root: {
                        authOrgId: 0
                    },
                    transform(item) {
                        return {
                            ...item,
                            key: item.authOrgId,
                            value: item.authOrgId,
                            title: item.authOrgName
                        }
                    }
                })
                setOrgs(root.children);
            })

    }, [])


    return (
        <Modal width={640} visible {...props}>
            <Form {...props}>
                <Grid labelWidth="68px" gutter={16}>
                    <Grid.Row>
                            <Form.Item
                                label="名称"
                                name="authUserUsername"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="标识"
                                name="authUserCode"
                            >
                                <Input />
                            </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                            <Form.Item
                                label="昵称"
                                name="authUserNick"
                            >
                                <Input />
                            </Form.Item>
                        <Form.Item
                            label="密码"
                            name="authUserPasswordOrigin"
                        >
                            <Input type="password" />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                                label="手机"
                                name="authUserMobile"
                            >
                                <Input />
                        </Form.Item>
                        <Form.Item
                                label="邮箱"
                                name="authUserMail"
                            >
                                <Input />
                            </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                                label="角色"
                                name="roles"
                            >
                                <Select mode="multiple" valueType='array' service={app.service.roleList} labelField="authRoleName" valueField="authRoleId" />
                        </Form.Item>
                        <Form.Item
                                label="组织机构"
                                name="orgs"
                            >
                                <TreeSelect
                                    treeData={orgs}
                                    treeCheckable={true}
                                    showCheckedStrategy={TreeSelect.SHOW_PARENT}
                                />
                        </Form.Item>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}