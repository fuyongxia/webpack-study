import { PlusOutlined } from '@ant-design/icons';
import { Switch as RouterSwitch, Route } from "react-router-dom";
import { Button, Input, Space } from 'antd';
import { useModalForm, useService, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { confirm, Constant, Filters, Page, Table, Results, renderer } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        const data = {
            ...modalForm.data,
            orgs: modalForm.data.orgs.map(item => ({
                authOrgId: item
            })),
            roles: modalForm.data.roles.map(item => ({
                authRoleId: item
            })),
        }

        if (modalForm.type == 'add') {
            app.service.userSave(data)
                .then(body => {
                    setModalForm(false);
                    setFilters({ _updatedAt: Date.now() });
                })
        }

        if (modalForm.type == 'update') {
            app.service.userUpdate(data)
                .then(body => {
                    setModalForm(false);
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: {
                    ...record,
                    orgs: record.orgs.map(item => item.authOrgId),
                    roles: record.roles.map(item => item.authRoleId)
                }
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.userDelete)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    return (
        <Page title="用户管理">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="名称"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                {Table.create({
                    filters,
                    service: app.service.userList,
                    columns: [
                        { 
                            title: '名称',
                            dataIndex: 'authUserUsername'
                        },
                        { 
                            title: '昵称',
                            dataIndex: 'authUserNick'
                        },
                        { 
                            title: '标识',
                            dataIndex: 'authUserCode'
                        },
                        { 
                            title: '邮箱',
                            dataIndex: 'authUserMail'
                        },
                        { 
                            title: '手机',
                            dataIndex: 'authUserMobile'
                        },
                        { 
                            title: '操作',
                            render: function(value, record) {
                                return (
                                    <Space>
                                        <a onClick={onUpdate(record)}>编辑</a>
                                        <a onClick={onRemove(record)}>删除</a>
                                    </Space>
                                )
                            }
                        },
                    ]
                })}
            </Results>
            {modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}


export default function (props) {
    return (
        <RouterSwitch>
            <Route exact path="/auth/user" children={(
                <Constant.Provider value={[]}>
                     <Index />
                </Constant.Provider>
            )} />
        </RouterSwitch>
    )
}
