import React, { useContext } from 'react';
import { Input, Button, Space, Modal } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { Route, Switch } from "react-router-dom";
import { Page, Filters, Results, Table, Constant, confirm } from 'ui';
import { useTableFilters, useTableResults, useModalForm } from 'hooks';
import ModalForm from './ModalForm';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.attackEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {
                filters: [ {} ]
            }
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.attackDelete)(record)
                .then(()=> {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function filtersRender(value) {
        const filterType = {};
        if(constants.attack_filter_type == null){
            return;
        }
        constants.attack_filter_type.forEach(item => {
            filterType[item.value] = item.name;
        })

        return (
            <Space direction="vertical">
                {value.map(item => (
                    <div>{filterType[item.fieldName] || item.fieldName} {item.expression} {filterType[item.fieldValue] || item.fieldValue}</div>
                ))}
            </Space>
        )
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="攻击类型">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="名称"
                    name="primaryName"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="攻击类型列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table filters={filters} service={app.service.attackPage}>
                    <Table.Column title="名称" dataIndex="primaryName" />
                    <Table.Column title="描述" dataIndex="description" />
                    <Table.Column title="过滤条件" dataIndex="filters" render={filtersRender} />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/attack_type">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}