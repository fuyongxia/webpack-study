import { Form, Input, Modal } from 'antd';
import React, { useRef } from 'react';
import { Grid, ScrollView } from 'ui';
import Condition from './Condition';

export default function (props) {
    const formRef = useRef(null);
    return (
        <Modal {...props} width={800} visible onOk={() => formRef.current.submit()} >
            <ScrollView maxHeight="500px">
                <Form ref={formRef} {...props} >
                    <Grid labelWidth="120px" gutter={16}>
                        <Grid.Row>
                            <Grid.Col span={20} offset={2}>
                                <Form.Item
                                    label="攻击类型名称"
                                    name="primaryName"
                                    rules={[{ required: true }]}
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    label="攻击类型描述"
                                    name="description"
                                >
                                    <Input.TextArea />
                                </Form.Item>
                                <Form.Item
                                    label="过滤条件"
                                    name="filters"
                                >
                                    <Condition />
                                </Form.Item>
                            </Grid.Col>
                        </Grid.Row>
                    </Grid>
                </Form>
            </ScrollView>
        </Modal>
    )
}