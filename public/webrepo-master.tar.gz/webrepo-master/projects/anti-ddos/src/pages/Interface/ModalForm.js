import React, { useContext } from 'react';
import { Modal, Form, Input, InputNumber } from 'antd';
import { useStyles } from 'hooks';
import { Grid, Select, Switch, Constant,renderer } from 'ui';
import _ from 'lodash';

export default function (props) {
    const constants = useContext(Constant.Context);

    const styles = useStyles({
        section: { 
            padding: '30px 10px 10px 10px',
            background: 'aliceblue',
            pointerEvents: 'none'
        }
    })

    return (
        <Modal {...props} width={800} visible >
            <Form {...props} >
                <Grid labelWidth="120px" gutter={32} className={styles.section}>
                <Grid.Row>
                        <Form.Item
                            label="网络设备名称"
                        >
                            <Input value={_.get(props.data, ['baseRouter', 'name'])} />
                        </Form.Item>
                        <Form.Item
                            label="设备描述"
                        >
                            <Input value={_.get(props.data, ['baseRouter', 'description'])} />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                            label="接口名称"
                            name="name"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="接口描述"
                            name="description"
                        >
                            <Input />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                            label="接口IP地址"
                            name="ifipaddr"                        
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="接口带宽"
                        >
                            <Input value={renderer.flowRender(' ', 0)(_.get(props.data,'speed'))} />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                            label="接口索引"
                            name="snmpindex"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="Flow索引"
                            name="flowindex"
                        >
                            <Input />
                        </Form.Item>
                    </Grid.Row>
                </Grid>
                <Grid labelWidth="120px" gutter={32} style={{paddingTop: 20, borderTop: '1px solid #ddd '}}>
                    <Grid.Row>
                        <Form.Item
                            label="邻居AS号"
                            name="peerasns"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="接口分类"
                            name="classification"
                        >
                            <Select data={constants.classification} />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item
                            label="接口类型"
                            name="ifboundarytype"
                        >
                            <Select data={constants.interface_type} />
                        </Form.Item>
                        <Form.Item
                            label="采集接口链路流量"
                            name="trafficCollect"
                        >
                            <Switch />
                        </Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Grid.Col span={24}>
                            <Form.Item
                                label="接口流量阈值"
                            >
                                <div>
                                    <span>上限流量</span>
                                    <Form.Item noStyle name="highSwitch"> 
                                        <Switch style={{margin: "0 10px"}} /> 
                                    </Form.Item> 
                                    <Form.Item noStyle name="speedthresholdHigh"> 
                                        <InputNumber size="small" /> 
                                    </Form.Item> 
                                    %
                                </div>
                                <div style={{marginTop: 5}}>
                                    <span>下限流量</span>
                                    <Form.Item noStyle name="lowSwitch"> 
                                        <Switch style={{margin: "0 10px"}} /> 
                                    </Form.Item> 
                                    <Form.Item noStyle name="speedthresholdLow"> 
                                        <InputNumber size="small" /> 
                                    </Form.Item> 
                                    %
                                </div>
                            </Form.Item>
                        </Grid.Col>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}