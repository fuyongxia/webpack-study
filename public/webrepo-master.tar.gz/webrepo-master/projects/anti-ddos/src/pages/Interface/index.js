import { Input, Space } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { Route, Switch } from "react-router-dom";
import { confirm, Constant, Filters, Page, renderer, Results, Select, Table } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.interfaceEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }


    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'add',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.interfaceDelete)(record)
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }
    
    function onView(record) {
        return () => {
            app.service.interfaceView({interfaceid: record.interfaceid})
                .then(body => {
                    setModalForm({
                        type: 'view',
                        title: '查看',
                        data: body
                    })
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onView(record)}>查看</a>
                <a onClick={onUpdate(record)}>编辑</a>
            </Space>
        )
    }
    
    return (
        <Page title="设备接口">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="网络设备"
                    name="routerid"
                >
                    <Select service={app.service.routerPage} params={{ pageSize: 999 }} labelField="name" valueField="uuid" />
                </Filters.Item>
                <Filters.Item
                    label="接口名称"
                    name="name"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="接口描述"
                    name="description"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="接口IP地址"
                    name="ifipaddr"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="接口类型"
                    name="ifboundarytype"
                >
                    <Select allowClear data={constants.interface_type} />
                </Filters.Item>
                <Filters.Item
                    label="链路流量采集"
                    name="trafficCollect"
                >
                    <Select allowClear data={constants.traffic_collect} />
                </Filters.Item>
                <Filters.Item
                    label="接口状态"
                    name="ifOperStatus"
                >
                    <Select allowClear data={constants.if_oper_status} />
                </Filters.Item>
            </Filters>
            <Results
                title="网络设备接口列表"
            >
                <Table service={app.service.interfacePage} filters={filters}>
                    <Table.Column title="网络设备名称" dataIndex={["baseRouter", "name"]} />
                    <Table.Column title="接口名称" dataIndex="name" />
                    <Table.Column title="接口描述" dataIndex="description" />
                    <Table.Column title="接口IP地址" dataIndex="ifipaddr"  render={renderer.ipRender()} />
                    <Table.Column title="接口带宽bps" dataIndex="speed" render={renderer.flowRender(' ', 0)}  />
                    <Table.Column title="接口类型" dataIndex="ifboundarytype" render={renderer.enumRender({ data: constants.interface_type })} />
                    <Table.Column title="状态" dataIndex="ifOperStatus" />
                    <Table.Column title="链路流量采集" dataIndex="trafficCollect" render={renderer.enumRender({ data: constants.traffic_collect })}/>
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function (props) {
    const constants = {
        if_oper_status: [
            { name: 'UP', value: 'UP'},
            { name: 'DOWN', value: 'DOWN'},
        ],
        traffic_collect: [
            { name: '开启', value: 'ON'},
            { name: '关闭', value: 'OFF'},
        ],
        classification: [
            { name: '自动', value: 'AUTO'},
            { name: '手动', value: 'MANUAL'},
        ]
    }

    return (
        <Switch>
            <Route exact path="/interface" children={(
                <Constant.Provider value={constants}>
                     <Index />
                </Constant.Provider>
            )} />
        </Switch>
    )
}