import React, { useContext, useEffect } from 'react';
import { Route, Switch } from "react-router-dom";
import { Input, Button, Select } from 'antd';
import { DeleteOutlined } from '@ant-design/icons';
import { Page, Filters, Results, DatePicker, Constant, Table, confirm, renderer} from 'ui';
import { useTableFilters, useTableResults, useModalForm } from 'hooks';

function Index(props) {
    const { result_type } = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { table, setTable, tableProps } = useTableResults(app.service.systemLogPage, [ filters._updatedAt ], { 
        filters,
        rowSelection: {
            selectedRowKeys: [],
            onChange: (keys) => {
                setTable({
                    rowSelection: {
                        ...table.rowSelection,
                        selectedRowKeys: keys
                    }
                })
            }
        }
     })

     useEffect(() => {
        setTable({
            rowSelection: {
                ...table.rowSelection,
                selectedRowKeys: []
            }
        })
     }, [ JSON.stringify(filters), JSON.stringify(table.pagination)])



    function onEmpty() {
        confirm(app.service.systemLogEmpty)()
            .then(body => {
                setFilters({ _updatedAt: Date.now() });
            })
    }

    function onRemove() {
        confirm(app.service.systemLogDelete)({ ids: table.rowSelection.selectedRowKeys })
        .then(body => {
            setFilters({ _updatedAt: Date.now() });
        })
    }

    return (
        <Page title="用户操作日志">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="用户名"
                    name="requestName"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="客户端IP"
                    name="requestIp"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="操作方式"
                    name="requestMethod"
                >
                    <Select allowClear>
                        <Select.Option value="GET">GET</Select.Option>
                        <Select.Option value="POST">POST</Select.Option>
                    </Select>
                </Filters.Item>
                <Filters.Item
                    label="操作结果"
                    name="responseStatus"
                > 
                     <Select allowClear>
                        <Select.Option value="SUCCESS">成功</Select.Option>
                        <Select.Option value="FAILURE">失败</Select.Option>
                    </Select>
                </Filters.Item>
                <Filters.Item
                    label="返回码"
                    name="responseCode"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item style={{width: '130%'}}
                    label="操作时间"
                >
                    <Filters.Item noStyle name="startTime">
                        <DatePicker showTime style={{width: '48%'}} />
                    </Filters.Item>
                    ~
                    <Filters.Item noStyle name="endTime">
                        <DatePicker showTime  style={{width: '48%'}} />
                    </Filters.Item>
                </Filters.Item>
            </Filters>
            <Results
                title="用户操作日志列表"
                extra={[
                    <Button type="primary" onClick={onEmpty}>清空</Button>,
                    <Button disabled={!table.rowSelection.selectedRowKeys} icon={<DeleteOutlined />} type="primary" onClick={onRemove}>批量删除</Button>
                ]}
            >
                <Table rowKey="id" {...tableProps} >
                    <Table.Column title="用户名" dataIndex="requestName"  />
                    <Table.Column title="客户端IP" dataIndex="requestIp"  />
                    <Table.Column title="操作页面" dataIndex="requestUrl"  />
                    <Table.Column title="操作方式" dataIndex="requestMethod"  />
                    <Table.Column title="操作结果" dataIndex="responseStatus" render={renderer.enumRender({ data: result_type })} />
                    <Table.Column title="返回码" dataIndex="responseCode"  />
                    <Table.Column title="操作时间" dataIndex="requestTime" render={renderer.dateRender()} />
                </Table>
            </Results>
        </Page>
    )
}


export default function (props) {
    return (
        <Switch>
            <Route exact path="/system_log">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}