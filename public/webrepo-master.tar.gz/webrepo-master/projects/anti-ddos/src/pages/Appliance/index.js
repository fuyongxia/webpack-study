import React, { useContext } from 'react';
import { Input, Button, Space } from 'antd';
import { Switch, Route } from "react-router-dom";
import { PlusOutlined } from '@ant-design/icons';
import { Page, Filters, Results, confirm, Select, Table, renderer, Constant, Ping } from 'ui';
import { useTableFilters, useModalForm } from 'hooks';
import ModalForm from './ModalForm';

function Index(props) {
    const { appliance_type = [] } = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.applianceEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onView(record) {
        return () => {
            app.service.applianceView({ uuid: record.uuid})
                .then(body => {
                    setModalForm({
                        type: 'view',
                        title: '查看',
                        data: body
                    })
                })
        }
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            loading: false,
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            app.service.applianceView({ uuid: record.uuid})
                .then(body => {
                    setModalForm({
                        type: 'update',
                        title: '修改',
                        loading: false,
                        data: body
                    })
                })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.applianceDelete)({ uuid: record.uuid })
                .then(body => {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <Ping ip={record.ip} />
                <a onClick={onView(record)}>查看</a>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="监测设备">
            <Filters {...filtersProps} key="filters">
                <Filters.Item
                    label="设备名称"
                    name="name"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="设备IP地址"
                    name="ip"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="设备类型"
                    name="applianceType"
                >
                    <Select data={appliance_type} allowClear />
                </Filters.Item>
            </Filters>
            <Results
                title="监测设备列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table service={app.service.appliancePage} filters={filters}>
                    <Table.Column title="设备名称" dataIndex="name" />
                    <Table.Column title="设备IP地址"  dataIndex="ip"/>
                    <Table.Column title="设备类型"  dataIndex="applianceType" render={renderer.enumRender({ data: appliance_type })} />
                    <Table.Column title="关联Flow源"  dataIndex="routers" render={routers => (routers || []).map(item=>item.name).join(',') }/>
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}


export default function (props) {
    return (
        <Switch>
            <Route exact path="/appliance">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}