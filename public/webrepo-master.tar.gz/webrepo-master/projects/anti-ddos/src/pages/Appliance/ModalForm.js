import React, { useContext } from 'react';
import { Modal, Form, Input } from 'antd';
import { Grid, Checkbox, Select, ProvinceSelect, CitySelect, Constant } from 'ui';
import { useStyles } from 'hooks';

export default function (props) {
    const { appliance_type = [] } = useContext(Constant.Context);
    const styles = useStyles({
        flow: {
            "& .ant-checkbox-wrapper": {
                marginLeft: 8
            }
        }
    })

    function onValuesChange(data) {
        if ('province' in data) {
            data.city = '';
        }
        props.onValuesChange(data);
    }

    return (
        <Modal width={800} visible {...props} >
            <Form {...props} onValuesChange={onValuesChange} >
                <Grid labelWidth="120px" gutter={16}>
                    <Grid.Row>
                        <Grid.Col offset={3} span={18}>
                            <Form.Item
                                label="设备名称"
                                name="name"
                                rules={[{ required: true }]}
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="设备描述"
                                name="description"
                            >
                                <Input.TextArea />
                            </Form.Item>
                            <Form.Item
                                required
                                label="设备IP地址"
                                name="ip"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                required
                                label="设备类型"
                                name="applianceType"
                            >
                                <Select data={appliance_type} />
                            </Form.Item>
                            <Form.Item
                                label="Flow采集接口"
                            >
                                <Grid.Row gutter={16} className={styles.flow}>
                                    <Grid.Col span={6}>
                                        {['bond0', 'eth0', 'eth4'].map(item => (
                                            <Form.Item noStyle name={item}>
                                                <Checkbox>{item}</Checkbox>
                                            </Form.Item>
                                        ))}
                                    </Grid.Col>
                                    <Grid.Col span={6}>
                                        {['bond1', 'eth1', 'eth5'].map(item => (
                                            <Form.Item noStyle name={item}>
                                                <Checkbox>{item}</Checkbox>
                                            </Form.Item>
                                        ))}
                                    </Grid.Col>
                                    <Grid.Col span={6}>
                                        {['bond2', 'eth2', 'eth6'].map(item => (
                                            <Form.Item noStyle name={item}>
                                                <Checkbox>{item}</Checkbox>
                                            </Form.Item>
                                        ))}
                                    </Grid.Col>
                                    <Grid.Col span={6}>
                                        {['bond3', 'eth3', 'eth7'].map(item => (
                                            <Form.Item noStyle name={item}>
                                                <Checkbox>{item}</Checkbox>
                                            </Form.Item>
                                        ))}
                                    </Grid.Col>
                                </Grid.Row>
                            </Form.Item>
                            <Form.Item
                                label="部署省份"
                                name="province"
                            >
                                <ProvinceSelect />
                            </Form.Item>
                            <Form.Item
                                label="部署城市"
                                name="city"
                            >
                                <CitySelect province={props.data.province} />
                            </Form.Item>
                            <Form.Item
                                label="部署网络"
                                name="networkDeploy"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                label="部署位置"
                                name="location"
                            >
                                <Input />
                            </Form.Item>
                            {props.type !== 'add' && (
                                <>
                                    <Form.Item
                                        label="设备序列号"
                                        name="licenseKey"
                                    >
                                        <Input disabled  />
                                    </Form.Item>
                                    <Form.Item
                                        label="关联检测Flow源"
                                    >
                                        <Input disabled value={(props.data.routers || []).map(item => item.name).join("name")} />
                                    </Form.Item>
                                </>
                            )}
                        </Grid.Col>
                    </Grid.Row>
                </Grid>
            </Form>
        </Modal>
    )
}