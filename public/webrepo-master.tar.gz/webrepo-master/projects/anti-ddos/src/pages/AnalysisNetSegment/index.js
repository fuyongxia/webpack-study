import { Input, InputNumber } from 'antd';
import { useTableFilters } from 'hooks';
import React, { useContext, useEffect } from 'react';
import { Route, Switch } from "react-router-dom";
import { Constant, Select, Table, Filters, Page, RangePicker, Results, renderer, util } from 'ui';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});

    useEffect(() => {
        if (Object.keys(constants).length > 0) {
            setFilters({
                period: constants.net_segment_time_period[0].value,
                _updatedAt: Date.now()
            })
        }
    }, [ Object.keys(constants).length ]);

    return (
        <Page title="攻击网段分析">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="时间范围"
                    name="period"
                >
                   <Select data={constants.net_segment_time_period} />
                </Filters.Item>
                {filters.period !== 'DEFINED' && (
                     <Filters.Item
                        span={18}
                     >
                         
                    </Filters.Item>
                )}
                {filters.period == 'DEFINED' && (
                    <Filters.Item
                        span={18}
                        colon=""
                        name="definedTime"
                    >
                        <RangePicker />
                        <span> （请选择7天时间段） </span>
                    </Filters.Item>
                )}
                <Filters.Item
                    label="被攻击网段"
                >
                    <Filters.Item noStyle name="ip">
                        <Input placeholder="/24 (IPV4) OR /120(IPV6)" />
                    </Filters.Item>
                </Filters.Item>
                <Filters.Item
                    label="网段被攻击IP数大于"
                >
                    <Filters.Item  name="num">
                        <InputNumber min={0} style={{width: '100%'}} />
                    </Filters.Item>
                </Filters.Item>
            </Filters>
            <Results
                title="攻击分析列表"
            >
                {Table.create({
                    filters: {
                        ...filters,
                        definedTime: filters.definedTime ? filters.definedTime.map(item => item.format('YYYY-MM-DD')).join(' - ') : null
                    },
                    service: (args) => {
                        return app.service.analysisNetSegment(args).then(body => {
                            const dsTree = util.denormalize((body || []), {
                                    id: 'node',
                                    pid: 'pnode',
                                    root: { node: "" },
                                }).children;
                            return dsTree;
                        })
                    },
                    rowKey : 'node',
                    columns: [
                        {
                            title: '被攻击C类网段',
                            render: (value, record) => {
                                return `${record.name} (IP数：${record.ipNum})`
                            }
                        },
                        {
                            title: '攻击次数',
                            dataIndex: 'attackNum'
                        },
                        {
                            title: '状态',
                            dataIndex: 'status',
                            render: renderer.enumRender({ data: constants.attack_status })
                        },
                        {
                            title: '首次攻击时间',
                            dataIndex: 'startTime',
                            render: renderer.dateRender()
                        },
                        {
                            title: '末次攻击时间',
                            dataIndex: 'endTime',
                            render: renderer.dateRender()
                        },
                        {
                            title: '持续时间',
                            dataIndex: 'duration',
                            render: renderer.durationRender()
                        },
                        {
                            title: '流量峰值bps',
                            dataIndex: 'bps',
                            render: renderer.flowRender()
                        },
                        {
                            title: '流量峰值pps',
                            dataIndex: 'pps',
                            render: renderer.flowRender()
                        },
                        {
                            title: '操作'
                        }
                    ]
                })}
            </Results>
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/analysis_net_segment">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}