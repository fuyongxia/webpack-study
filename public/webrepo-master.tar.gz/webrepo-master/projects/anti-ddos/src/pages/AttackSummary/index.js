import { Input } from 'antd';
import { useTableFilters } from 'hooks';
import React, { useContext, useEffect } from 'react';
import { Route, Switch } from "react-router-dom";
import { Filters, Page, Select, RangePicker, Results, Table, Constant } from 'ui';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});

    useEffect(() => {
        if (Object.keys(constants).length > 0) {
            setFilters({
                period: constants.time_period[0].value,
                _updatedAt: Date.now()
            })
        }
    }, [ Object.keys(constants).length ]);

    function getFilters() {
        return {
            ...filters,
            definedTime: filters.definedTime ? filters.definedTime.map(item => item.format('YYYY-MM-DD')).join(' - ') : null
        }
    }

    return (
        <Page title="异常统计">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="时间范围"
                    name="period"
                >
                    <Select data={constants.time_period} />
                </Filters.Item>
                {filters.period == 'DEFINED' && (
                    <Filters.Item
                        colon=""
                        name="definedTime"
                    >
                        <RangePicker />
                    </Filters.Item>
                )}
            </Filters>
            <Results
                title="攻击级别统计"
            >
                {Table.create({
                    filters: getFilters(),
                    service: app.service.attackSummaryLevel,
                    columns: [
                        {
                            title: '状态',
                            dataIndex: "status",
                            width: 300
                        },
                        {
                            title: '低',
                            dataIndex: "low",
                            width: 300
                        },
                        {
                            title: '中',
                            dataIndex: "medium",
                            width: 300
                        },
                        {
                            title: '高',
                            dataIndex: "high",
                            width: 300
                        },
                    ]
                })}
            </Results>
            <Results
                title="攻击类型统计"
            >
                {Table.create({
                    filters: getFilters(),
                    service: app.service.attackSummaryType,
                    columns: [
                        {
                            title: '序号',
                            dataIndex: "_index",
                            width: 300
                        },
                        {
                            title: '攻击类型',
                            dataIndex: "name",
                            width: 300
                        },
                        {
                            title: '攻击次数',
                            dataIndex: "num",
                            width: 300
                        },
                        {
                            title: '占比',
                            dataIndex: "rate",
                            width: 300
                        },
                    ]
                })}
            </Results>
            <Results
                title="攻击对象统计"
            >
                {Table.create({
                    filters: getFilters(),
                    service: app.service.attackSummaryObject,
                    columns: [
                        {
                            title: '序号',
                            dataIndex: "_index",
                            width: 300
                        },
                        {
                            title: '监测对象',
                            dataIndex: "name",
                            width: 300
                        },
                        {
                            title: '攻击次数',
                            dataIndex: "num",
                            width: 300
                        },
                        {
                            title: '占比',
                            dataIndex: "rate",
                            width: 300
                        },
                    ]
                })}
            </Results>
            <Results
                title="攻击峰值统计"
            >
                {Table.create({
                    filters: getFilters(),
                    service: app.service.attackSummaryBps,
                    columns: [
                        {
                            title: '序号',
                            dataIndex: "_index",
                            width: 300
                        },
                        {
                            title: '流速峰值',
                            dataIndex: "name",
                            width: 300
                        },
                        {
                            title: '攻击次数',
                            dataIndex: "num",
                            width: 300
                        },
                        {
                            title: '占比',
                            dataIndex: "rate",
                            width: 300
                        },
                    ]
                })}
            </Results>
            <Results
                title="攻击时长统计"
            >
                {Table.create({
                    filters: getFilters(),
                    service: app.service.attackSummaryDuration,
                    columns: [
                        {
                            title: '序号',
                            dataIndex: "_index",
                            width: 300
                        },
                        {
                            title: '时长（分钟）',
                            dataIndex: "name",
                            width: 300
                        },
                        {
                            title: '攻击次数',
                            dataIndex: "num",
                            width: 300
                        },
                        {
                            title: '占比',
                            dataIndex: "rate",
                            width: 300
                        },
                    ]
                })}
            </Results>
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/attack_summary">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}