import { Area, Line } from '@ant-design/charts';
import { Input, Space,Tag } from 'antd';
import { useTableFilters } from 'hooks';
import React, { useContext, useEffect } from 'react';
import { Route, Switch, Link } from "react-router-dom";
import { Constant, Filters, RangePicker, Page, renderer, Results, Select, Table } from 'ui';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});

    useEffect(() => {
        if (Object.keys(constants).length > 0) {
            setFilters({
                period: constants.time_period[0].value,
                _updatedAt: Date.now()
            })
        }
    }, [ Object.keys(constants).length ]);

    return (
        <Page title="DDoS攻击">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="监测对象"
                    name="detectObject"
                >
                    <Select allowClear params={{ pageSize: 999 }} service={app.service.customerPage} labelField="custname" valueField="custid" />
                </Filters.Item>
                <Filters.Item
                    label="攻击类型"
                    name="attackType"
                >
                    <Select allowClear params={{ pageSize: 999 }} service={app.service.attackPage} labelField="primaryName" valueField="secondName" />
                </Filters.Item>
                <Filters.Item
                    label="快速查询"
                    name="quickQuery"
                >
                    <Input placeholder="攻击ID或者攻击目标IP" />
                </Filters.Item>
                <Filters.Item
                    label="对象类型"
                    name="detectObjectType"
                >
                    <Select data={constants.detect_object_type} />
                </Filters.Item>
                <Filters.Item
                    label="告警级别"
                    name="level"
                >
                    <Select allowClear data={constants.attack_level} />
                </Filters.Item>
                <Filters.Item
                    label="持续时间"
                    name="duration"
                >
                    <Select allowClear data={constants.attack_duration} />
                </Filters.Item>
                <Filters.Item
                    label="攻击方向"
                    name="direction"
                >
                    <Select allowClear data={constants.attack_direction} />
                </Filters.Item>
                <Filters.Item
                    label="攻击状态"
                    name="status"
                >
                    <Select allowClear data={constants.attack_status} />
                </Filters.Item>
                <Filters.Item
                    label="攻击周期"
                    name="period"
                >
                    <Select allowClear data={constants.time_period} />
                </Filters.Item>
                {filters.period == 'DEFINED' && (
                    <Filters.Item
                        colon=""
                        name="definedTime"
                    >
                        <RangePicker />
                    </Filters.Item>
                )}
                <Filters.Item
                    label="流量峰值"
                    name="maxBps"
                >
                    <Select allowClear data={constants.attack_bps_max} />
                </Filters.Item>
            </Filters>
            <Results
                title="DDoS攻击列表"
            >
                {Table.create({
                    filters: {
                        ...filters,
                        definedTime: filters.definedTime ? filters.definedTime.map(item => item.format('YYYY-MM-DD')).join(' - ') : null
                    },
                    service: app.service.attackDdosPage,
                    columns: [
                        {
                            title: 'ID',
                            dataIndex: 'attackId'
                        },
                        {
                            title: '流量图',
                            dataIndex: 'bpsTreanlist',
                            render: data => {
                                const config = {
                                        color: 'red',
                                        height: 30,
                                        data: data || [],
                                        padding: 0,
                                        tooltip: false,
                                        xField: 'xStr',
                                        yField: 'yValue',
                                        areaStyle: function areaStyle() {
                                            return { fill: 'l(270) 0:#ffffff 0.5:#E9967A 1:#FF0000' };
                                        }
                                }
                                return (
                                    <div style={{ width: 100 }}>
                                        <Area {...config} />
                                    </div>
                                )
                            }
                        },
                        {
                            title: '监测对象',
                            dataIndex: ["cust", 'custname']
                        },
                        {
                            title: '攻击目标',
                            dataIndex: 'attackTarget'
                        },
                        {
                            title: '状态',
                            dataIndex: 'status',
                            render: renderer.enumRender({ data: constants.attack_status})
                        },
                        {
                            title: '攻击类型',
                            dataIndex: ['attackTypeObject', 'primaryName']
                        },
                        {
                            title: '级别',
                            dataIndex: 'level',
                            render: data => {
                                let color = data.length > 0 ? 'green' : '';
                                if (data === 'medium') {
                                    color = 'yellow';
                                }
                                if (data === 'high') {
                                    color = 'red';
                                }
                                if(data.length > 0 ){
                                    return (
                                        <Tag color={color} key={data}>
                                            {renderer.enumRender({ data: constants.attack_level})(data)}
                                        </Tag>
                                    )
                                } else {
                                    return data;
                                }
                                
                            }                         
                        },
                        {
                            title: '方向',
                            dataIndex: 'direction',
                            render: renderer.enumRender({ data: constants.attack_direction})
                        },
                        {
                            title: '起止时间',
                            render: (value, record) => {
                                return (
                                    <div>
                                        {renderer.dateRender()(record.startTime)}
                                        <br/>
                                        {renderer.dateRender()(record.endTime)}
                                    </div>
                                )
                            }
                        },
                        {
                            title: '持续时间',
                            dataIndex: 'duration',
                            render: renderer.durationRender()
                        },
                        {
                            title: '流量峰值',
                            render: (value, record) => {
                                return (
                                    <div>
                                        {renderer.flowRender()(record.maxBps)}bps
                                        <br/>
                                        {renderer.flowRender()(record.maxPps)}pps
                                    </div>
                                )
                            }
                        },
                        {
                            title: '操作',
                            render: (value, record) => {
                                return (
                                    <Space>
                                        <Link to={{ pathname: "attack_process", search: `attackId=${record.attackId}` }}>过程</Link>
                                        <Link to={{ pathname: "attack_count", search: `attackId=${record.attackId}` }}>统计</Link>
                                        {record.status == 'done' && (
                                            <Link to={{ pathname: "attack_analysis", search: `attackId=${record.attackId}` }}>分析</Link>
                                        )}
                                    </Space>
                                )
                            }
                        },
                    ]
                })}
            </Results>
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/attack_ddos">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}