import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React from 'react';
import { Route, Switch } from "react-router-dom";
import { confirm, Constant, Filters, Page, Results, Table } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.notificationGroupEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.notificationGroupDelete)(record)
                .then(() => {
                    setFilters({_updatedAt: Date.now()});
                })
        }
    }
    
    function onView(record) {
        return () => {
            app.service.notificationGroupView({ id: record.id})
                .then(body => {
                    setModalForm({
                        type: 'view',
                        title: '查看',
                        data: body
                    })
                })
        }
    }

    function actionRender(value, record) {
        return (
            <Space>
                <a onClick={onView(record)}>查看</a>
                <a onClick={onUpdate(record)}>编辑</a>
                <a onClick={onRemove(record)}>删除</a>
            </Space>
        )
    }

    return (
        <Page title="通知组">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="通知组名称"
                    name="name"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="邮箱地址"
                    name="emailAddress"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="syslog目的IP"
                    name="destinationIp"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="通知组列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                <Table service={app.service.notificationGroupPage} filters={filters}>
                    <Table.Column title="通知组名称" dataIndex="name" />
                    <Table.Column title="通知组描述" dataIndex="description" />
                    <Table.Column title="邮箱地址" dataIndex="emailAddress" />
                    <Table.Column title="syslog目的IP" dataIndex="destinationIp" />
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}


export default function (props) {
    return (
        <Switch>
            <Route exact path="/notification_group">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}