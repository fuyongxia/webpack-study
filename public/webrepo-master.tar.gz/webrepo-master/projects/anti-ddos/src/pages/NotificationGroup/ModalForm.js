import React, { useContext } from 'react';
import { Modal, Form, Row, Col, Input, Button, Space, Tabs, InputNumber } from 'antd';
import { Grid, Select, Constant } from 'ui';

export default function (props) {
    const constants = useContext(Constant.Context);
    return (
        <Modal {...props} width={800} visible >
            <Form {...props} >
                <Tabs defaultActiveKey="1">
                    <Tabs.TabPane key="1" tab="基本信息">
                        <Grid labelWidth="90px" gutter={16}>
                            <Grid.Row>
                                <Grid.Col offset={3} span={18}>
                                    <Form.Item
                                        label="通知组名称"
                                        name="name"
                                        rules={[{ required: true }]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        label="通知组描述"
                                        name="description"
                                    >
                                        <Input.TextArea />
                                    </Form.Item>
                                    <Form.Item
                                        label="通知组邮箱"
                                        name="emailAddress"
                                    >
                                        <Input.TextArea />
                                    </Form.Item>
                                </Grid.Col>
                            </Grid.Row>
                        </Grid>
                    </Tabs.TabPane>
                    <Tabs.TabPane key="2" tab="Syslog配置">
                    <Grid labelWidth="90px" gutter={16}>
                            <Grid.Row>
                                <Grid.Col offset={3} span={18}>
                                    <Form.Item
                                        label="目的IP地址"
                                        name="destinationIp"
                                        rules={[{ required: true }]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        label="目的端口"
                                        name="destinationPort"
                                        rules={[{ required: true }]}
                                    >
                                        <InputNumber />
                                    </Form.Item>
                                    <Form.Item
                                        label="设施"
                                        name="facility"
                                    >
                                        <Select data={constants.syslog_facility_type}/>
                                    </Form.Item>
                                    <Form.Item
                                        label="级别"
                                        name="severityLevel"
                                    >
                                        <Select data={constants.notification_event_level} />
                                    </Form.Item>
                                </Grid.Col>
                            </Grid.Row>
                        </Grid>
                    </Tabs.TabPane>
                </Tabs>
            </Form>
        </Modal>
    )
}