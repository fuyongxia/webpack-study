import React, { useState, useEffect, useContext } from 'react';
import { Table, Card, Radio } from 'antd';
import { Area } from '@ant-design/charts';
import { Route, Switch } from "react-router-dom";
import { Filters, Page, Select, RangePicker, Constant, renderer } from 'ui';
import { useTableFilters } from 'hooks';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, filtersProps } = useTableFilters({ type: "DEVICE" });
    const [chartData, setChartData] = useState([]);
    const [dataSource, setDataSource] = useState([]);

    useEffect(() => {
        app.service.monitorSystemFlowList({ type: filters.type })
            .then(body => {
                setDataSource(body || []);
            })
    }, [ filters.type, filters._updatedAt ]);

    useEffect(() => {
        const params = { 
            ...filters, 
            definedTime: (filters.definedTime || []).map(item => item.format('YYYY-MM-DD')).join(' - ') 
        };
        if (filters.type == "DEVICE") {
            const id = filters.applianceId;
            app.service.monitorSystemFlowApplianceItems({...params, id})
            .then(body => {
                setChartData(body || []);
            })
            .catch(error => {
                setChartData([]);
            })
        }

        if (filters.type == "ROUTER") {
            const id = filters.routerId;
            app.service.monitorSystemFlowFlowItems({...params, id})
            .then(body => {
                setChartData(body || []);
            })
            .catch(error => {
                setChartData([]);
            })
        }

    }, [filters._updatedAt])

    const config = {
        className: 'chart-enlarge',
        data: chartData,
        xField: 'xStr',
        yField: 'yValue',
        xAxis: { tickCount: 5 },
        yAxis: {
            label: {
              formatter: function formatter(v) {
                 return renderer.flowRender(' ', 0)(v)+' FPS';
              },
            },
        }, 
        slider: {
            start: 0.1,
            end: 0.9,
            trendCfg: { isArea: true },
        },
        tooltip: {
            trigger: 'yValue',
            formatter: function(v) {
                return { name: 'Flow速率', value: renderer.flowRender()(v.yValue) + ' FPS'};
            }
        }     
    }

    return (
        <Page title="Flow采集">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="设备类型"
                    name="type"
                >
                    <Select data={constants.device_from_type} />
                </Filters.Item>
                {filters.type == "DEVICE" && (
                    <Filters.Item
                        label="监测机名称"
                        name="applianceId"
                        key="appliance"
                    >
                        <Select allowClear params={{ pageSize: 99999, applianceType: 'COLLECTOR' }} service={app.service.appliancePage} labelField="name" valueField="uuid" />
                    </Filters.Item>
                )}
                {filters.type == "ROUTER" && (
                    <Filters.Item
                        label="Flow源名称"
                        name="routerId"
                        key="router"
                    >
                        <Select allowClear params={{ pageSize: 99999 }} service={app.service.routerPage} labelField="name" valueField="routerid" />
                    </Filters.Item>
                )}
                <Filters.Item
                    label="时间范围"
                    name="period"
                >
                    <Select allowClear>
                        <Select.Option value="TODAY">今日</Select.Option>
                        <Select.Option value="YESTERDAY">昨日</Select.Option>
                        <Select.Option value="WEEK">本周</Select.Option>
                        <Select.Option value="MONTH">本月</Select.Option>
                        <Select.Option value="YEAR">本年</Select.Option>
                        <Select.Option value="DEFINED">自定义</Select.Option>
                    </Select>
                </Filters.Item>
                {filters.period == 'DEFINED' && (
                    <Filters.Item
                        label="自定义时间段"
                        name="definedTime"
                    >
                        <RangePicker style={{width: '100%'}} />
                    </Filters.Item>
                )}
            </Filters>
            <Card style={{ margin: "16px 0" }}>
                <Area {...config} />
            </Card>
            <Card>
                <Table rowKey="uuid" dataSource={dataSource} >
                    <Table.Column title="设备名称" dataIndex="name" />
                    <Table.Column title="设备类型" dataIndex="type" render={renderer.enumRender({ data: constants.appliance_type })} />
                    <Table.Column title="Flow版本" dataIndex="flowVersion" />
                    <Table.Column title="Flow速率(FPS)" dataIndex="fps" render={renderer.flowRender()} />
                    <Table.Column title="采集时间" dataIndex="dataTime" render={renderer.dateRender()} />
                </Table>
            </Card>
        </Page>
    )
}

export default function (props) {
    const constants = {
        
    }

    return (
        <Switch>
            <Route exact path="/system_flow">
                <Constant.Provider value={constants}>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}