import React, { useState, useEffect } from 'react';
import { Space, Button } from 'antd';
import { Table, Select, confirm } from 'ui';

export default function (props) {
    const [ value, setValue ] = useState('');
    const [ filters, setFilters ] = useState({});

    useEffect(() => {
        setFilters({
            ...props.filters,
            _updatedAt: Date.now()
        })

    }, [ JSON.stringify(props.filters)]);

    function onAdd() {
        if (filters.authRoleId) {
            app.service.roleUserSave({ ...filters, authUserId: value })
                .then(body => {
                    setValue('');
                    setFilters({ ...filters, _updatedAt: Date.now() });
                })
        }
        if (filters.authOrgId) {
            app.service.orgUserSave({ ...filters, authUserId: value })
                .then(body => {
                    setValue('');
                    setFilters({ ...filters, _updatedAt: Date.now() });
                })
        }
    }

    function onRemove(item) {
        return () => {
            if (filters.authRoleId) { 
                confirm(app.service.roleUserDelete)({ ...props.filters, authUserId: item.authUserId })
                    .then(body => {
                        setFilters({ ...filters, _updatedAt: Date.now() });
                    })
            }
            if (filters.authOrgId) {
                confirm(app.service.orgUserDelete)({ ...props.filters, authUserId: item.authUserId })
                    .then(body => {
                        setFilters({ ...filters, _updatedAt: Date.now() });
                    })
            }
        }
    }

    return (
        <div>
            <div style={{marginBottom: 15 }}>
                <Select value={value} onChange={setValue} allowClear style={{width: 320, marignRight: 10}} service={app.service.userList} params={{pageSize: 999 }} labelField="authUserUsername" valueField="authUserId" /> 
                <Button onClick={onAdd} type="primary">添加</Button>
            </div>
            {Table.create({
                filters: filters,
                service: (args) => {
                    if (args.authRoleId == null && args.authOrgId == null) {
                        return Promise.resolve([]);
                    }
                    return app.service.userList(args);
                },
                columns: [
                    {
                        title: '名称',
                        dataIndex: 'authUserUsername'
                    },
                    {
                        title: '昵称',
                        dataIndex: 'authUserNick'
                    },
                    {
                        title: '标识',
                        dataIndex: 'authUserCode'
                    },
                    {
                        title: '邮箱',
                        dataIndex: 'authUserMail'
                    },
                    {
                        title: '手机',
                        dataIndex: 'authUserMobile'
                    },
                    {
                        title: '操作',
                        render: function (value, record) {
                            return (
                                <Space>
                                    <a onClick={onRemove(record)}>取消关联</a>
                                </Space>
                            )
                        }
                    },
                ]
            })}
        </div>
    )
}