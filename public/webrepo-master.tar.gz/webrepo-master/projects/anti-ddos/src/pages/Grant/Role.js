import { Form, Input, InputNumber, Modal, Card, Tabs, Menu } from 'antd';
import React, { useContext, useState, useEffect } from 'react';
import { Constant, Grid, Select } from 'ui';
import ResTable from './ResTable';
import UserTable from './UserTable';

export default function (props) {
    const constants = useContext(Constant.Context);
    const [ curRole, setCurRole ] = useState();
    const [ roles, setRoles ] = useState([]);

    useEffect(() => {
        app.service.roleList({ pageSize: 0 })
            .then(body => {
                const results = body.results || [];
                setRoles(results);
                if (results.length) {
                    onSelect(results[0])();
                }
            })
    }, [])

    function onSelect(item) {
        return () => {
            setCurRole(item);
        }
    }

    return (
        <Grid>
            <Grid.Row gutter={32}>
                <Grid.Col span={4}>
                    <Menu selectedKeys={curRole ? [ curRole.authRoleId ] : []}>
                        {roles.map(item => (
                            <Menu.Item key={item.authRoleId} onClick={onSelect(item)}>{item.authRoleName}</Menu.Item>
                        ))}
                    </Menu>
                </Grid.Col>
                <Grid.Col span={18}>
                    <Tabs>
                        <Tabs.TabPane tab="授权到权限" key="1">
                            <ResTable authGrantOwnerType={3} authGrantOwnerValue={curRole && curRole.authRoleId} />
                        </Tabs.TabPane>
                        <Tabs.TabPane tab="授权到用户" key="2">
                            <UserTable filters={{ authRoleId: curRole && curRole.authRoleId }} />
                        </Tabs.TabPane>
                    </Tabs>
                </Grid.Col>
            </Grid.Row>
        </Grid>
    )
}