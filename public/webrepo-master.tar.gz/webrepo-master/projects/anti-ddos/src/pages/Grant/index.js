import { Card, Tabs } from 'antd';
import React from 'react';
import { useService } from 'hooks';
import { Constant, Page } from 'ui';
import { Switch as RouterSwitch, Route } from "react-router-dom";
import Org from './Org';
import Role from './Role';

function Index(props) {
    return (
        <Page title="授权管理">
            <Card>
                <Tabs>
                    <Tabs.TabPane tab="按角色授权" key="role">
                        <Role />
                    </Tabs.TabPane>
                    <Tabs.TabPane tab="按组织机构授权" key="org">
                        <Org />
                    </Tabs.TabPane>
                </Tabs>
            </Card>
        </Page>
    )
}

export default function (props) {
    const constants = useService(app.service.authAttrs, {});

    return (
        <RouterSwitch>
            <Route exact path="/auth/grant" children={(
                <Constant.Provider value={constants}>
                     <Index />
                </Constant.Provider>
            )} />
        </RouterSwitch>
    )
}