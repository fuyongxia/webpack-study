import React from 'react';
import { Input, Button, Table, Space, Row, Col } from 'antd';
import { Page, Filters, Results, DatePicker, Select, Select, confirm } from 'ui';
import { useTableFilters, useTableResults } from 'hooks';

export default function (props) {
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { tableProps } = useTableResults(app.service.netflowTracePage, [ filters._updatedAt ], { filters })

    function actionRender(value, record) {
        return (
            <Space>
                <a>原始数据</a>
                <a>波动图</a>
            </Space>
        )
    }

    return (
        <Page title="实时流量分析">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="时间范围"
                    name="rangeType"
                >
                    <Select>
                        <Select.Option value="TODAY">今日</Select.Option>
                        <Select.Option value="YESTERDAY">昨日</Select.Option>
                        <Select.Option value="WEEK">本周</Select.Option>
                        <Select.Option value="MONTH">本月</Select.Option>
                        <Select.Option value="YEAR">本年</Select.Option>
                        <Select.Option value="DEFINED">自定义</Select.Option>
                    </Select>
                </Filters.Item>
                {filters.rangeType == 'DEFINED' && (
                    <Filters.Item
                        label="开始时间"
                        name="startTime"
                    >
                    <DatePicker />
                </Filters.Item>
                )}
                {filters.rangeType == 'DEFINED' && (
                    <Filters.Item
                    label="结束时间"
                    name="endTime"
                    >
                        <DatePicker />
                    </Filters.Item>
                )}
                <Filters.Item
                    label="方案名称"
                    name="planId"
                >
                    <Select params={{pageSize: 999}} service={app.service.tracePlanPage} labelField="name" valueField="id" />
                </Filters.Item>
                <Filters.Item
                    label="统计维度"
                    name="columnName"
                >
                    <Select type="flow_field" />
                </Filters.Item>
                <Filters.Item
                    label="TopN"
                    name="top"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="统计单位"
                    name="unitBy"
                >
                    <Select>
                        <Select.Option value="bps">bps</Select.Option>
                        <Select.Option value="pps">pps</Select.Option>
                        <Select.Option value="bytes">bytes</Select.Option>
                        <Select.Option value="packets">packets</Select.Option>
                    </Select>
                </Filters.Item>
            </Filters>
            <Results 
                title="流量曲线图"
            >
            </Results>
            <Results
                title="列表"
            >
                <Table {...tableProps}>
                    <Table.Column title="操作" render={actionRender} />
                </Table>
            </Results>
        </Page>
    )
}