import { PlusOutlined } from '@ant-design/icons';
import { Button, Input, Space } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { Route, Switch, Link } from "react-router-dom";
import { confirm, Constant, Filters, Page, renderer, Results, Select, Table } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.tracePlanEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {
                direction: 'ALL',
                conditions: [],
                patterns: []
            }
        })
    }

    function onView(record) {
        return () => {
            setModalForm({
                type: 'view',
                title: '查看',
                data: record
            })
        }
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.tracePlanDelete)(record)
                .then(()=> {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    return (
        <Page title="回溯分析方案">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="方案名称"
                    name="name"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="方案状态"
                    name="state"
                >
                    <Select allowClear data={constants.state} />
                </Filters.Item>
            </Filters>
            <Results
                title="列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                {Table.create({
                    filters,
                    service: app.service.tracePlanPage,
                    columns: [
                        {
                            title: '方案名称',
                            dataIndex: 'name'
                        },
                        {
                            title: '方案状态',
                            dataIndex: 'state',
                            render: renderer.enumRender({ data: constants.state })
                        },
                        {
                            title: '网络边界',
                            dataIndex: ['interfaceGroup', 'name']
                        },
                        {
                            title: '流量方向',
                            dataIndex: 'direction',
                            render: renderer.enumRender({ data: constants.direction })
                        },
                        {
                            title: '创建时间',
                            dataIndex: 'createTime',
                            render: renderer.dateRender()
                        },
                        {
                            title: '修改时间',
                            dataIndex: 'updateTime',
                            render: renderer.dateRender()
                        },
                        {
                            title: '操作',
                            render: (value, record) => {
                                return (
                                    <Space>
                                        <Link to={{ pathname: "/analysis_netflow_trace", search: `?planId=${record.id}`}} >报表</Link>
                                        <a onClick={onView(record)}>查看</a>
                                        <a onClick={onUpdate(record)}>修改</a>
                                        <a onClick={onRemove(record)}>删除</a>
                                    </Space>
                                )
                            }
                        },

                    ]

                })}
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}

export default function (props) {
    const constants = {
        state: [
            { name: '启用', value: 'ENABLE' },
            { name: '停用', value: 'DISABLE' },
        ],
        direction: [
            { name: '双向', value: 'ALL' },
            { name: '入向', value: 'IN' },
            { name: '出向', value: 'OUT' }
        ]
    }

    return (
        <Switch>
            <Route exact path="/analysis_trace_plan">
                <Constant.Provider value={constants}>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}