import React, { useContext } from 'react';
import { Form, Input } from 'antd';
import { Grid, Select, Constant } from 'ui';

export default function (props) {
    const constants = useContext(Constant.Context);
    return (
        <Grid labelWidth="120px">
            <Grid.Row>
                <Grid.Col span={16} offset={4}>
                    <Form.Item
                        label="分析方案名称"
                        name="name"
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        label="分析方案描述"
                        name="description"
                    >
                        <Input.TextArea />
                    </Form.Item>
                    <Form.Item
                        label="方案状态"
                        name="state"
                    >
                        <Select data={constants.state} />
                    </Form.Item>
                </Grid.Col>
            </Grid.Row>
        </Grid>
    )
}