import React, { useContext, useRef } from 'react';
import { Modal, Form, Tabs } from 'antd';
import { ScrollView, Grid, Select, Constant } from 'ui';
import BaseInfo from './BaseInfo';
import Condition from './Condition';
import Pattern from './Pattern';

export default function (props) {
    const constants = useContext(Constant.Context);
    return (
        <Modal {...props} width={800} visible >
            <ScrollView minHeight="500px" maxHeight="500px">
                <Form {...props} >
                    <Tabs defaultActiveKey="1">
                        <Tabs.TabPane tab="基本信息" key="1">
                            <BaseInfo />
                        </Tabs.TabPane>
                        <Tabs.TabPane tab="过滤条件" key="2">
                            <Grid gutter={32} labelWidth="100px">
                                <Grid.Row>
                                    <Form.Item
                                        label="网络边界"
                                        name="networkBoundary"
                                    >
                                        <Select allowClear params={{ pageSize: 999 }} service={app.service.groupPage} labelField="name" valueField="uuid" placeholder="不选择默认为全网边界" />
                                    </Form.Item>
                                    <Form.Item
                                        label="流量方向"
                                        name="direction"
                                    >
                                        <Select data={constants.direction} />
                                    </Form.Item>
                                </Grid.Row>
                                <Grid.Row>
                                    <Form.Item label="Flow过滤条件" name="conditions">
                                        <Condition />
                                    </Form.Item>
                                </Grid.Row>
                            </Grid>
                        </Tabs.TabPane>
                        <Tabs.TabPane tab="统计方式" key="3">
                            <Grid>
                                <Grid.Row>
                                    <Grid.Col span={16} offset={3}>
                                        <Form.Item label="子任务" name="patterns">
                                            <Pattern />
                                        </Form.Item>
                                    </Grid.Col>
                                </Grid.Row>
                            </Grid>
                        </Tabs.TabPane>
                    </Tabs>
                </Form>
            </ScrollView>
        </Modal>
    )
}