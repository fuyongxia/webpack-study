import React, { useState, useContext, useEffect } from 'react';
import { Modal, Table, Button, Form, Tag } from 'antd';
import { useModalForm, useTableResults } from 'hooks';
import { Constant, renderer } from 'ui';

export default function(props) {
    const constants = useContext(Constant.Context);
    const [ selection, setSelection ] = useState([]);
    const [ filters, setFilters ] = useState({ });
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish});
    const { table, setTable, tableProps } = useTableResults(app.service.groupQueryInfterface, [ filters._updatedAt ], { 
        filters,
        rowSelection: {
            selectedRowKeys: (props.value || '').split(',').filter(Boolean),
            onChange(keys) {
                setTable({
                    rowSelection: {
                        ...table.rowSelection,
                        selectedRowKeys: keys
                    }
                })
            }
        },
        rowKey: 'interfaceid',
        size: 'middle',
        bordered: true
    })

    useEffect(() => {
        app.service.groupQueryMatchingInterface({
            pageSize: 999,
            interfaceIds: table.rowSelection.selectedRowKeys.join(','),
            selectType: 'MANUAL'
        }).then(body => {
            setSelection(body.content || []);
        })

    }, [table.rowSelection.selectedRowKeys.join(',')])

    function onFinish() {
        if (props.onChange) {
            props.onChange(selection.map(item => item.interfaceid).join(','));
        }
        setModalForm(false);
    }

    function onSelect() {
        setModalForm({
            title: '选择接口',
            type: 'update',
            data: {}
        })
        setFilters({ 
            routerIds: props.routerIds,
            _updatedAt: Date.now() 
        })
    }

    function onClose(index) {
        return () => {
            const rs = selection.slice();
            rs.splice(index, 1);
            setTable({
                rowSelection: {
                    ...table.rowSelection,
                    selectedRowKeys: rs.map(item => item.interfaceid)
                }
            })
            setSelection(rs);
        }
    }

    return (
        <>
            <Button type="primary" onClick={onSelect}>选择接口</Button>
            {modalForm && (
                <Modal visible width={800}  {...modalFormProps}>
                    <Form {...modalFormProps}>
                    <div style={{ margin: '10px 0'}}>
                        <span style={{ float: 'left' }}>已选接口：</span>
                        <div>
                        {selection.map((item, index) => (
                            <Tag closable onClose={onClose(index)} style={{ marginBottom: 5}}>{item.name}</Tag>
                        ))}
                        </div>
                    </div>
                    <div>
                        <Table {...tableProps}>
                            <Table.Column title="路由器" dataIndex={['baseRouter', 'name']} />
                            <Table.Column title="接口名称" dataIndex="name" />
                            <Table.Column title="接口描述" dataIndex="description" />
                            <Table.Column title="接口类型" dataIndex="ifboundarytype"  render={renderer.enumRender({ data: constants.interface_type })}  />
                            <Table.Column title="flowindex" dataIndex="flowindex" />
                            <Table.Column title="snmpindex" dataIndex="snmpindex" />
                        </Table>
                    </div>
                    </Form>
                </Modal>
            )}
        </>
    )
}