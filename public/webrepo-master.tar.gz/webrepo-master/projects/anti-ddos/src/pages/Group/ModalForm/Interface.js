import { Form, Input, Radio } from 'antd';
import React, { useContext } from 'react';
import { Constant, Grid, Select } from 'ui';
import InterfaceResult from './InterfaceResult';
import InterfaceSelect from './InterfaceSelect';

export default function (props) {
    const constants = useContext(Constant.Context);

    return (
        <Grid labelWidth="100px">
            <Grid.Row>
                <Grid.Col span={18} offset={3}>
                    <Form.Item
                        label="选择网络设备"
                        name="routerIds"
                    >
                        <Select mode="multiple" params={{pageSize: 999}} service={app.service.routerPage} labelField="name" valueField="routerid" />
                    </Form.Item>
                    <Form.Item
                        label="接口匹配方式"
                        name="selectType"
                    >
                        <Radio.Group>
                            {(constants.select_type || []).map(item => (
                                <Radio value={item.value}>{item.name}</Radio>
                            ))}
                        </Radio.Group>
                    </Form.Item>
                    {props.data.selectType == 'AUTO' && (
                        <>
                            <Form.Item
                                label="匹配方式"
                                name="matchingType"
                            >
                                <Select data={constants.matching_type} />
                            </Form.Item>
                            {props.data.matchingType !== 'INTERFACE_TYPE' && (
                                <Form.Item
                                    label="匹配内容"
                                    name="matchingValue"
                                >
                                    <Input />
                                </Form.Item>
                            )}
                            {props.data.matchingType == 'INTERFACE_TYPE' && (
                                <Form.Item
                                    label="匹配内容"
                                    name="matchingValue"
                                >
                                    <Select  data={constants.interface_type} />
                                </Form.Item>
                            )}
                        </>
                    )}
                    {props.data.selectType == 'MANUAL' && (
                        <Form.Item
                            label="选择接口"
                            name="interfaceIds"
                        >
                            <InterfaceSelect routerIds={props.data.routerIds} />
                        </Form.Item>
                    )}
                </Grid.Col>
            </Grid.Row>
            <Grid.Row>
                 <InterfaceResult data={props.data} />
            </Grid.Row>
        </Grid>
    )
}