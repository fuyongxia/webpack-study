import React, { useContext } from 'react';
import { Modal, Form, Row, Col, Input, Button, Space, Tabs } from 'antd';
import { Grid, Select, CitySelect, ProvinceSelect, Constant } from 'ui';


export default function (props) {
    const constants = useContext(Constant.Context);

    return (
        <Grid labelWidth="100px">
            <Grid.Row>
                <Grid.Col span={18} offset={3}>
                    <Form.Item
                        label="边界名称"
                        name="name"
                        rules={[{ required: true }]}
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        label="边界描述"
                        name="description"
                    >
                        <Input.TextArea />
                    </Form.Item>
                    <Form.Item
                        label="边界类型"
                        name="boundaryType"
                    >
                        <Select data={constants.boundary_type} />
                    </Form.Item>
                    <Form.Item
                        label="归属省份"
                        name="province"
                    >
                        <ProvinceSelect />
                    </Form.Item>
                    <Form.Item
                        label="归属城市"
                        name="city"
                    >
                        <CitySelect province={props.data.province} />
                    </Form.Item>
                    <Form.Item
                        label="归属网络"
                        name="belongNetwork"
                    >
                        <Input />
                    </Form.Item>
                </Grid.Col>
            </Grid.Row>
        </Grid>
    )
}