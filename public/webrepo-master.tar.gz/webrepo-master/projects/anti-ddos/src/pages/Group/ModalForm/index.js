import React, { useRef } from 'react';
import { Modal, Form, Row, Col, Input, Select, Button, Space, Tabs } from 'antd';
import { Grid, ScrollView } from 'ui';
import BaseInfo from './BaseInfo';
import Interface from './Interface';
import Threshold from './Threshold';

export default function (props) {

    function onValuesChange(data) {
        if ('province' in data) {
            data.city = '';
        }
        if ('matchingType' in data) {
            data.matchingValue = '';
        }
        props.onValuesChange(data);
    }

    return (
        <Modal {...props} width={800} visible>
            <Form {...props} onValuesChange={onValuesChange}>
                <ScrollView minHeight={500} maxHeight={500}>
                    <Tabs defaultActiveKey="1">
                        <Tabs.TabPane tab="基础信息" key="1">
                            <BaseInfo {...props} />
                        </Tabs.TabPane>
                        <Tabs.TabPane tab="匹配接口" key="2">
                            <Interface {...props} />
                        </Tabs.TabPane>
                        <Tabs.TabPane tab="边界应用" key="3">
                            <Threshold {...props}  />
                        </Tabs.TabPane>
                    </Tabs>
                </ScrollView>
            </Form>
        </Modal>
    )
}