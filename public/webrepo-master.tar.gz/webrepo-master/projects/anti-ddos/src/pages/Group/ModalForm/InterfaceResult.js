import React, { useState, useContext, useEffect } from 'react';
import { Modal, Table, Button, Tag } from 'antd';
import { useModalForm, useTableFilters, useTableResults } from 'hooks';
import { Constant, renderer } from 'ui';

export default function(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish});
    const { table, tableProps } = useTableResults(app.service.groupQueryMatchingInterface, [ filters._updatedAt ], { 
        filters,
        rowKey: 'interfaceid',
        size: 'middle',
        bordered: true
    })

    function onFinish() {
        setModalForm(false);
    }

    function onView() {
        setModalForm({
            title: '查看匹配结果',
            type: 'view',
            data: {}
        })
        setFilters({ 
            _updatedAt: Date.now() ,
            routerIds: props.data.routerIds,
            selectType: props.data.selectType,
            matchingType: props.data.matchingType,
            matchingValue: props.data.matchingValue,
            interfaceIds: props.data.interfaceIds,
        });
    }

    return (
        <>
            <Button type="primary" onClick={onView}>查看匹配结果</Button>
            {modalForm && (
                <Modal {...modalFormProps} visible width={800}>
                    <div>
                        <Table {...tableProps}>
                            <Table.Column title="路由器" dataIndex={['baseRouter', 'name']} />
                            <Table.Column title="接口名称" dataIndex="name" />
                            <Table.Column title="接口描述" dataIndex="description" />
                            <Table.Column title="接口类型" dataIndex="ifboundarytype"  render={renderer.enumRender({ data: constants.interface_type })}  />
                            <Table.Column title="接口索引" dataIndex="snmpindex" />
                            <Table.Column title="Flow索引" dataIndex="flowindex" />
                        </Table>
                    </div>
                </Modal>
            )}
        </>
    )
}