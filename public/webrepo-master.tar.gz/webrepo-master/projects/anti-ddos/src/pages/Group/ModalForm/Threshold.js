import { Form, InputNumber } from 'antd';
import React from 'react';
import { Grid, Switch } from 'ui';

export default function (props) {
    return (
        <Grid labelWidth="100px">
            <Grid.Row >
                <Grid.Col  span={18} offset={3}>
                    <Form.Item
                        label="接口流量阈值"
                    >
                        <div>
                            <span>上限流量</span>
                            <Form.Item noStyle name="highSwitch">
                                <Switch style={{ margin: "0 10px" }} />
                            </Form.Item>
                            <Form.Item noStyle name="speedthresholdHigh">
                                <InputNumber size="small" />
                            </Form.Item>
                                    %
                                </div>
                        <div style={{ marginTop: 5 }}>
                            <span>下限流量</span>
                            <Form.Item noStyle name="lowSwitch">
                                <Switch style={{ margin: "0 10px" }} />
                            </Form.Item>
                            <Form.Item noStyle name="speedthresholdLow">
                                <InputNumber size="small" />
                            </Form.Item>
                                    %
                                </div>
                    </Form.Item>
                </Grid.Col>
            </Grid.Row>
        </Grid>
    )
}