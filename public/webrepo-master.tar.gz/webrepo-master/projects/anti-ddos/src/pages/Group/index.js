import { PlusOutlined } from '@ant-design/icons';
import { Button, Input } from 'antd';
import { useModalForm, useTableFilters } from 'hooks';
import React, { useContext } from 'react';
import { Route, Switch } from "react-router-dom";
import { CitySelect, confirm, Constant, Filters, Page, ProvinceSelect, renderer, Results, Select, Table } from 'ui';
import ModalForm from './ModalForm';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSave });

    function onSave() {
        setModalForm({ ...modalForm, confirmLoading: true });
        app.service.groupEdit(modalForm.data)
            .then(body => {
                setModalForm(false);
                setFilters({ _updatedAt: Date.now() });
            }).catch(error => {
                setModalForm({ ...modalForm, confirmLoading: false });
                throw error;
            })
    }

    function onAdd() {
        setModalForm({
            type: 'add',
            title: '新增',
            data: {}
        })
    }

    function onView(record) {
        return () => {
            setModalForm({
                type: 'view',
                title: '查看',
                data: record
            })
        }
    }

    function onUpdate(record) {
        return () => {
            setModalForm({
                type: 'update',
                title: '修改',
                data: record
            })
        }
    }

    function onRemove(record) {
        return () => {
            confirm(app.service.groupDelete)(record)
                .then(()=> {
                    setFilters({ _updatedAt: Date.now() });
                })
        }
    }

    function onFilterChange(data) {
        if ('province' in data) {
            data.city = '';
        }
        filtersProps.onValuesChange(data);
    }

    return (
        <Page title="网络边界">
            <Filters {...filtersProps} onValuesChange={onFilterChange}>
                <Filters.Item
                    label="边界名称"
                    name="name"
                >
                    <Input />
                </Filters.Item>
                <Filters.Item
                    label="边界类型"
                    name="boundaryType"
                >
                    <Select data={constants.boundary_type} allowClear />
                </Filters.Item>
                <Filters.Item
                    label="包含网络设备"
                    name="routerIds"
                >
                    <Select params={{ pageSize: 999}} service={app.service.routerPage} labelField="name" valueField="routerid" allowClear />
                </Filters.Item>
                <Filters.Item
                    label="省份"
                    name="province"
                >
                    <ProvinceSelect allowClear />
                </Filters.Item>
                <Filters.Item
                    label="城市"
                    name="city"
                >
                    <CitySelect province={filters.province} allowClear />
                </Filters.Item>
                <Filters.Item
                    label="网络"
                    name="belongNetwork"
                >
                    <Input />
                </Filters.Item>
            </Filters>
            <Results
                title="网络边界列表"
                extra={[
                    <Button icon={<PlusOutlined />} type="primary" onClick={onAdd}>新增</Button>
                ]}
            >
                {Table.create({
                    filters,
                    service: app.service.groupPage,
                    columns: [
                        {
                            title: '边界名称',
                            dataIndex: 'name'
                        },
                        {
                            title: '边界类型',
                            dataIndex: 'boundaryType',
                            render: renderer.enumRender({ data: constants.boundary_type })
                        },
                        {
                            title: '省份',
                            dataIndex: 'province',
                        },
                        {
                            title: '城市',
                            dataIndex: 'city',
                        },
                        {
                            title: '网络',
                            dataIndex: 'belongNetwork',
                        },
                        {
                            title: '网络设备',
                            dataIndex: 'baseRouters',
                            render: value => (value || []).map(item => item.name).join(',')
                        },
                        {
                            title: '操作',
                            render: renderer.actionRender([
                                {
                                    title: '查看',
                                    action: onView
                                },
                                {
                                    title: '编辑',
                                    action: onUpdate
                                },
                                {
                                    title: '删除',
                                    action: onRemove
                                }
                            ])
                        }
                    ]
                })}
            </Results>
            { modalForm && <ModalForm {...modalFormProps} />}
        </Page>
    )
}


export default function (props) {
    return (
        <Switch>
            <Route exact path="/group">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}