import React, { useState, useEffect, useRef } from 'react';
import { BrowserRouter as Router, Switch, Route, useHistory } from "react-router-dom";
import { Input, Button, Form, message } from 'antd';
import { useConstructor } from 'hooks';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import style from './style.module.less';

function Page() {
    useConstructor(() => {
        app.config({
            title: '安全采控系统',
            description: '中盈优创安全采控系统',
            copyright: '中盈优创责任有限公司',
            service: {
                items: {
                    login: 'POST api/login'
                }
            }
        });
    })

    const formRef = useRef(null);
    const [loginForm, setLoginForm] = useState({
        data: {
            _ck: Date.now()
        },
        message: ''
    });

    function onValuesChange(data) {
        setLoginForm({
            data: {
                ...loginForm.data,
                ...data
            }
        })
    }

    function onFinish() {
        setLoginForm({ message: '' });

        app.service.login(loginForm.data)
            .then(body => {
                message.success('登录成功');

                const { userName, authToken } = body;
                app.cookie.set(authToken.name, authToken.value);
                app.cookie.set(app.config.key + '_USER', { userName });
            }).catch(e => {
                onValuesChange({ _ck: Date.now() });
                setLoginForm({
                    message: e.message
                })
            })
    }

    return (
        <div className={style.container}>
            <div className={style.top}>
            </div>
            <div className={style.header}>
                <h1>
                    {app.config.logo && <img className="logo" src={app.config.logo} alt="logo" />}
                    <span className="title">{app.config.title}</span>
                </h1>
                <p className="desc">{app.config.description}</p>
            </div>
            <div className={style.body}>
                <div className={style.panel}>
                    <Form ref={formRef} data={loginForm} onValuesChange={onValuesChange} onFinish={onFinish}>
                        <Form.Item
                            name="username"
                            rules={[{ required: true, message: '用户名不能为空' }]}
                        >
                            <Input prefix={<UserOutlined />} placeholder="用户名" size="large" />
                        </Form.Item>
                        <Form.Item
                            name="password"
                            rules={[{ required: true, message: '密码不能为空' }]}
                        >
                            <Input.Password prefix={<LockOutlined />} placeholder="密码" size="large" />
                        </Form.Item>
                        <div style={{ display: 'flex' }}>
                            <Form.Item
                                name="captcha"
                                className={style.captcha}
                                rules={[{ required: true, message: '验证码不能为空' }]}
                            >
                                <Input prefix={<LockOutlined />} placeholder="验证码" size="large" />
                            </Form.Item>
                            <Form.Item style={{ flex: 1 }}>
                                <img src={`api/captcha/show?_ck=${loginForm._ck}`} onClick={() => { onValuesChange({ _ck: Date.now() }) }} alt="验证码" />
                            </Form.Item>
                        </div>
                        <Form.Item>
                            <Button type="primary" style={{ width: '100%' }} size="large" onClick={() => { formRef.current.submit() }}>登录</Button>
                        </Form.Item>
                        <div className={style.error}>{loginForm.message}</div>
                    </Form>
                </div>
            </div>
            <div className={style.footer}>
                <p>{app.config.copyright}</p>
            </div>
        </div>
    )
}

export default function(props) {
    return (
        <Switch>
            <Route exact path="/login" children={<Page />} />
        </Switch>
    )
};