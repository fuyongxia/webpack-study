import { Sankey } from '@ant-design/charts';
import { Form, Radio } from 'antd';
import { useService, useTableFilters } from 'hooks';
import React from 'react';
import { Checkbox, renderer } from 'ui';

export default function (props) {
    const { filters, filtersProps } = useTableFilters({
        ...props.filters,
        isReal: ''
    });
    let dataSource = useService(app.service.analysisSrcRoute, filters);

    const config = {
        data: dataSource || [],
        sourceField: 'source',
        targetField: 'target',
        weightField: 'value',
        nodeWidthRatio: 0.008,
        nodePaddingRatio: 0.03,
    };

    return (

        <div>
            <Form {...filtersProps}>
                <Form.Item
                    label="统计方式"
                    name="isReal"
                >
                    <Radio.Group>
                        <Radio value="">所有流量</Radio>
                        <Radio value="yes">合法源地址流量</Radio>
                        <Radio value="no">虚假源地址流量</Radio>
                    </Radio.Group>
                </Form.Item>
                <Form.Item
                    label="展示内容"
                >
                    <Form.Item noStyle name="srcipEnable"><Checkbox>源IP</Checkbox></Form.Item>
                    <Form.Item noStyle name="cityEnable"><Checkbox>城域</Checkbox></Form.Item>
                    <Form.Item noStyle name="provinceEnable"><Checkbox>省网</Checkbox></Form.Item>
                    <Form.Item noStyle name="ispEnable"><Checkbox>运营商</Checkbox></Form.Item>
                    <Form.Item noStyle name="objectEnable"><Checkbox>检测群组</Checkbox></Form.Item>
                    <Form.Item noStyle name="dstipEnable"><Checkbox>目标IP</Checkbox></Form.Item>
                </Form.Item>
            </Form>
            <Sankey {...config} />
        </div>
    )
}