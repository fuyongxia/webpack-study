import { Form, Tabs } from 'antd';
import { useTableFilters } from 'hooks';
import React, { useContext, useEffect, useState } from 'react';
import { Route, Switch, useLocation } from "react-router-dom";
import { Constant, Grid, Select, Table, Filters, Page, Results, renderer } from 'ui';
import SrcAreaTable from './SrcArea';
import SrcNetworkTable from './SrcNetwork';
import SrcRouteChart from './SrcRoute';

function Index(props) {
    const constants = useContext(Constant.Context);
    const location = useLocation();
    const params = new URLSearchParams(location.search);

    const [ attackInfo, setAttackInfo ] = useState({});
    const { filters, setFilters, filtersProps } = useTableFilters({
        boundaryType: 'ALL',
        boundaryValue: '',
        attackId: params.get('attackId')
    });

    useEffect(() => {
        app.service.attackDdosInfo(filters)
            .then(body => {
                setAttackInfo(body);
            })
    }, [filters._updatedAt])

    return (
        <Page title="攻击分析">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="网络边界"
                    name="boundaryType"
                >
                    <Select allowClear data={constants.net_boundary_type} />
                </Filters.Item>
                {filters.boundaryType == 'FLOW_RESOURCE' && (
                    <Filters.Item
                        label=""
                        colon=""
                        name="boundaryValue"
                    >
                        <Select allowClear params={{pageSize: 999}} service={app.service.routerPage} labelField="name" valueField="routerid" />
                    </Filters.Item>
                )}
            </Filters>
            <Results>
                <Grid>
                    <Grid.Row>
                        <Form.Item label="攻击ID">{_.get(attackInfo, 'attackId')}</Form.Item>
                        <Form.Item label="监测对象">{_.get(attackInfo, ['cust', 'custname'])}</Form.Item>
                        <Form.Item label="对象类型">{renderer.enumRender({data: constants.detect_object_type})(_.get(attackInfo, ['cust', 'type']))}</Form.Item>
                        <Form.Item label="攻击目标">{_.get(attackInfo, 'attackTarget')}</Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item label="攻击类型">{_.get(attackInfo, ['attackTypeObject', 'primaryName'])}</Form.Item>
                        <Form.Item label="告警级别">{renderer.enumRender({data: constants.attack_level})(_.get(attackInfo, 'level'))}</Form.Item>
                        <Form.Item label="攻击方向">{renderer.enumRender({data: constants.attack_direction})(_.get(attackInfo, 'direction'))}</Form.Item>
                        <Form.Item label="当前状态">{renderer.enumRender({data: constants.attack_status})(_.get(attackInfo, 'status'))}</Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item label="开始时间">{renderer.dateRender()(_.get(attackInfo, 'startTime'))}</Form.Item>
                        <Form.Item label="结束时间">{renderer.dateRender()(_.get(attackInfo, 'endTime'))}</Form.Item>
                        <Form.Item label="持续时间">{renderer.durationRender()(_.get(attackInfo, 'duration'))}</Form.Item>
                        <Form.Item label=""></Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item label="流速峰值">{renderer.flowRender()(_.get(attackInfo, 'maxBps'))}</Form.Item>
                        <Form.Item label="包速峰值">{renderer.flowRender()(_.get(attackInfo, 'maxPps'))}</Form.Item>
                        <Form.Item label="总字节数">{renderer.flowRender()(_.get(attackInfo, 'btyecount'))}</Form.Item>
                        <Form.Item label="总包数">{renderer.flowRender()(_.get(attackInfo, 'packcount'))}</Form.Item>
                    </Grid.Row>
                </Grid>
            </Results>
            <Results
            >
                <Tabs defaultActiveKey="1">
                    <Tabs.TabPane tab="攻击源区域分析" key="1">
                        <SrcAreaTable filters={filters} />
                    </Tabs.TabPane>
                    <Tabs.TabPane tab="攻击源C类网段分析" key="2">
                        <SrcNetworkTable filters={filters} />
                    </Tabs.TabPane>
                    <Tabs.TabPane tab="攻击路径分析" key="3">
                        <SrcRouteChart filters={filters} />
                    </Tabs.TabPane>
                </Tabs>
            </Results>
        </Page>
    )
}

export default function (props) {
    const constants = {
        net_boundary_type: [
            { name: '全网范围', value: 'ALL' },
            { name: '对象网络边界', value: 'OBJECT' },
            { name: '网络设备', value: 'FLOW_RESOURCE' },
        ]
    }

    return (
        <Switch>
            <Route exact path="/attack_analysis">
                <Constant.Provider value={constants}>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}