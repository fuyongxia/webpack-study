import React from 'react';
import { Table } from 'antd';
import { util, renderer } from 'ui';
import { useService, useTableResults } from 'hooks';

export default function(props) {
    let dataSource = useService(app.service.analysisSrcNetwork, props.filters);
    const columns = [
        {
            title: 'C类网段',
            render: (text, record) => {
                return `${record.name} (IP: ${record.ipNum})`;
            }
        },
        {
            title: '平均流速bps',
            dataIndex: 'bps',
            render: renderer.flowRender()
        },
        {
            title: '平均包速pps',
            dataIndex: 'pps',
            render: renderer.flowRender()
        },
        {
            title: '总字节数bytes',
            dataIndex: 'bytecount',
            render: renderer.flowRender()
        },
        {
            title: '总包数pckts',
            dataIndex: 'packcount',
            render: renderer.flowRender()
        },
        {
            title: '总字节数占比',
            dataIndex: 'byteRate'
        },
        {
            title: '总包数占比',
            dataIndex: 'packRate'
        },
        {
            title: '操作',
            dataIndex: ''
        },
    ]

    const dsTree = util.denormalize((dataSource || []), {
        id: 'node',
        pid: 'pnode',
        root: { node: "" },
    }).children;

    return (
        <Table rowKey="node" columns={columns} dataSource={dsTree}  />
    )

}