import { Form } from 'antd';
import { useTableFilters } from 'hooks';
import React, { useContext, useEffect, useState } from 'react';
import { Route, Switch, useLocation } from "react-router-dom";
import { Constant, Grid, Select, Table, Filters, Page, Results, renderer } from 'ui';
import LineChart from './LineChart';


function Index(props) {
    const constants = useContext(Constant.Context);
    const location = useLocation();
    const params = new URLSearchParams(location.search);

    const [ chartData, setChartData ] = useState([]);
    const [ attackInfo, setAttackInfo ] = useState({});
    const { filters, setFilters, filtersProps } = useTableFilters({
        boundaryType: 'ALL',
        boundaryValue: '',
        attackId: params.get('attackId')
    });

    useEffect(() => {
        app.service.attackDdosInfo(filters)
            .then(body => {
                setAttackInfo(body);
            })
    }, [filters._updatedAt])

    useEffect(() => {
        app.service.attackDdosProcess(filters)
            .then(body => {
                const results = [];
                (body.reverse() || []).map(item => {
                    results.push({
                        type: 'bps',
                        value: item.bps,
                        datatime: renderer.dateRender()(item.datatime)
                    });
                    results.push({
                        type: 'pps',
                        value: item.pps,
                        datatime: renderer.dateRender()(item.datatime)
                    });
                });
                setChartData(results);
            })
    }, [filters._updatedAt])

    const config = {
        className: 'chart-enlarge',
        data: chartData,
        xField: "datatime",
        yField: "value",
        seriesField: "type",
        legend: { position: 'top'},
        smooth: true,
        meta: {
            value: {
                formatter: function formatter(v) {
                    return renderer.flowRender()(v);
                    }
            }
        }
    }

    return (
        <Page title="攻击过程">
            <Filters {...filtersProps}>
                <Filters.Item
                    label="网络边界"
                    name="boundaryType"
                >
                    <Select allowClear data={constants.net_boundary_type} />
                </Filters.Item>
                {filters.boundaryType == 'FLOW_RESOURCE' && (
                    <Filters.Item
                        label=""
                        colon=""
                        name="boundaryValue"
                    >
                        <Select allowClear params={{pageSize: 999}} service={app.service.routerPage} labelField="name" valueField="routerid" />
                    </Filters.Item>
                )}
            </Filters>
            <Results>
                <Grid>
                    <Grid.Row>
                        <Form.Item label="攻击ID">{_.get(attackInfo, 'attackId')}</Form.Item>
                        <Form.Item label="监测对象">{_.get(attackInfo, ['cust', 'custname'])}</Form.Item>
                        <Form.Item label="对象类型">{renderer.enumRender({data: constants.detect_object_type})(_.get(attackInfo, ['cust', 'type']))}</Form.Item>
                        <Form.Item label="攻击目标">{_.get(attackInfo, 'attackTarget')}</Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item label="攻击类型">{_.get(attackInfo, ['attackTypeObject', 'primaryName'])}</Form.Item>
                        <Form.Item label="告警级别">{renderer.enumRender({data: constants.attack_level})(_.get(attackInfo, 'level'))}</Form.Item>
                        <Form.Item label="攻击方向">{renderer.enumRender({data: constants.attack_direction})(_.get(attackInfo, 'direction'))}</Form.Item>
                        <Form.Item label="当前状态">{renderer.enumRender({data: constants.attack_status})(_.get(attackInfo, 'status'))}</Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item label="开始时间">{renderer.dateRender()(_.get(attackInfo, 'startTime'))}</Form.Item>
                        <Form.Item label="结束时间">{renderer.dateRender()(_.get(attackInfo, 'endTime'))}</Form.Item>
                        <Form.Item label="持续时间">{renderer.durationRender()(_.get(attackInfo, 'duration'))}</Form.Item>
                        <Form.Item label=""></Form.Item>
                    </Grid.Row>
                    <Grid.Row>
                        <Form.Item label="流速峰值">{renderer.flowRender()(_.get(attackInfo, 'maxBps'))}</Form.Item>
                        <Form.Item label="包速峰值">{renderer.flowRender()(_.get(attackInfo, 'maxPps'))}</Form.Item>
                        <Form.Item label="总字节数">{renderer.flowRender()(_.get(attackInfo, 'btyecount'))}</Form.Item>
                        <Form.Item label="总包数">{renderer.flowRender()(_.get(attackInfo, 'packcount'))}</Form.Item>
                    </Grid.Row>
                </Grid>
            </Results>
            <Results>
                <LineChart cfg={config} />
            </Results>
            <Results
                title="攻击过程列表"
            >
                {Table.create({
                    filters,
                    service: app.service.attackDdosProcess,
                    columns: [
                        {
                            title: '时间',
                            dataIndex: 'datatime',
                            render: renderer.dateRender()
                        },
                        {
                            title: '攻击类型',
                            dataIndex: 'attackTypeObjects',
                            render: (value) => {
                                return (value || []).map(item => item.primaryName).join(',')
                            }
                        },
                        {
                            title: '告警级别',
                            dataIndex: 'level',
                            render: renderer.enumRender({ data: constants.attack_level})
                        },
                        {
                            title: '字节数byte',
                            dataIndex: 'bytecount',
                            render: renderer.flowRender()
                        },
                        {
                            title: '包数pkts',
                            dataIndex: 'packcount',
                            render: renderer.flowRender()
                        },
                        {
                            title: '包速pps',
                            dataIndex: 'pps',
                            render: renderer.flowRender()
                        },
                        {
                            title: '流速bps',
                            dataIndex: 'bps',
                            render: renderer.flowRender()
                        },
                        {
                            title: '状态',
                            dataIndex: 'status',
                            render: renderer.enumRender({ data: constants.attack_status})
                        },
                    ]
                })}
            </Results>
        </Page>
    )
}

export default function (props) {
    const constants = {
        net_boundary_type: [
            { name: '全网范围', value: 'ALL' },
            { name: '对象网络边界', value: 'OBJECT' },
            { name: '网络设备', value: 'FLOW_RESOURCE' },
        ]
    }

    return (
        <Switch>
            <Route exact path="/attack_process">
                <Constant.Provider value={constants}>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}