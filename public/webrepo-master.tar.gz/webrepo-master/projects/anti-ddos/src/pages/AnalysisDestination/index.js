import { useTableFilters } from 'hooks';
import { Route, Switch } from "react-router-dom";
import React, { useContext, useEffect } from 'react';
import { CitySelect, RangePicker, Filters, Grid, Page, ProvinceSelect, Results, Select, Constant } from 'ui';
import AttackLevel from './AttackLevel';
import AttackBps from './AttackBps';
import AttackPps from './AttackPps';
import AttackByte from './AttackByte';
import AttackPacket from './AttackPacket';
import AttackType from './AttackType';
import AttackTarget from './AttackTarget';
import AttackDuration from './AttackDuration';
import AttackTime from './AttackTime';

function Index(props) {
    const constants = useContext(Constant.Context);
    const { filters, setFilters, filtersProps } = useTableFilters({});

    useEffect(() => {
        if (Object.keys(constants).length > 0) {
            setFilters({
                dstType: constants.attack_dst_type[0].value,
                analysisType: constants.attack_analysis_type[0].value,
                period: constants.time_period[0].value,
                _updatedAt: Date.now()
            })
        }
    }, [ Object.keys(constants).length ]);


    function onFiltersChange(updatedValues) {
        if (updatedValues.dstType) {
            updatedValues.dstName = '';
        }
        filtersProps.onValuesChange(updatedValues);
    }

    return (
        <Page title="攻击目的地分析">
            <Filters {...filtersProps} onValuesChange={onFiltersChange}>
                <Filters.Item
                    label="目的类型"
                    name="dstType"
                >
                    <Select allowClear data={constants.attack_dst_type} />
                </Filters.Item>
                {filters.dstType && (
                    <Filters.Item
                        label="目的名称"
                    >
                        {filters.dstType == 'OBJECT' && (
                            <Filters.Item noStyle name="dstName">
                                <Select allowClear params={{ pageSize: 9999 }} service={app.service.customerPage} labelField="custname" valueField="custcode" />
                            </Filters.Item>
                        )}
                        {filters.dstType == 'PROVINCE' && (
                            <Filters.Item noStyle name="dstName"><ProvinceSelect allowClear /></Filters.Item>
                        )}
                        {filters.dstType == 'CITY' && (
                            <Filters.Item noStyle name="dstName"><CitySelect allowClear/></Filters.Item>
                        )}
                        {filters.dstType == 'ISP' && (
                            <Filters.Item noStyle name="dstName"><Select allowClear data={constants.isp_type} /></Filters.Item>
                        )}
                    </Filters.Item>
                )}
                <Filters.Item
                    label="分析类型"
                    name="analysisType"
                >
                    <Select data={constants.attack_analysis_type} />
                </Filters.Item>
                <Filters.Item
                    label="时间范围"
                    name="period"
                >
                    <Select allowClear data={constants.time_period} />
                </Filters.Item>
                {filters.period == 'DEFINED' && (
                    <Filters.Item
                        label="自定义时间段"
                        name="definedTime"
                    >
                        <RangePicker />
                    </Filters.Item>
                )}
            </Filters>
            {filters.analysisType == 'LEVEL' && (
                <AttackLevel filters={filters} />
            )}
            {filters.analysisType == 'MAINTAPE' && (
                <AttackType filters={filters} />
            )}
            {filters.analysisType == 'DURATION' && (
                <AttackDuration filters={filters} />
            )}
            {filters.analysisType == 'TIME' && (
                <AttackTime filters={filters} />
            )}
            {filters.analysisType == 'TARGET' && (
                <AttackTarget filters={filters} />
            )}
            {filters.analysisType == 'BPS' && (
                <AttackBps filters={filters} />
            )}
            {filters.analysisType == 'PPS' && (
                <AttackPps filters={filters} />
            )}
            {filters.analysisType == 'BYTE' && (
                <AttackByte filters={filters} />
            )}
            {filters.analysisType == 'PACKET' && (
                <AttackPacket filters={filters} />
            )}
        </Page>
    )
}

export default function (props) {
    return (
        <Switch>
            <Route exact path="/analysis_destination">
                <Constant.Provider>
                    <Index />
                </Constant.Provider>
            </Route>
        </Switch>
    )
}