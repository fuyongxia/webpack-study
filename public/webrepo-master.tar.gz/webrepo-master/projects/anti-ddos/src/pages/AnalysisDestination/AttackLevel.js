import React, { useState } from 'react';
import { Input } from 'antd';
import { Grid, Results, Table } from 'ui';
import { Pie } from '@ant-design/charts';

export default function (props) {
    const [ chartData, setChartData ] = useState([]);

    const config = {
        height: 250,
        appendPadding: 10,
        data: chartData,
        angleField: 'num',
        colorField: 'name',
        radius: 0.8,
        label: {
          type: 'inner',
          offset: '-30%',
          content: '{name}',
          style: {
            fontSize: 14,
            textAlign: 'center',
          },
        },
        state: {
          active: {
            style: {
              lineWidth: 0,
              fillOpacity: 0.65,
            },
          },
        },
        interactions: [{ type: 'element-selected' }, { type: 'element-active' }],
      };

    return (
        <>
            <Results title="攻击级别分布">
                <Grid>
                    <Grid.Row gutter={32}>
                        <Grid.Col span={7}>
                            <Pie {...config} />
                        </Grid.Col>
                        <Grid.Col span={2}>
                        </Grid.Col>
                        <Grid.Col span={14}>
                            {Table.create({
                                filters: props.filters,
                                service: (args) => {
                                    return app.service.attackAnalysisDstCount(args)
                                        .then(body => {
                                            setChartData(body);
                                            return body;
                                        })
                                },
                                columns: [
                                    {
                                        title: '序号',
                                        dataIndex: '_index'
                                    },
                                    {
                                        title: '级别',
                                        dataIndex: 'name'
                                    },
                                    {
                                        title: '数量',
                                        dataIndex: 'num'
                                    },
                                    {
                                        title: '占比',
                                        dataIndex: 'rate'
                                    },
                                    {
                                        title: '操作',
                                        dataIndex: ''
                                    },
                                ],
                                bordered: true
                            })}
                        </Grid.Col>
                    </Grid.Row>
                </Grid>
            </Results>
            <Results
                title="严重程度Top50攻击告警"
                extra={[
                    <Input placeholder="筛选IP" />
                ]}
            >
                {Table.create({
                    filters: props.filters,
                    service: app.service.attackAnalysisDstTop,
                    columns: [
                        {
                            title: '序号',
                            dataIndex: '_index'
                        },
                        {
                            title: '攻击告警ID',
                            dataIndex: 'attackId'
                        },
                        {
                            title: '攻击IP',
                            dataIndex: 'attackIp'
                        },
                        {
                            title: '攻击类型',
                            dataIndex: 'attackType'
                        },
                        {
                            title: '严重程度占比',
                            dataIndex: 'value'
                        },
                        {
                            title: '操作'
                        },
                    ]
                })}
            </Results>
        </>
    )

}