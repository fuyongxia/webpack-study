import React, { useState } from 'react';
import { Grid, Results, Table } from 'ui';
import { Liquid, Column  } from '@ant-design/charts';

export default function (props) {
    const [ rate, setRate ] = useState(0.0);
    const [ chartData, setChartData ] = useState([]);

    const liquidConfig = {
        percent: parseFloat(rate) * 0.01,
        outline: {
          border: 4,
          distance: 8,
        },
        wave: { length: 128 },
      };

    const columnConfig = {
        data: chartData,
        xField: 'name',
        yField: 'num',
        label: {
          position: 'middle',
          style: {
            fill: '#FFFFFF',
            opacity: 0.6,
          },
        }
      };

    return (
        <>
            <Results title="被攻击IP占比">
                <Grid>
                    <Grid.Row gutter={32}>
                        <Grid.Col span={4}>
                            <Liquid  {...liquidConfig} />
                        </Grid.Col>
                        <Grid.Col span={2}>
                        </Grid.Col>
                        <Grid.Col span={18}>
                            {Table.create({
                                filters: props.filters,
                                service: (args) => {
                                    return app.service.attackAnalysisDstTarget(args)
                                        .then(body => {
                                            setRate(body.rate);
                                            return [{
                                                name: body.totalIp,
                                                num: body.attackIp,
                                                rate: body.rate
                                            }];
                                        })
                                },
                                columns: [
                                    {
                                        title: 'IP地址数量',
                                        dataIndex: 'name'
                                    },
                                    {
                                        title: '被攻击IP数量',
                                        dataIndex: 'num'
                                    },
                                    {
                                        title: '占比',
                                        dataIndex: 'rate'
                                    },
                                    {
                                        title: '操作',
                                        dataIndex: ''
                                    },
                                ],
                                bordered: true,
                                align: 'center'
                            })}
                        </Grid.Col>
                    </Grid.Row>
                </Grid>
            </Results>
            <Results title="攻击目标次数Top50">
                <Grid>
                    <Grid.Row gutter={32}>
                        <Grid.Col span={24}>
                            <Column {...columnConfig} />
                        </Grid.Col>
                        <Grid.Col span={24} style={{marginTop: 10}}>
                            {Table.create({
                                filters: props.filters,
                                service: (args) => {
                                    return app.service.attackAnalysisDstCount(args)
                                        .then(body => {
                                            setChartData(body);
                                            return body;
                                        })
                                },
                                columns: [
                                    {
                                        title: '序号',
                                        dataIndex: '_index'
                                    },
                                    {
                                        title: '攻击IP',
                                        dataIndex: 'name'
                                    },
                                    {
                                        title: '攻击次数',
                                        dataIndex: 'num'
                                    },
                                    {
                                        title: '占比',
                                        dataIndex: 'rate'
                                    },
                                    {
                                        title: '操作',
                                        dataIndex: ''
                                    },
                                ],
                                bordered: true
                            })}
                        </Grid.Col>
                    </Grid.Row>
                </Grid>
            </Results>
        </>
    )
}