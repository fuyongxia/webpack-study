import React, { useEffect, useState } from 'react';
import { Select as AntSelect } from 'antd';

function Select(props) {
    const { service, params, labelField, valueField } = props;
    const [loading, setLoading] = useState(false);
    const [options, setOptions] = useState([]);

    useEffect(() => {
        setOptions(props.data || []);
    }, [JSON.stringify(props.data)])

    useEffect(() => {
        if (service) {
            setLoading(true);
            service(params).then(body => {
                body = body.content || body.results || body || [];
                setOptions(body);
                setLoading(false);
            }).catch(error => {
                setLoading(false);
                throw error;
            })
        }
    }, [JSON.stringify(params)])

    return (
        <AntSelect loading={loading} {...props}>
            {options.map(item => (
                <AntSelect.Option value={item[valueField]}>{item[labelField]}</AntSelect.Option>
            ))}
            {props.children}
        </AntSelect>
    )
}

Select.Option = AntSelect.Option;
Select.OptGroup = AntSelect.OptGroup;

Select.defaultProps = {
    labelField: 'name',
    valueField: 'value',
}

export default Select;