import React, { useState } from 'react';
import { Row as AntRow, Col as AntCol } from 'antd';

function Grid(props) {
    const [ randomClass, setRandomClass ] = useState(false);

    if (!randomClass) {
        setRandomClass('g' + Math.random().toString(36).substring(2));
    }

    let innerStyle = '';
    if (props.labelWidth) {
        innerStyle = `
            .${randomClass} .ant-form-item-label {
                width: ${props.labelWidth};
            }
        `
    }

    const children = props.children ? (props.children.length ? props.children : [ props.children]) : [];
    return (
        <div  {...props} className={`${randomClass} ${props.className}`}>
            <style>{innerStyle}</style>
            {children.map(item => {
                if (item.type === Grid.Row) {
                    return React.cloneElement(item, { gutter: props.gutter, ...item.props })
                }
                return item;
            })}
        </div>
    )
}

Grid.Row = function (props) {
    const children = props.children ? (props.children.length ? props.children : [ props.children]) : [];
    return (
        <AntRow {...props}>
            {children.map(item => {
                if (item.type !== Grid.Col) {
                    return (
                        <AntCol span={24/children.length}>
                            {item}
                        </AntCol>
                    )
                } 
                return item;
            })}
        </AntRow>
    )
};

Grid.Col = AntCol;

export default Grid;