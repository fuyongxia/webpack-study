import React from 'react';
import moment from 'moment';
import { Space } from 'antd';

function dateRender(format = 'YYYY-MM-DD HH:mm:ss') {
    return (value) => {
        return value && moment(value).format(format)
    }
}

function ipRender(sep = ';') {
    return (value) => {
        return (
            <pre style={{fontSize: 'inherit'}}>
                {(value || '').split(sep).join('\r\n')}
            </pre>
        );
    }
}


function enumRender(options) {
    function Text(props) {
        const { value, labelField, valueField, data } = props;

        const matched = data.find(item => (
            item[valueField] == value
        ));

        if (matched) {
            return matched[labelField];
        }

        return '';
    }

    Text.defaultProps = {
        data: [],
        labelField: 'name',
        valueField: 'value',
    }

    return (value) => {
        return (
            <Text value={value} {...options} />
        )
    }
}



function actionRender(items) {
    return (value, record) => {
        return (
            <Space>
                {items.map(item => (
                    <a onClick={item.action(record)}>{item.title}</a>
                ))}
            </Space>
        )
    }
}

function lineRender() {
    return (value) => {
        return (
            <pre style={{fontSize: 14, lineHeight: 1.5}}>
                {(value || '').split(',').join('\n')}
            </pre>
        )
    }
}

function convertTo(value, unit, fixed = 2, base) {
    if (value == null || _.isNaN(value)) {
        return;
    }
   
    if (base == null) {
        base = 1000;
    }

    const number = _.toNumber(value);

    if (0 == number) {
        return number + unit.slice(1);
    }

    if (!_.isNumber(number) || value < base) {
        return number.toFixed(fixed) + unit.slice(1);
    }

    let n = ' KMGTP'.indexOf(unit[0]);
    if (!n) {
        n = Math.floor(Math.log(number) / Math.log(base));
    }
    return (number / Math.pow(base, n)).toFixed(fixed) + ['', 'K', 'M', 'G', 'T', 'P'][n] + unit.slice(1);
}

function flowRender(unit = ' ', fixed, base) {
    return (value) => {
        value = parseFloat(value);
        return convertTo(value, unit, fixed, base);
    }
}

function durationRender() {
    return (value) => {
        if(value == 0){
            return '0秒';
        }
        const duration = moment.duration(value);
        const days = duration.days() ? duration.days() + '天' : '';
        const hours = duration.hours() ? duration.hours() + '小时' : '';
        const minutes = duration.minutes() ? duration.minutes() + '分' : '';
        const seconds = duration.seconds() ? duration.seconds() + '秒' : '';
        return `${days}${hours}${minutes}${seconds}`;
    }
}

function numToRateRender() {
    return (value) => {
        return value * 100 + '%'
    }   
}

function percentRender() {
    return (value) => {
        return value + '%'
    }   
}

export default { ipRender, dateRender, enumRender, actionRender, lineRender, durationRender, flowRender, numToRateRender, percentRender};