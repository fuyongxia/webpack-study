import React from 'react';
import { Space } from 'antd';
import style from './style.module.less';

export default function(props) {
    return (
        <div {...props} className={`${style.results} ${props.className}`}>
            <div className={style.header}>
                <Space>
                    <div className={style.title}>{props.title}</div>
                </Space>
                <Space>
                    {props.extra}
                </Space>
            </div>
            <div className={style.body}>
                {props.children}
            </div>
        </div>
    )
}