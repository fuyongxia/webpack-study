import React, { useState, useEffect, useRef } from 'react';
import { Form } from 'antd';
import jss from './jss';

function useConstructor(callback = ()=> {}) {
    const inited = useRef(false);
    if (!inited.current) {
        callback();
        inited.current = true;
    }
} 

function useStyles(styleSheet, deps) {
    const sheetRef = useRef(null);
    const [ inited, setInited ] = useState(false);

    if (!inited) {
        sheetRef.current = jss
            .createStyleSheet(styleSheet)
            .attach();
        setInited(true);
    }

    useEffect(() => {
        sheetRef.current.update(deps);
        return () => {
            sheetRef.current.detach();
        }
    }, deps ? [deps] : []);

    return sheetRef.current.classes;
}

function useValue({ value, onChange }) {
    const [ state, setState ] = useState(value);

    useEffect(() => {
        setState(value);
    }, [ value ])

    return [
        state,
        function(args) {
            setState(args);
            if (onChange) {
                onChange(args);
            }
        }
    ]
}

function useService(service, params) {
    const [ data, setData ] = useState();

    useEffect(() => {
        service(params).then(body => {
            setData(body);
        })
    }, [ JSON.stringify(params) ]);

    return data;
}

function useTableFilters(initState, options) {
    const [form] = Form.useForm();
    const [filters, setFilters] = useState(initState);

    const updateFilters = updatedValues => {
        form.setFieldsValue(updatedValues);
        setFilters(prevState => ({
            ...prevState,
            ...updatedValues
        }))
    };

    return {
        filters,
        setFilters: updateFilters,
        filtersProps: {
            form: form,
            initialValues: filters,
            onValuesChange: updateFilters,
            onFinish: () => {
                setFilters({ ...filters, _updatedAt: Date.now() });
            },
            ...options
        }
    }
}

function useTableResults(service, deps = [], options = {}) {
    const [ valueType, setValueType ] = useState('v1');
    const [props, setProps] = useState(options);
    
    const STYLES = {
        v1: {
            pageNum: 'pageNum',
            current: 'currentPage',
            pageSize: 'pageSize',
            total: 'recordTotal',
            results: 'content',
        },
        v2: {
            pageNum: 'pageNo',
            current: 'pageNo',
            pageSize: 'pageSize',
            total: 'totalCount',
            results: 'results'
        }
    }


    function setTable(args) {
        setProps(prevProps => {
            return { ...prevProps, ...args }
        })
    }

    function fetchData(params) {
        setTable({ loading: true });
        service(params).then(body => {
            body = body || [];
            if (Array.isArray(body)) {
                setTable({
                    loading: false,
                    dataSource: body.map((item, index) => ({
                        _index: index + 1,
                        ...item
                    })),
                    pagination: {
                        ...props.pagination,
                        hideOnSinglePage:true,
                        showTotal: (total, range) => `共 ${total} 条记录`
                    },
                })
            } else {
                let vt;
                
                if (body.content) {
                    vt = 'v1';
                }

                if (body.results) {
                    vt = 'v2';
                }

                setValueType(vt);
                setTable({
                    loading: false,
                    pagination: {
                        ...props.pagination,
                        current: body[STYLES[vt].current],
                        pageSize: body[STYLES[vt].pageSize],
                        total: body[STYLES[vt].total],
                        // hideOnSinglePage:true,
                        showTotal: (total, range) => `共 ${total} 条记录`
                    },
                    dataSource: (body[STYLES[vt].results] || []).map((item, index) => ({
                        _index: body[STYLES[vt].pageSize]*(body[STYLES[vt].current] -1) + index + 1,
                        ...item
                    }))
                })
            }
        }).catch(error => {
            setTable({
                loading: false
            })
            throw error;
        })
    }

    useEffect(() => {
        service && fetchData(options.filters);
    }, deps);

    return {
        table: props,
        setTable: setTable,
        tableProps: {
            ...props,
            onChange(pagination, filters, sorter, extra) {
                if (extra.action == 'paginate') {
                    service && fetchData({
                        ...options.filters,
                        [STYLES[valueType].pageNum]: pagination.current,
                        [STYLES[valueType].pageSize]: pagination.pageSize,
                    })
                }
                if (props.onChange) {
                    props.onChange(pagination, filters, sorter, extra)
                }
            }
        }
    }
}

function useModalForm(state, options = {}) {
    const [form] = Form.useForm();
    const [modalForm, setModalForm] = useState(state);

    useEffect(() => {
        if (modalForm) {
            form.resetFields();
        }
    }, [Boolean(modalForm)])

    const defaultOptions = {
        form,
        initialValues: modalForm.data,
        onOk() {
            form.submit();
        },
        onCancel() {
            setModalForm(false);
        },
        onValuesChange(data) {
            if (modalForm.type == 'view') {
                form.setFieldsValue(modalForm.data);
                return;
            }
            form.setFieldsValue(data);
            setModalForm({
                ...modalForm,
                data: {
                    ...modalForm.data,
                    ...data
                }
            })
        },
        footer: modalForm.type == 'view' ? null : undefined,
        className: modalForm.type == 'view' ? 'modal-readonly' : "",
        maskClosable: false
    }

    return {
        modalForm,
        setModalForm,
        modalFormProps: {
            ...modalForm,
            ...defaultOptions,
            ...options
        }
    }
}

export { useConstructor, useValue, useStyles, useService, useTableFilters, useTableResults, useModalForm };