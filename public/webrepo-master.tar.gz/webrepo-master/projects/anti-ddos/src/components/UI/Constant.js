import React, { useState, useEffect } from 'react';
import groupBy from 'lodash/groupBy';

const Context = React.createContext({});

function Provider(props) {
    const [ value, setValue ] = useState(props.value || {});

    useEffect(() => {
        app.service.dataList({}).then(body => {
            setValue(prevValue => ({
                ...prevValue,
                ...groupBy(body, 'type')
            }));
        })
    }, [])

    useEffect(() => {
        setValue(prevValue => ({
            ...prevValue,
            ...props.value
        }))
    }, [ JSON.stringify(props.value)]);

    return (
        <Context.Provider value={value}>
            {props.children}
        </Context.Provider>
    )
}

export default {
    Context: Context,
    Provider: Provider
}