import React from 'react';
import { message } from 'antd';

export default function(props) {
    function ping() {
        app.service.ping({ ip: props.ip })
            .then(body => {
                message.info(body);
            })
    }

    return (
        <a onClick={ping}>Ping</a>
    )
}