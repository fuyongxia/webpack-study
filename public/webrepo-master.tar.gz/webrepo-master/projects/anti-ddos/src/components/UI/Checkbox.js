import React from 'react';
import { Checkbox as AntCheckbox } from 'antd';

function Checkbox(props) {
    const { trueValue = 'ON', falseValue = 'OFF' } = props;
    function onChange(e) {
        props.onChange && props.onChange(e.target.checked ? trueValue: falseValue);
    }

    return (
        <AntCheckbox {...props} checked={props.value === trueValue} onChange={onChange} />
    )
}

export default Checkbox;