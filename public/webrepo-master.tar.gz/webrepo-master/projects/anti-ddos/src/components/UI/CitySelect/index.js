import React from 'react';
import { Select } from 'antd';
import cityData from '../cityData.json';
import provinceData from '../provinceData.json';

function CitySelect(props) {
    function getCityData() {
        if (props.province) {
            const province = provinceData.find(item => item.name == props.province);
            if (province) {
                return cityData.filter(item => item.province == province.province);
            }
            return [];
        } else {
            return cityData;
        }
    }

    return (
        <Select {...props}>
            {getCityData().map(item => (
                <Select.Option value={item.name}>{item.name}</Select.Option>
            ))}
        </Select>
    )
}

export default CitySelect;