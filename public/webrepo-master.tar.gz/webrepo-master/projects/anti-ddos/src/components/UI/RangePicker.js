import React from 'react';
import { DatePicker as AntDatePicker } from 'antd';

function RangePicker(props) {
    const dateFormat = 'YYYY/MM/DD';
    return (
        <AntDatePicker.RangePicker {...props} format={dateFormat} />
    )
}


export default RangePicker;