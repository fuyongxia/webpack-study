import React from 'react';
import { Switch as AntSwitch } from 'antd';

function Switch(props) {
    const { trueValue = 'ON', falseValue = 'OFF' } = props;
    function onChange(checked) {
        props.onChange && props.onChange(checked ? trueValue: falseValue);
    }
    return (
        <AntSwitch {...props} checked={props.value === trueValue} onChange={onChange} />
    )
}

export default Switch;