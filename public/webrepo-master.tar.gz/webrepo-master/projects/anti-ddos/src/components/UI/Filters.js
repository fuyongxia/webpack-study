import React from 'react';
import { Card } from 'antd';
import { default as AntFilters } from 'filters';

function Filters(props) {
    return (
        <Card>
            <AntFilters {...props}>
                {props.children}
            </AntFilters>
        </Card>
    )
}

Filters.Item = AntFilters.Item;

Filters.create = function({ items, props }) {
    return (
        <Filters {...props}>
            {items.map(item => (
                <Filters.Item
                    label={item.label}
                    name={item.name}
                >
                    {item.component}
                </Filters.Item>
            ))}
        </Filters>
    )
}

export default Filters;