import React from 'react';
import { default as AntSelect } from 'select';
import Adapter from 'adapter';

function Select(props) {
    function parse(value) {
        if (props.mode == 'multiple' && props.valueType == 'string') {
            return (value || '').split(',').filter(item => item !== '');
        }
        return value;
    }

    function valueOf(value) {
        if (props.mode == 'multiple' && props.valueType == 'string') {
            return (value || []).join(',');
        }
        return value;
    }

    return (
        <Adapter parse={parse} valueOf={valueOf} value={props.value} onChange={props.onChange} >
            <AntSelect {...props} />
        </Adapter>
    )
}

Select.Option = AntSelect.Option;
Select.defaultProps = {
    valueType: 'string'
}

export default Select;