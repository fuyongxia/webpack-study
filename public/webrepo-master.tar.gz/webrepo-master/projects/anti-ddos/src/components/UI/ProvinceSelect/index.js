import React from 'react';
import { Select } from 'antd';
import data from '../provinceData.json';

function ProvinceSelect(props) {
    return (
        <Select {...props}>
            {data.map(item => (
                <Select.Option value={item.name}>{item.name}</Select.Option>
            ))}
        </Select>
    )
}

export default ProvinceSelect;