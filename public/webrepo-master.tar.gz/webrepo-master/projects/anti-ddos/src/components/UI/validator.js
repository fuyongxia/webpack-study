// ipv4或前缀
function ipv4orPre(v) {
	var isOK = true;
	var ips = v.split(/[(\r\n)\r\n]+/);
	for(var n = 0; n < ips.length; n++) {
		if(ips[n].length<=0) continue;
		if(!isIpv4(ips[n])&&!isIpv4pre(ips[n])) {
			isOK = false;
			break;
		}
	}
	return isOK;
}

// ip地址
function isIpv4(ipv4) {
	return (/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/.test(ipv4) && (RegExp.$1 <256 && RegExp.$2<256 && RegExp.$3<256 && RegExp.$4<256))
}

// ipv4地址前缀
function isIpv4pre(ipv4) {
	return /^((0|[1-9]\d{0,1}|1\d{2}|2[0-4]\d|25[0-5])\.){3}(0|[1-9]\d{0,1}|1\d{2}|2[0-4]\d|25[0-5])\/([1-9]|[12]\d|3[012])$/.test(ipv4);
}

// ipv6地址
function isIpv6(value) {
	const ipv6 = /^([\da-fA-F]{1,4}:){6}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^::([\da-fA-F]{1,4}:){0,4}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:):([\da-fA-F]{1,4}:){0,3}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){2}:([\da-fA-F]{1,4}:){0,2}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){3}:([\da-fA-F]{1,4}:){0,1}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){4}:((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){7}[\da-fA-F]{1,4}$|^:((:[\da-fA-F]{1,4}){1,6}|:)$|^[\da-fA-F]{1,4}:((:[\da-fA-F]{1,4}){1,5}|:)$|^([\da-fA-F]{1,4}:){2}((:[\da-fA-F]{1,4}){1,4}|:)$|^([\da-fA-F]{1,4}:){3}((:[\da-fA-F]{1,4}){1,3}|:)$|^([\da-fA-F]{1,4}:){4}((:[\da-fA-F]{1,4}){1,2}|:)$|^([\da-fA-F]{1,4}:){5}:([\da-fA-F]{1,4})?$|^([\da-fA-F]{1,4}:){6}:$/;
    return ipv6.test(value);
}

// ipv6cidr
function isIpv6cidr(value) {
	const ipv6cidr = /^((\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*)(\/(([1-9])|([1-9][0-9])|(1[0-1][0-9]|12[0-8]))){0,1})*$/;
    return ipv6cidr.test(value);
}

// 邮箱验证
function isEmail(value) {
	return /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/.test(value);
}

//邮箱验证
function emailLine(v) {
	var isOK = true;
	var ips = v.split(/[(\r\n)\r\n]+/);
	for(var n = 0; n < ips.length; n++) {
		if(ips[n].length<=0) continue;
		if(!isEmail(ips[n])) {
			isOK = false;
			break;
		}
	}
	return isOK;
}

//支持ipv4 ivp6前缀
//支持中间-
//支持单个ipv4 ipv6
function variousIp(v) {
	var isOK = true;
	var ips = v.split(/[(\r\n)\r\n]+/);
	for(var n = 0; n < ips.length; n++) {
		if(ips[n].length<=0) continue;
		ipr = ips[n].trim();
		//d开头排除  p默认
		if(ipr.charAt(0) == 'd' || ipr.charAt(0) == 'p'){
		    ipr=ipr.substring(1)
		}
		// 掩码的
		if (ipr.indexOf("/") != -1) {
		   if(!isIpPre(ipr)){
		      isOK = false;
			  break;
		   }
		//中间-的
		}else if (ipr.indexOf("-") != -1) {
		     var start = ipr.split("-")[0];
             var end = ipr.split("-")[1];
             if((!isIpv4(start) || !isIpv4(end)) &&  (!isIpv6(start) || !isIpv6(end))){
                isOK = false;
			    break;  
             }
        //单个的
		}else{
		     if(!isIpv4(ipr) && !isIpv6(ipr)){
                isOK = false;
			    break;  
             }
		}
		
	}
	return isOK;
}

// ipv6前缀
function isIpv6Cidr(v) {
	var isOK = true;
	var ips = v.split(/[(\r\n)\r\n]+/);
	for(var n = 0; n < ips.length; n++) {
		if(ips[n].length<=0) continue;
		if(!isIpv6cidr(ips[n])) {
			isOK = false;
			break;
		}
	}
	return isOK;
}

// ipv4地址前缀或ipv6地址前缀
function isIpPre(v) {
	var isOK = true;
	var ips = v.split(/[(\r\n)\r\n]+/);
	for(var n = 0; n < ips.length; n++) {
		if(ips[n].length<=0) continue;
		if(!isIpv6Cidr(ips[n])&&!isIpv4pre(ips[n])) {
			isOK = false;
			break;
		}
	}
	return isOK;
}


export default {
    email: async (rule, value) => {
        if (!isEmail(value)) {
            throw new Error('请输入正确的邮箱地址');
        }
    },

    emails: async (rule, value) => {
        
    }
}