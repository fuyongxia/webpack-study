import React from 'react';
import { Card } from 'antd';
import { default as AntResults } from 'results';

function Results(props) {
    return (
        <Card
            style={{ marginTop: 10 }}
            bodyStyle={{ padding: '0 24px' }}
        >
            <AntResults {...props}>
                {props.children}
            </AntResults>
        </Card>
    )
}

export default Results;