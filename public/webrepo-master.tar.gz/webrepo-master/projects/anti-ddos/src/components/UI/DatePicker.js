import React from 'react';
import { DatePicker as AntDatePicker } from 'antd';
import Adapter from 'adapter';

function DatePicker(props) {
    function parse(value) {
        const { format, valueType } = props;
        switch(valueType) {
            case 'timestamp':
                return value ? moment(value) : null;
            case 'string':
                return value ? moment(value, format) : null;
            case 'default':
                return value;
        }
    }

    function valueOf(value) {
        const { format, valueType } = props;
        switch(valueType) {
            case 'timestamp':
                return value ? value.valueOf() : null;
            case 'string':
                return value ? value.format(format) : '';
            case 'default':
                return value;
        }
    }

    return (
        <Adapter parse={parse} valueOf={valueOf} value={props.value} onChange={props.onChange} >
            <AntDatePicker {...props} />
        </Adapter>
    )
}

DatePicker.defaultProps = {
    valueType: 'default',
    format: 'YYYY-MM-DD HH:mm:ss'
}

export default DatePicker;