import React from 'react';
import { Modal, message } from 'antd';

function confirm(service) {
    return (params) => {
        return (new Promise((resolve, reject) => {
            Modal.confirm({
                title: '确认',
                content: '确认执行所选操作？',
                onOk: () => {
                    resolve(service(params))
                }
            })
        })).then(body => {
            message.success('操作成功');
        })
    }
}

export default confirm;