import React from 'react';
import { Form, Row, Col, Button, Space} from 'antd';
import { SearchOutlined } from '@ant-design/icons';

function Filters(props) {
    const children = props.children.length ? props.children : [props.children];
    return (
        <Form {...props}>
            <Row gutter={16}>
                {children.filter(Boolean).map(item => (
                    <Col span={item.props.span || 24 / (props.columns || 4)}>
                        {item} 
                    </Col>
                ))}
                <Col style={{ textAlign: 'right', flex: 1 }}>
                    <Space>
                        {props.extra}
                        <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>查询</Button>
                    </Space>
                </Col>
            </Row>
        </Form>
    )
}


Filters.Item = Form.Item;

export default Filters;