import React from 'react';
import { PageHeader } from 'antd';
import style from './style.module.less';

export default function(props) {
    return (
        <div {...props} className={`${style.page} ${props.className}`}>
            <PageHeader ghost={false} title={props.title} />
            <div className={style.body}>
                {props.children}
            </div>
        </div>
    )
}