import React from 'react';
import { Layout } from 'antd';
import Aside from './Aside';
import Header from './Header';
import Content from './Content';
import Footer from './Footer';
import style from './layout.module.less';

export default function(props) {
    return (
        <div className={style.layout}>
            <Layout style={{ minHeight: '100%' }} >
                <Aside />
                <Layout>
                    <Header />
                        <Content>{props.children}</Content>
                    <Footer />
                </Layout>
            </Layout>
        </div>
    )
}