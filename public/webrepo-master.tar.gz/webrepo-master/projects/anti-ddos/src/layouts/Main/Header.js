import React, { useState, useEffect } from 'react';
import { Layout, Dropdown, Avatar, Menu, Modal, message } from 'antd';
import { LockOutlined, LogoutOutlined } from '@ant-design/icons';
import { useModalForm } from 'hooks';
import PasswordForm from './PasswordForm';
import style from './layout.module.less';

export default function () {
    const [ userInfo, setUserInfo ] = useState({});
    const { modalForm, setModalForm, modalFormProps } = useModalForm(false, { onFinish: onSavePassword });

    useEffect(() => {
        app.service.getUserInfo()
            .then(body => {
                setUserInfo(body);
            })
    }, [])

    function logout() {
        const accessToken = app.storage.get('access_token');
        fetch(app.config.logoutUrl + '&logout_token=' + accessToken, { method:"POST" })
            .catch(error => {
                //do nothing
            })
        app.storage.remove('access_token');
        location.reload();

    }

    function onLogout() {
        Modal.confirm({
            title: '确认登出',
            onOk() {
                logout();
            }
        })
    }

    function onSavePassword() {
        app.service.userPassword({
            authUserPassword: modalForm.data.userPasswordNew,
            authUserPasswordOrigin: modalForm.data.userPasswordOld
        }).then(body => {
            setModalForm(false);
            message.success('密码修改成功，即将退出重新登录...');
            setTimeout(() => {
                logout();
            }, 3000)
        }).catch(error => {
            message.error(error.message);
        })
    }

    function onPassword() {
        setModalForm({
            title: '修改密码',
            data: {}
        })
    }

    return (
        <>
            <Layout.Header
                style={{
                    height: 48,
                    lineHeight: 48,
                    background: "transparent"
                }}
            >
            </Layout.Header>
            <Layout.Header className={style.header} >
                <div className={style.inner}>
                    <div className={style.logo} >
                        <a><img src={require('./flow.png').default} alt="logo" /><h1>云网流量安全监测系统</h1></a>
                    </div>
                    <div style={{ flex: '1 1 0%' }}>
                    </div>
                    <div className={style.right}>
                        <Dropdown overlay={(
                            <Menu
                                selectedKeys={[]}
                            >
                                <Menu.Item key="password" onClick={onPassword}><LockOutlined />修改密码</Menu.Item>
                                <Menu.Divider />
                                <Menu.Item key="logout" onClick={onLogout}><LogoutOutlined />退出登录</Menu.Item>
                            </Menu>
                        )}>
                            <span className={`${style.action} ${style.account}`}>
                                <Avatar
                                    size="small"
                                    className={style.avatar}
                                    src={require('./avatar.png').default}
                                    alt="avatar"
                                />
                                 <span className={style.name}>{userInfo.nickname}</span>
                            </span>
                        </Dropdown>
                    </div>
                </div>
                {modalForm && <PasswordForm {...modalFormProps} />}
            </Layout.Header>
        </>
    )
}