import React from 'react';
import style from './layout.module.less';

export default function() {
    return (
        <div className={style.footer} >
            <img src={require('./logo.png').default} />
            Copyright @2021 中盈优创资讯科技有限公司出品
        </div>
    )
}