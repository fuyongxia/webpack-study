import React from 'react';
import { Modal, Input, Form, Button } from 'antd';

export default function(props) {
    return (
        <Modal visible={true} title="修改密码" width={400}  {...props} >
            <Form {...props}>
                <Form.Item
                    required
                    name="userPasswordOld"
                    rules={[{ required: true, message: '请输入原密码' }]}
                >
                    <Input.Password placeholder="原密码" visibilityToggle={true} />
                </Form.Item>
                <Form.Item
                    required
                    extra="请输入至少8位包含字母、数字及特殊字符的组合密码"
                    name="userPasswordNew"
                    rules={[
                        { required: true, message: '请输入新密码' },
                        () => ({
                            validator(rule, value) {
                                if (/^(?![\d]+$)(?![a-z]+$)(?![^\da-zA-Z]+$).{8,20}$/.test(value)) {
                                    return Promise.resolve();
                                }
                                return Promise.reject('新密码必须为至少8位包含字母、数字及特殊字符的组合密码');
                            },
                        }),
                    ]}
                >
                    <Input.Password placeholder="新密码" visibilityToggle={true} />
                </Form.Item>
                <Form.Item
                    required
                    name="userPasswordNewRepeat"
                    rules={[
                        { required: true, message: '请重新输入新密码' },
                        ({ getFieldValue }) => ({
                            validator(rule, value) {
                                if (!value || getFieldValue('userPasswordNew') === value) {
                                    return Promise.resolve();
                                }
                                return Promise.reject('两次密码输入不一致');
                            },
                        }),
                    ]}
                >
                    <Input.Password placeholder="重新输入新密码" visibilityToggle={true} />
                </Form.Item>
            </Form>
        </Modal>
    )
}