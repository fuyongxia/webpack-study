export default {
    cookie: {
        encode: false,
    },
    request: {
        onRequest: function (req, onRequest) {
            // req.headers.zy_token = app.cookie.get('zy_token');
            req.headers.Authorization =  app.storage.get('access_token') ? ('Bearer ' + app.storage.get('access_token')) : '';
            return onRequest(req);
        },
        onResponse: function (res) {
            if (res.status == 401) {
                return res.json()
                    .then(result => {
                        return Promise.reject(result);
                    })
            }

            if (res.status != 200) {
                return Promise.reject({ code: res.status, message: res.statusText });
            }

            return res.json()
                .then(result => {
                    const { code, body, message } = result;
                    if (code == null) {
                        return result;
                    }
                    if (code === '000000') {
                        return body;
                    }
                    return Promise.reject({ code, body, message });
                });


            // if (res.status != 200) {
            //     return Promise.reject({ code: res.status, message: res.statusText });
            // }

            // return res.json()
            //     .then(result => {
            //         const { code, data, message } = result;
            //         if (code === 200) {
            //             return data;
            //         }
            //         return Promise.reject({ code, data, message });
            //     });
        }
    },

    service: {
        items: {
            "dataList": 'POST api/v1/unicontroller/system/dic/datalist',

            "appliancePage": 'POST api/v1/unicontroller/base/appliance/page',
            "applianceView": "POST api/v1/unicontroller/base/appliance/view",
            "applianceEdit": "POST api/v1/unicontroller/base/appliance/edit",
            "applianceDelete": 'POST api/v1/unicontroller/base/appliance/delete',

            "routerPage": 'POST api/v1/unicontroller/base/router/page',
            "routerView": "POST api/v1/unicontroller/base/router/view",
            "routerEdit": "POST api/v1/unicontroller/base/router/edit",
            "routerDelete": 'POST api/v1/unicontroller/base/router/delete',
            "routerSnmpTest": 'POST api/v1/unicontroller/base/router/snmptest',

            "interfacePage": 'POST api/v1/unicontroller/base/interface/page',
            "interfaceView": "POST api/v1/unicontroller/base/interface/view",
            "interfaceEdit": "POST api/v1/unicontroller/base/interface/edit",
            "interfaceDelete": 'POST api/v1/unicontroller/base/interface/delete',

            "customerList": 'POST api/v1/unicontroller/base/customer/list',
            "customerPage": 'POST api/v1/unicontroller/base/customer/page',
            "customerView": "POST api/v1/unicontroller/base/customer/view",
            "customerEdit": "POST api/v1/unicontroller/base/customer/edit",
            "customerDelete": 'POST api/v1/unicontroller/base/customer/delete',

            "applicationPage": 'POST api/v1/unicontroller/base/application/page',
            "applicationView": "POST api/v1/unicontroller/base/application/view",
            "applicationEdit": "POST api/v1/unicontroller/base/application/edit",
            "applicationDelete": 'POST api/v1/unicontroller/base/application/delete',

            "groupPage": 'POST api/v1/unicontroller/base/group/page',
            "groupView": "POST api/v1/unicontroller/base/group/view",
            "groupEdit": "POST api/v1/unicontroller/base/group/edit",
            "groupDelete": 'POST api/v1/unicontroller/base/group/delete',
            "groupQueryInfterface": 'POST api/v1/unicontroller/base/group/queryInterface',
            "groupQueryMatchingInterface": 'POST api/v1/unicontroller/base/group/queryMatchingInterface',

            "ipaddressPage": 'POST api/v1/unicontroller/base/ipaddress/page',
            "ipaddressView": "POST api/v1/unicontroller/base/ipaddress/view",
            "ipaddressEdit": "POST api/v1/unicontroller/base/ipaddress/edit",
            "ipaddressDelete": 'POST api/v1/unicontroller/base/ipaddress/delete',

            "notificationGroupPage": 'POST api/v1/unicontroller/base/notification/group/page',
            "notificationGroupList": 'POST api/v1/unicontroller/base/notification/group/list',
            "notificationGroupView": "POST api/v1/unicontroller/base/notification/group/view",
            "notificationGroupEdit": "POST api/v1/unicontroller/base/notification/group/edit",
            "notificationGroupDelete": 'POST api/v1/unicontroller/base/notification/group/delete',

            "notificationRulePage": 'POST api/v1/unicontroller/base/notification/rule/page',
            "notificationRuleView": "POST api/v1/unicontroller/base/notification/rule/view",
            "notificationRuleEdit": "POST api/v1/unicontroller/base/notification/rule/edit",
            "notificationRuleDelete": 'POST api/v1/unicontroller/base/notification/rule/delete',

            "attackPage": 'POST api/v1/unicontroller/detect/attack/page',
            "attackView": "POST api/v1/unicontroller/detect/attack/view",
            "attackEdit": "POST api/v1/unicontroller/detect/attack/edit",
            "attackDelete": 'POST api/v1/unicontroller/detect/attack/delete',

            "wholeThresholdView": 'POST api/v1/unicontroller/detect/whole_threshold/view',
            "wholeThresholdEdit": "POST api/v1/unicontroller/detect/whole_threshold/edit",

            "systemLogPage": "POST api/v1/unicontroller/system/log/page",
            "systemLogDelete": "POST api/v1/unicontroller/system/log/delete",
            "systemLogEmpty": "POST api/v1/unicontroller/system/log/empty",

            "apiLogPage": "POST api/v1/unicontroller/JZKD/log/page",
            "apiLogDelete": "POST api/v1/unicontroller/JZKD/log/delete",
            "apiLogEmpty": "POST api/v1/unicontroller/JZKD/log/empty",

            "monitorSystemCount": 'POST api/v1/unicontroller/monitor/systemCount/getsysinfo',
            "monitorSystemDevice": 'POST api/v1/unicontroller/monitor/systemDevice/list',
            'monitorSystemDeviceItems': "POST api/v1/unicontroller/monitor/systemDevice/items",
            'monitorSystemFlowList': "POST api/v1/unicontroller/monitor/systemFlow/list",
            "monitorSystemFlowFlowItems": "POST api/v1/unicontroller/monitor/systemFlow/flowItems",
            "monitorSystemFlowApplianceItems": "POST api/v1/unicontroller/monitor/systemFlow/applianceItems",

            "storageView": 'POST api/v1/unicontroller/system/storage/view',
            "storageEdit": 'POST api/v1/unicontroller/system/storage/edit',

            "attackAnalysisDstTop": "POST api/v1/unicontroller/analysis/attack/dst/top",
            "attackAnalysisDstCount": "POST api/v1/unicontroller/analysis/attack/dst/count",
            "attackAnalysisDstTarget": "POST api/v1/unicontroller/analysis/attack/dst/target",


            "tracePlanPage": "POST api/v1/unicontroller/analysis/tracePlan/page",
            "tracePlanView": "POST api/v1/unicontroller/analysis/tracePlan/view",
            "tracePlanEdit": "POST api/v1/unicontroller/analysis/tracePlan/edit",
            "tracePlanDelete": "POST api/v1/unicontroller/analysis/tracePlan/delete",

            "attackSummaryLevel": "POST api/v1/unicontroller/attack/summary/level",
            "attackSummaryAttackType": 'POST api/v1/unicontroller/attack/summary/attack_type',
            "attackSummaryObject": 'POST api/v1/unicontroller/attack/summary/object',
            "attackSummaryBps": 'POST api/v1/unicontroller/attack/summary/bps',
            "attackSummaryDuration": 'POST api/v1/unicontroller/attack/summary/duration',

            "reportPage": 'POST api/v1/unicontroller/system/report/page',
            "reportHistoryPage": 'POST api/v1/unicontroller/system/report/historyPage',
            "reportEdit": 'POST api/v1/unicontroller/system/report/edit',
            "reportDelete": 'POST api/v1/unicontroller/system/report/delete',
            "reportHistoryDelete": 'POST api/v1/unicontroller/system/report/historyDelete',

            "ipAddressPage": 'POST api/v1/unicontroller/base/ipaddress/page',
            "ipAddressEdit": 'POST api/v1/unicontroller/base/ipaddress/edit',
            "ipAddressDelete": 'POST api/v1/unicontroller/base/ipaddress/delete',

            "ping": 'POST api/v1/unicontroller/system/ip/ping',

            "worldAreaList": function (data, options) {
                if (data.id == 0 || data.name) {
                    return app.request.post('api/v1/unicontroller/system/worldArea/list', data, options);
                }
                return Promise.resolve([]);
            },

            "analysisNetflowTracePage": "POST api/v1/unicontroller/analysis/netflowTrace/page",
            "analysisNetflowTraceList": "POST api/v1/unicontroller/analysis/netflowTrace/list",

            "analysisNetSegment": "POST api/v1/unicontroller/analysis/attack/net_segment/list",
            "attackDdosPage": "POST api/v1/unicontroller/attack/ddos/page",
            "analysisNetflowPage": 'POST api/v1/unicontroller/analysis/netflow/page',
            "analysisNetflowList": 'POST api/v1/unicontroller/analysis/netflow/list',
            "attackDdosInfo": 'POST api/v1/unicontroller/attack/ddos/detail/info',
            "attackDdosProcess": 'POST api/v1/unicontroller/attack/ddos/detail/process',
            "attackDdosCount": 'POST api/v1/unicontroller/attack/ddos/count/top',

            "analysisSrcArea": 'POST api/v1/unicontroller/attack/ddos/analysis/src_area',
            "analysisSrcNetwork": 'POST api/v1/unicontroller/attack/ddos/analysis/src_network',
            'analysisSrcRoute': 'POST api/v1/unicontroller/attack/ddos/analysis/src_route',

            "attackSummaryLevel": function (data, options) {
                return app.request.post('api/v1/unicontroller/attack/summary/level', data, options)
                    .then(body => {
                        return [
                            {
                                status: '进行中',
                                high: body.ongoingHigh,
                                medium: body.ongoingMedium,
                                low: body.ongoingLow
                            },
                            {
                                status: '已经结束',
                                high: body.endHigh,
                                medium: body.endMedium,
                                low: body.endLow
                            },
                            {
                                status: '共计',
                                high: body.totalHigh,
                                medium: body.totalMedium,
                                low: body.totalLow
                            },
                        ];
                    })
            },
            "attackSummaryType": 'POST api/v1/unicontroller/attack/summary/attack_type',
            "attackSummaryObject": 'POST api/v1/unicontroller/attack/summary/object',
            "attackSummaryBps": 'POST api/v1/unicontroller/attack/summary/bps',
            "attackSummaryDuration": 'POST api/v1/unicontroller/attack/summary/duration',
            "flowTopExport": `POST POST api/v1/unicontroller/attack/ddos/flowTopExport`,            

            orgList: `POST ${LOGIN_API_PREFIX}auth/org/list/${LOGIN_USER_SCOPE}`,
            orgSave: `POST ${LOGIN_API_PREFIX}auth/org/save/${LOGIN_USER_SCOPE}`,
            orgUpdate: `POST ${LOGIN_API_PREFIX}auth/org/update/${LOGIN_USER_SCOPE}`,
            orgDelete: `POST ${LOGIN_API_PREFIX}auth/org/delete/${LOGIN_USER_SCOPE}`,

            userList: `POST ${LOGIN_API_PREFIX}auth/user/list/${LOGIN_USER_SCOPE}`,
            userSave: `POST ${LOGIN_API_PREFIX}auth/user/save/${LOGIN_USER_SCOPE}`,
            userUpdate: `POST ${LOGIN_API_PREFIX}auth/user/update/${LOGIN_USER_SCOPE}`,
            userDelete: `POST ${LOGIN_API_PREFIX}auth/user/delete/${LOGIN_USER_SCOPE}`,
            userPassword: `POST ${LOGIN_API_PREFIX}auth/user/update/password/${LOGIN_USER_SCOPE}`,

            roleList: `POST ${LOGIN_API_PREFIX}auth/role/list/${LOGIN_RESOURCE_SCOPE}`,
            roleSave: `POST ${LOGIN_API_PREFIX}auth/role/save/${LOGIN_RESOURCE_SCOPE}`,
            roleUpdate: `POST ${LOGIN_API_PREFIX}auth/role/update/${LOGIN_RESOURCE_SCOPE}`,
            roleDelete: `POST ${LOGIN_API_PREFIX}auth/role/delete/${LOGIN_RESOURCE_SCOPE}`,

            roleUserSave: `POST ${LOGIN_API_PREFIX}auth/role/user/relation/save/${LOGIN_RESOURCE_SCOPE}`,
            roleUserDelete: `POST ${LOGIN_API_PREFIX}auth/role/user/relation/delete/${LOGIN_RESOURCE_SCOPE}`,

            orgUserSave: `POST ${LOGIN_API_PREFIX}auth/org/user/relation/save/${LOGIN_USER_SCOPE}`,
            orgUserDelete: `POST ${LOGIN_API_PREFIX}auth/org/user/relation/delete/${LOGIN_USER_SCOPE}`,

            resList: `POST ${LOGIN_API_PREFIX}auth/res/list/${LOGIN_RESOURCE_SCOPE}`,
            resSave: `POST ${LOGIN_API_PREFIX}auth/res/save/${LOGIN_RESOURCE_SCOPE}`,
            resUpdate: `POST ${LOGIN_API_PREFIX}auth/res/update/${LOGIN_RESOURCE_SCOPE}`,
            resDelete: `POST ${LOGIN_API_PREFIX}auth/res/delete/${LOGIN_RESOURCE_SCOPE}`,

            authAttrs: `POST ${LOGIN_API_PREFIX}auth/common/attrs`,

            grantList: `POST ${LOGIN_API_PREFIX}auth/grant/list`,
            grantSave: `POST ${LOGIN_API_PREFIX}auth/grant/save`,
            grantUpdate: `POST ${LOGIN_API_PREFIX}auth/grant/update`,
            grantMerge: `POST ${LOGIN_API_PREFIX}auth/grant/merge`,
            grantDelete: `POST ${LOGIN_API_PREFIX}auth/grant/delete`,
            
            getUserInfo: (data, options) => {
                return app.request.post(`${LOGIN_DOMAIN}/api/v1/authorization/oidc/userinfo?access-origin=${LOGIN_ACCESS_ORIGIN}`, data, options) 
            },

            getGrantResource: (data, options) => {
                return app.request.post(`${LOGIN_DOMAIN}/api/v1/authorization/oidc/grant/resource?access-origin=${LOGIN_ACCESS_ORIGIN}`, data, options)
            },

        }
    }
}