import React from "react";
import Main from './layouts/Main';
import { HashRouter as Router } from "react-router-dom";
import LoginPage from 'login';
import AppliancePage from '@pages/appliance';
import RouterPage from '@pages/router';
import InterfacePage from '@pages/interface';
import CustomerPage from '@pages/customer';
import GroupPage from '@pages/group';
import ApplicationPage from '@pages/application';
import ThresholdPage from '@pages/threshold';
import ReportPage from '@pages/report';
import IpAddressPage from '@pages/ip_address';
import ApiLogPage from '@pages/api_log';
import SystemLogPage from '@pages/system_log';
import StoragePage from "@pages/storage";
import NotificationRulePage from '@pages/notification_rule';
import NotificationGroupPage from '@pages/notification_group';
import SystemCountPage from '@pages/system_count';
import SystemDevicePage from '@pages/system_device';
import SystemFlowPage from '@pages/system_flow';
import AttackTypePage from '@pages/attack_type';
import AnalysisTracePlanPage from '@pages/analysis_trace_plan';
import AttackDdosPage from '@pages/attack_ddos';
import AttackProcessPage from '@pages/attack_process';
import AttackCountPage from '@pages/attack_count';
import AttackAnalysisPage from '@pages/attack_analysis';
import AnalysisNetflowTracePage from '@pages/analysis_netflow_trace';
import AnalysisNetSegment from '@pages/analysis_net_segment';
import AnalysisNetFlowPage from '@pages/analysis_netflow';
import AttackSummaryPage from '@pages/attack_summary';
import AnalysisDestination from '@pages/analysis_destination';

import OrgPage from './pages/Org';
import RolePage from './pages/Role';
import UserPage from './pages/User';
import ResPage from './pages/Res';
import GrantPage from './pages/Grant';
import CallbackPage from './pages/Callback';

export default function (props) {
    return (
        <>
            <Router>
                <Main>
                    <AppliancePage />
                    <InterfacePage />
                    <CustomerPage />
                    <ThresholdPage />
                    <GroupPage />
                    <ReportPage />
                    <IpAddressPage />
                    <ApplicationPage />
                    <ApiLogPage />
                    <SystemLogPage />
                    <StoragePage />
                    <NotificationRulePage />
                    <NotificationGroupPage />
                    <SystemCountPage />
                    <SystemDevicePage />
                    <SystemFlowPage />
                    <AttackTypePage />
                    <AnalysisNetSegment />
                    <AttackDdosPage />
                    <AttackProcessPage />
                    <AttackCountPage />
                    <AttackSummaryPage />
                    <AttackAnalysisPage />
                    <AnalysisTracePlanPage />
                    <AnalysisNetflowTracePage />
                    <AnalysisNetFlowPage />
                    <AnalysisDestination />
                    <RouterPage />
                    <OrgPage />
                    <RolePage />
                    <UserPage />
                    <ResPage />
                    <GrantPage />
                    <CallbackPage />
                </Main>
            </Router>
        </>
    )
}