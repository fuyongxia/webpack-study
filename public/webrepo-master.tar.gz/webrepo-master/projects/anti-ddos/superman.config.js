module.exports = {
    port: 9001,
    proxy: {
        '/api/': {
            target: 'http://192.168.131.98:8080/',
            secure: false
        }
    },
    // publicPath: '/public/scnpu/analytics'
    publicPath: ''
}