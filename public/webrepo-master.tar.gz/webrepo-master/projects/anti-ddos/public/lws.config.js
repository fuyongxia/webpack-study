module.exports = {
    spa: 'index.html',
    rewrite: [
        {
            from: '/api/(.*)',
            to: 'http://192.168.131.98:8080/api/$1'
        }
    ],
    logFormat: 'stats'
}