import React from "react";
import Main from './layouts/Main';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Login from 'login';
import Appliance from 'appliance';

export default function (props) {
    return (
        <>
            <Router>
                <Switch>
                    <Route path="/login">
                        <Login />
                    </Route>
                    <Route path="/appliance">
                        <Main><Appliance /></Main>
                    </Route>
                </Switch>
            </Router>
        </>
    )
}