module.exports = {
    service: {
        items: {
            baseAppliancePage: 'POST /api/base/appliance/page'
        }
    }
}