import React, { useEffect, useState } from 'react';
import { Select as AntSelect } from 'antd';

function Select (props) {
    const { params, service, labelField = 'label', valueField = 'value' } = props;
    const [ loading, setLoading ] = useState(false);
    const [ options, setOptions ] = useState([]);

    useEffect(() => {
        if (service) {
            setLoading(true);
            service(params).then(body => {
                body = body.results || body;
                setOptions(body);
                setLoading(false);
            }).catch(error => {
                setLoading(false);
                throw error;
            })
        }
    }, [ params ])

    return (
        <AntSelect loading={loading} {...props}>
            {options.map(item => (
                <AntSelect.Option value={item[valueField]} {...item}>{item[labelField]}</AntSelect.Option>
            ))}
        </AntSelect>
    )
}

Select.Option = AntSelect.Option;
Select.OptGroup = AntSelect.OptGroup;

export default Select;