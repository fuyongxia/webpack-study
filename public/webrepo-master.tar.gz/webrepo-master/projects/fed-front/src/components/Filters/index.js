import React from 'react';
import { Form, Row, Col, Button } from 'antd';

function Filters(props) {
    const children = props.children.length ? props.children : [props.children];
    return (
        <Form {...props}>
            <Row gutter={16}>
                {children.map(item => (
                    <Col span={24/( props.columns || 4)}>
                        {item}
                    </Col>
                ))}
                <Col style={{ textAlign: 'right', flex: 1 }}>
                    <Button type="primary" htmlType="submit">查询</Button>
                </Col>
            </Row>
        </Form>
    )
}

Filters.Item = Form.Item;

export default Filters;