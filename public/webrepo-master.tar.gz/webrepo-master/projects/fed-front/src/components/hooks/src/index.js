import React, { useState, useEffect, useRef } from 'react';
import jss from './jss';

function useTableFilters(initState, options) {
    const [filters, setFilters] = useState(initState);

    const updateFilters = updatedValues => {
        setFilters(prevState => ({
            ...prevState,
            ...updatedValues
        }))
    };

    return {
        filters,
        setFilters: updateFilters,
        filtersProps: {
            initialValues: filters,
            onValuesChange: updateFilters,
            onFinish: () => {
                setFilters({ ...filters, _updatedAt: Date.now() });
            },
            ...options
        }
    }
}

function useTableResults(service, deps = [], options = {}) {
    const [loading, setLoading] = useState(false);
    const [pagination, setPagination] = useState();
    const [dataSource, setDataSource] = useState([]);

    const update = (params) => {
        setLoading(true);
        service(params).then(body => {
            if (body.results) {
                setPagination({ current: params.pageNo || 1, total: body.totalCount });
                setDataSource(body.results);
                setLoading(false);
            } else {
                setDataSource(body);
            }
            setLoading(false);
        }).catch(error => {
            setLoading(false);
            throw error;
        })
    }

    useEffect(() => {
        update(options.filters || {})
    }, deps);

    return {
        pagination,
        tableProps: {
            loading: loading,
            dataSource: dataSource,
            pagination: pagination,
            onChange: (pagination) => {
                update({
                    ...options.filters,
                    pageNo: pagination.current
                })
            },
            ...options
        }
    }
}

function useModalForm(state, options = {}) {
    const [modalForm, setModalForm] = useState(state);

    const defaultOptions = {
        initialValues: modalForm.data,
        onCancel() {
            setModalForm(false);
        },
        onValuesChange(data) {
            setModalForm({
                ...modalForm,
                data: {
                    ...modalForm.data,
                    ...data
                }
            })
        },
    }

    return {
        modalForm,
        setModalForm: args => {
            if (typeof args == 'function') {
                Promise.resolve(args())
                    .then(body => {
                        setModalForm(body)
                    })
                return;
            }
            setModalForm(args);
        },
        modalFormProps: {
            ...modalForm,
            ...defaultOptions,
            ...options
        }
    }
}

function useConstructor(callback = ()=> {}) {
    const inited = useRef(false);
    if (!inited.current) {
        callback();
        inited.current = true;
    }
}

function useStyles(styleSheet, deps = {}) {
    const sheetRef = useRef(null);
    const [ inited, setInited ] = useState(false);

    if (!inited) {
        sheetRef.current = jss
            .createStyleSheet(styleSheet)
            .attach();
        setInited(true);
    }

    useEffect(() => {
        sheetRef.current.update(deps);
        return () => {
            sheetRef.current.detach();
        }
    }, [ deps ]);

    return sheetRef.current.classes;
}


export { useConstructor, useStyles, useTableFilters, useTableResults, useModalForm };