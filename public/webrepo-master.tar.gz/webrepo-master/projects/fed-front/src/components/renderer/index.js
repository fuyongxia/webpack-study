import React from 'react';

function dateRender(format = 'YYYY/MM/DD HH:mm:ss') {
    return (value) => {
        return value && moment(value).format(format)
    }
}

function dateRender() {
    return (
        <div>

        </div>
    )
}

function paraRender() {

}

export { dateRender };