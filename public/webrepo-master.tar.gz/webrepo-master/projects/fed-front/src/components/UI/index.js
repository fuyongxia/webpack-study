import React, { useState } from 'react';
import { Card } from 'antd';
import { default as AntFilters } from 'filters';
import { default as AntResults } from 'results';

function Filters(props) {
    return (
        <Card>
            <AntFilters {...props}>
                {props.children}
            </AntFilters>
        </Card>
    )
}

Filters.Item = AntFilters.Item;

function Results(props) {
    return (
        <Card
            style={{ marginTop: 10 }}
            bodyStyle={{ padding: '0 24px' }}
        >
            <AntResults {...props}>
                {props.children}
            </AntResults>
        </Card>
    )
}

export { default as Grid } from 'grid';
export { default as Page } from 'page';
export { default as Select } from 'select';
export { default as ScrollView } from 'scroll-view';

export { Filters, Results };