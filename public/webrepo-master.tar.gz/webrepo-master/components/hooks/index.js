import { useState, useEffect, useRef } from 'react';
import { Form } from 'antd';
import jss from './jss';

function useConstructor(callback = ()=> {}) {
    const inited = useRef(false);
    if (!inited.current) {
        callback();
        inited.current = true;
    }
}

function useStyle(styleSheet, deps) {
    const sheetRef = useRef(null);

    useConstructor(() => {
        sheetRef.current = jss
            .createStyleSheet(styleSheet)
            .attach();
    })

    useEffect(() => {
        sheetRef.current.update(deps);
        return () => {
            sheetRef.current.detach();
        }
    }, [JSON.stringify(deps)]);

    return sheetRef.current.classes;
}

function useService(api, params = {}, defaults) {
    const [ data, setData ] = useState(defaults);

    useEffect(() => {
        api(params)
            .then(body => {
                setData(body);
            })
    }, [ JSON.stringify(params)] );

    return data;
}

function useValue({ value, onChange }) {
    const [ val, setVal ] = useState(value);

    useEffect(() => {
        setVal(value);
    }, [ JSON.stringify(value)])

    return [
        val,
        function(args) {
            setVal(args);
            onChange && onChange(args);
        }
    ]
}

function useFilterForm(state, options) {
    const [ form ] = Form.useForm();
    const [filterForm, setFilterForm] = useState(state);

    const updateFilterForm = updatedValues => {
        form.setFieldsValue(updatedValues);
        setFilterForm(prevState => ({
            ...prevState,
            ...updatedValues
        }))
    };

    return {
        filterForm,
        setFilterForm: updateFilterForm,
        filterFormProps: {
            form,
            initialValues: filterForm,
            onValuesChange: updateFilterForm,
            onFinish: () => {
                setFilterForm({ ...filterForm, _updatedAt: Date.now() });
            },
            ...options
        }
    }
}

function useModalForm(state, options = {}) {
    const [form] = Form.useForm();
    const [modalForm, setModalForm] = useState(state);

    useEffect(() => {
        if (modalForm) {
            form.resetFields();
        }
    }, [Boolean(modalForm)])

    const defaultOptions = {
        form,
        initialValues: modalForm.data,
        onOk() {
            form.submit();
        },
        onCancel() {
            setModalForm(false);
        },
        onValuesChange(data) {
            if (modalForm.type == 'view') {
                form.setFieldsValue(modalForm.data);
                return;
            }
            form.setFieldsValue(data);
            setModalForm({
                ...modalForm,
                data: {
                    ...modalForm.data,
                    ...data
                }
            })
        },
        footer: modalForm.type == 'view' ? null : undefined
    }

    return {
        modalForm,
        setModalForm,
        modalFormProps: {
            ...modalForm,
            ...defaultOptions,
            ...options
        }
    }
}

function useTable(service, deps = [], options = {}) {
    const [props, setProps] = useState(options);

    function setTable(args) {
        setProps(prevProps => {
            return { ...prevProps, ...args }
        })
    }

    function fetchData(params) {
        setTable({ loading: true });
        service(params).then(body => {
            body = body || [];
            if (body.length) {
                setTable({
                    loading: false,
                    dataSource: body.map((item, index) => ({
                        _index: index + 1,
                        ...item
                    }))
                })
            } else {
                setTable({
                    loading: false,
                    pagination: {
                        ...props.pagination,
                        current: body.currentPage,
                        pageSize: body.pageSize,
                        total: body.recordTotal
                    },
                    dataSource: (body.content || []).map((item, index) => ({
                        _index: body.pageSize*(body.currentPage -1) + index + 1,
                        ...item
                    }))
                })
            }
        }).catch(error => {
            setTable({
                loading: false
            })
            throw error;
        })
    }

    useEffect(() => {
        service && fetchData(options.filters);
    }, deps);

    return {
        table: props,
        setTable: setTable,
        tableProps: {
            ...props,
            onChange(pagination, filters, sorter, extra) {
                if (extra.action == 'paginate') {
                    service && fetchData({
                        ...options.filters,
                        pageNum: pagination.current,
                        pageSize: pagination.pageSize
                    })
                }
                if (props.onChange) {
                    props.onChange(pagination, filters, sorter, extra)
                }
            }
        }
    }
}

export { useConstructor, useStyle, useValue, useService, useTable, useFilterForm, useModalForm };