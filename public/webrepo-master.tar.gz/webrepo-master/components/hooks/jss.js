import preset from 'jss-preset-default'
import jss from 'jss'

jss.setup(preset())

export default jss;