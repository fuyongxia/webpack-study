import React from 'react';
import { DatePicker as AntDatePicker } from 'antd';
import Adapter from '@sbtd/adapter';

function RangePicker(props) {
    function parse(value) {
        const { format, valueType } = props;
        switch(valueType) {
            case 'timestamp':
                return value ? [moment(value[0]), moment(value[1])] : null;
            case 'string':
                return value ? [moment(value[0], format), moment(value[1], format)] : null;
            case 'default':
                return value;
        }
    }

    function valueOf(value) {
        const { format, valueType } = props;
        switch(valueType) {
            case 'timestamp':
                return value ? [value[0].valueOf(), value[1].valueOf()] : null;
            case 'string':
                return value ? [value[0].format(format), value[1].format(format)] : null;
            case 'default':
                return value;
        }
    }

    return (
        <Adapter parse={parse} valueOf={valueOf} value={props.value} onChange={props.onChange} >
            <AntDatePicker.RangePicker {...props} />
        </Adapter>
    )
}

RangePicker.defaultProps = {
    valueType: 'default',
}

export default RangePicker;