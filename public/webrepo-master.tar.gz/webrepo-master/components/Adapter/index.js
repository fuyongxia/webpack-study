import React from 'react';

function Adapter(props) {
    const { parse, valueOf, valueProp } = props;

    return React.cloneElement(props.children, {
        [valueProp]: parse(props.value),
        onChange: (value) => props.onChange && props.onChange(valueOf(value))
    })
}

Adapter.defaultProps = {
    valueProp: 'value'
}

export default Adapter;