import React, { useState, useEffect } from 'react';

function Service(props) {
    const { api, params = {}, callback, defaults = {} } = props;
    
    const [ loading, setLoading ] = useState(false);
    const [ data, setData ]  = useState(defaults);

    useEffect(() => {
        setLoading(true);
        api(params).then(body => {
            setLoading(false);
            setData(body);
        }).catch(error => {
            setLoading(false);
            throw error;
        })
    }, [ JSON.stringify(params)]);

    return callback(data, loading);
}

export default Service;