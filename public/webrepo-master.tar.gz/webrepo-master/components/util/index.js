import lodash from 'lodash';

export default {
    denormalize(array, options) {
        options = lodash.merge({
            id: 'id',
            pid: 'pid',
            root: { id: 0 },
            children: 'children',
            transform: lodash.cloneDeep
        }, options);
    
        const { id, pid, root, children, transform } = options;
    
        const parse = (array, root) => {
            for (let i=0; i<array.length; i++) {
                let item = array[i];
                if (root[id] == item[pid]) {
                    if (!root[children]) {
                        root[children] = []
                    }
                    root[children].push(parse(array, item))
                }
            }
            return root;
        }
    
        return parse(array.map(transform), root);
    },

    convertTo(value, unit) {
        const base = 1024;
        const number = lodash.toNumber(value);

        if (!lodash.isNumber(number) || value < base) {
            return value + unit.slice(1);
        }

        let n = ' KMGTP'.indexOf(unit[0]);
        if (!n) {
            n = Math.floor(Math.log(number) / Math.log(base));
        }
        return (number / Math.pow(base, n)).toFixed(2) + ['', 'K', 'M', 'G', 'T', 'P'][n] + unit.slice(1);
    },

    confirm(service) {
        return (params) => {
            return (new Promise((resolve, reject) => {
                Modal.confirm({
                    title: '确认',
                    content: '确认执行所选操作？',
                    onOk: () => {
                        resolve(service(params))
                    }
                })
            })).then(body => {
                message.success('操作成功');
            })
        }
    }
}