import React from 'react';
import { Row as AntRow, Col as AntCol } from 'antd';

function Grid(props) {
    const children = (props.children ? (props.children.length ? props.children : [ props.children]) : []).filter(Boolean);
    return (
        <div  {...props}>
            {children.map(item => {
                if (item.type === Grid.Row || item.type === AntRow) {
                    return React.cloneElement(item, { gutter: props.gutter, ...item.props })
                }
                return item;
            })}
        </div>
    )
}

Grid.Row = function (props) {
    const children = (props.children ? (props.children.length ? props.children : [ props.children]) : []).filter(Boolean);
    return (
        <AntRow {...props}>
            {children.map(item => {
                if (item.type !== Grid.Col || item.type !== AntCol) {
                    return (
                        <AntCol span={24/children.length}>
                            {item}
                        </AntCol>
                    )
                } 
                return item;
            })}
        </AntRow>
    )
};

Grid.Col = AntCol;

export default Grid;