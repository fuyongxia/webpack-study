import React from 'react';
import style from './style.module.less';

export default function(props) {
    const computedStyle = {
        overflowX: 'hidden',
        overflowY: 'auto',
        minHeight: props.minHeight,
        maxHeight: props.maxHeight,
        ...props.style
    }
    return (
        <div {...props} style={computedStyle} className={`${style.scrollView} ${props.className}`}>
            {props.children}
        </div>
    )
}