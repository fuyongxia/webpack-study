import React from 'react';
import { Table as AntTable } from 'antd';
import { useTable } from '@sbtd/hooks';

function Table(props) {
    const { service, filters = {} } = props;
    const { tableProps } = useTable(service, [ filters._updatedAt ], { filters });

    return (
        <AntTable {...tableProps} {...props}>
            {props.children}
        </AntTable>
    )
}

Table.Column = AntTable.Column;

Table.create = function(options) {
    return (
        <Table {...options} />
    )
}

export default Table;