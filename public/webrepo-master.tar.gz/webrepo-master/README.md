# webrepo

前端代码仓库




### 打包运行

按以下内容为每个项目构建测试或上线的文件、在.gitlab-ci.yml文件中

推荐前端和后端使用的tags是相同的、即相同的机器

```
build_sfp_dc: <---- 起一个 build_项目名
  stage: build  <---- 固定就是build
  tags:
    - test-131-89  <---- 在哪台机器上运行 这需要安装一个github-runner
  only:
    - master <---- 在哪个分支上构建流程
  script: <---- 以下是一堆构建脚本 sh 执行的东西
    - echo "Build Sfp Dc " <---- 输出个名字
    - cd $CI_PROJECT_DIR/projects/sfp-dc <---- 切换到目录下
    - /home/node/node-v14.17.0-linux-x64/bin/yarn install  <---- 执行install和build
    - /home/node/node-v14.17.0-linux-x64/bin/yarn build
    - cd $CI_PROJECT_DIR/projects/sfp-dc/build <---- 到build完的目录里面
    - zip -r ../build.zip * <---- 把build目录里面的内容都zip 为了artifacts
    - unzip -o -d /home/web/sfp-dc-or-gateway-resources $CI_PROJECT_DIR/projects/sfp-dc/build.zip <---- 把build内容输出到一个项目用的外部资源目录
  cache:
    paths:
      - $CI_PROJECT_DIR/projects/sfp-dc/node_modules/ <---- 缓存它
  artifacts:
     paths:
      - $CI_PROJECT_DIR/projects/sfp-dc/build.zip <---- 上传作为构建的工作件附件
  when: manual

```